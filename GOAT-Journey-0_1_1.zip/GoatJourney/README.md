# GOAT Journey 0.1.1 — Gameplay Rework (vertical)

Mismo proyecto que 0.1 (Canvas, Room, DataStore, CareerState, calendario, tabla, guardado). Se reconstruye el partido.
Saves de 0.1 compatibles: `CareerState`/`MatchResult`/`PlayerStats` no cambian (no hace falta SaveVersion nuevo).

## Flujo
MATCH_SIMULATING -> KEY_MOMENT -> (POSITIONING) -> AIM -> CONTACT -> BALL_FLIGHT -> respuesta de compañeros/rivales -> RESULT -> (NEW KEY_MOMENT | simulación)

## Controles (todo táctil, sin joystick ni botones permanentes)
- POSITIONING (ventana 0.7–3.2 s según presión/zona/Vision/Positioning): arrastra en cualquier punto para moverte; arrastra DESDE EL BALÓN para ejecutar.
- REACTION / ACROBATIC (0.45–1.4 s): sin movimiento libre; arrastra ya (el anillo se cierra sobre el punto de contacto).
- AIM: dirección = dirección del arrastre; fuerza = longitud (MAX_DRAG 260 px, curva ^1.2). Se muestra vector, fuerza y trayectoria inicial.
- CONTACT: toca el balón grande. Derecha/izquierda = efecto hacia ese lado; abajo = elevado; arriba = rasante y potente. Zona muerta central suave.
- La acción (pase, pase al espacio, tiro, centro, despeje...) se INFIERE del gesto y del contexto; no hay menú.

## Arquitectura (core/match)
MatchModel (Vec, KeyMoment, KeyMomentType, Mate/Rival/Keeper, ActionResult/Beat) · BallPhysics (gravedad, rozamiento, bote, curva) ·
Phases (AimPhase, ContactPhase, PositioningPhase, ActionIntent) · TeamAI (OpponentAI, TeammateAI) · KeyMomentGenerator ·
MomentSession (máquina de fases, sin Android) · ActionResolver (único resolutor) · AIPlayerController (SIMULATE).
PLAY y SIMULATE usan el mismo ActionResolver; solo cambia quién produce el gesto.

Implementados: PASS, SHOT, POSITIONING, HEADER, REBOUND, INTERCEPTION, ONE_TWO, CROSS, CLEARANCE, FIRST_TOUCH, VOLLEY, CHILENA (acrobático).
Preparados (enum, sin generador): BLOCK, TACKLE, DRIBBLE.
Ganchos futuros: personalidad (TeammateAI.decide / AIPlayerController.chooseGesture), regate manual (DRIBBLE_MOMENT), primer toque ya encadena momentos.

## Notas
- Positioning cambia dónde aparece el protagonista (distancia al marcador, llegada a centros, ventana). Vision hace más legibles compañeros libres, carreras y espacios (resaltado sutil).
- Buen gesto ≠ éxito: error angular, de potencia y de contacto dependen de atributos, presión, estabilidad del contacto y timing.
- Rebotes, paredes y centros encadenan KeyMoments (profundidad máx. 4).
- Pixel art funcional; el pulido visual queda para después.
