package com.goatjourney.core.match

import com.goatjourney.core.player.Attributes
import kotlin.math.*
import kotlin.random.Random

/** Todo lo que el resolutor necesita: gesto del usuario + estado vivo + calidad de la ejecución. */
class ResolveInput(
    val moment: KeyMoment, val world: World, val ball: Vec, val ballZ: Float,
    val attrs: Attributes, val aim: Aim, val intent: ActionIntent, val contact: Contact, val effect: ContactEffect,
    val timing: Float, val arrive: Float, val pressure: Float
)

/**
 * Único resolutor de acciones (PLAY y SIMULATE pasan por aquí).
 * Resultado = gesto (dirección, fuerza, contacto, timing) + atributos + presión + situación + calidad de compañeros/rivales.
 */
class ActionResolver(private val rng: Random, private val gen: KeyMomentGenerator) {

    private var A: Attributes = Attributes(50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50)

    private class Strike(val traj: Trajectory, val from: Vec, val skill: Float)
    private class Reach(val who: Int, val idx: Int, val t: Float, val pos: Vec, val z: Float, val margin: Float)
    private class Chain(val minute: Int, val depth: Int, val fromPlayer: Boolean, val passDist: Float, val aerial: Boolean)
    private class ShotEval(
        val outcome: ShotOutcome, val endT: Float, val keeperTo: Vec?, val rebound: Trajectory?,
        val label: String, val detail: String
    )

    private fun rf(a: Float, b: Float) = a + rng.nextFloat() * (b - a)

    // ------------------------------------------------------------------ atributos
    private fun skillFor(k: IntentKind, a: Attributes): Float = when (k) {
        IntentKind.PASS, IntentKind.SPACE_PASS ->
            a.passing * 0.5f + a.vision * 0.1f + a.control * 0.15f + a.decisions * 0.1f + a.composure * 0.15f
        IntentKind.CROSS -> a.crossing * 0.6f + a.passing * 0.15f + a.control * 0.1f + a.vision * 0.15f
        IntentKind.HEADER -> a.finishing * 0.3f + a.strength * 0.2f + a.positioning * 0.2f + a.composure * 0.15f + a.control * 0.15f
        IntentKind.CLEARANCE -> a.strength * 0.2f + a.control * 0.2f + a.composure * 0.25f + a.decisions * 0.2f + a.positioning * 0.15f
        else -> a.finishing * 0.35f + a.shooting * 0.3f + a.composure * 0.2f + a.control * 0.15f
    } / 100f

    private fun powerAttr(k: IntentKind, a: Attributes): Float = when (k) {
        IntentKind.PASS, IntentKind.SPACE_PASS, IntentKind.CROSS -> a.passing * 0.6f + a.strength * 0.4f
        IntentKind.HEADER -> a.strength * 0.7f + a.shooting * 0.3f
        else -> a.shooting * 0.55f + a.strength * 0.45f
    } / 100f

    fun technique(a: Attributes): Float = (a.control * 0.6f + a.dribbling * 0.2f + a.composure * 0.2f) / 100f

    // ------------------------------------------------------------------ API
    fun resolve(inp: ResolveInput): ActionResult {
        A = inp.attrs
        return when (inp.intent.kind) {
            IntentKind.CONTROL -> firstTouch(inp)
            IntentKind.INTERCEPT -> intercept(inp)
            IntentKind.CLEARANCE -> clearance(inp)
            else -> strike(inp)
        }
    }

    /** Trayectoria sin ruido para la previsualización del gesto. */
    fun previewTrajectory(inp: ResolveInput): Trajectory? {
        A = inp.attrs
        return when (inp.intent.kind) {
            IntentKind.CONTROL, IntentKind.INTERCEPT -> null
            else -> strikeTrajectory(inp, inp.intent.kind, false).traj
        }
    }

    // ------------------------------------------------------------------ golpeo + física
    private fun strikeTrajectory(inp: ResolveInput, kind: IntentKind, noisy: Boolean): Strike {
        val a = inp.attrs
        val prof = ActionProfiles.of(kind)
        val skill = skillFor(kind, a)
        val eff = inp.effect
        val z0 = if (kind == IntentKind.HEADER || kind == IntentKind.VOLLEY || kind == IntentKind.CHILENA)
            inp.ballZ.coerceAtLeast(0.3f) else max(prof.z0, inp.ballZ)
        val speedScale = 0.78f + 0.22f * powerAttr(kind, a)
        var speed = mix(prof.minSpeed, prof.maxSpeed * speedScale, inp.aim.power)
        speed *= (1f + eff.drive * 0.10f) * (0.88f + 0.12f * eff.stability)
        var dir = inp.aim.dir
        var elev = (prof.baseElev + eff.lift * prof.liftRange).coerceIn(prof.minElev, prof.maxElev)
        if (noisy) {
            val execQ = (inp.timing * inp.arrive).coerceIn(0.2f, 1f)
            var diff = 0f
            val inc = inp.moment.incoming
            if (inc != null) diff += 0.12f * (inc.speedAt(max(0f, inp.moment.timeWindow - 0.15f)) / 20f)
            if (inp.moment.type == KeyMomentType.VOLLEY_MOMENT) diff += 0.5f
            if (inp.moment.type == KeyMomentType.CHILENA_MOMENT) diff += 1.0f
            val sigma = (0.022f + (1f - skill) * 0.070f + inp.pressure * 0.035f) * prof.precision *
                (1f + (1f - eff.stability) * 1.4f) * (1f + diff) * (1f + (1f - execQ) * 1.5f)
            speed *= (1f + rng.gauss() * (0.03f + (1f - skill) * 0.07f))
            dir = dir.rot(rng.gauss() * sigma)
            elev += rng.gauss() * (0.015f + (1f - skill) * 0.05f) * (1f + (1f - eff.stability))
        }
        if (prof.minElev >= 0f) elev = max(0f, elev)
        val l = BallPhysics.launch(dir, max(3f, speed), elev, eff.curve)
        return Strike(BallPhysics.simulate(inp.ball, z0, l), inp.ball, skill)
    }

    private fun strike(inp: ResolveInput): ActionResult {
        val kind = inp.intent.kind
        val r = ActionResult(kind)
        val st = strikeTrajectory(inp, kind, true)
        val w = inp.world.copyOf()
        val goalDirected = st.traj.goalCross != null
        val isShot = kind == IntentKind.SHOT || kind == IntentKind.VOLLEY || kind == IntentKind.CHILENA ||
            (kind == IntentKind.HEADER && goalDirected)
        r.protagonistShot = isShot
        r.passAttempt = !isShot && kind != IntentKind.CROSS
        r.crossAttempt = kind == IntentKind.CROSS
        if (isShot) shotByPlayer(inp, r, w, st) else receive(inp, r, w, st, kind)
        return r
    }

    // ------------------------------------------------------------------ tiros
    private fun looseBall(at: Vec, outward: Boolean): Trajectory {
        val dir = if (outward) Vec(-1f, 0f).rot(rng.gauss() * 0.7f) else Vec(1f, 0f).rot(rng.nextFloat() * 6.283f)
        val l = BallPhysics.launch(dir, rf(4f, 10f), rf(0f, 0.35f), 0f)
        return BallPhysics.simulate(Vec(at.x.coerceIn(2f, 103f), at.y.coerceIn(2f, 66f)), 0.3f, l, 1.8f)
    }

    private fun evalShot(from: Vec, traj: Trajectory, shooterQ: Float, w: World): ShotEval {
        var blockT = -1f; var blockIdx = -1
        for (s in traj.samples) {
            if (s.t < 0.08f) continue
            if (hypot(s.x - from.x, s.y - from.y) > 14f) break
            if (s.z > 1.9f) continue
            for (i in w.rivals.indices) {
                val rv = w.rivals[i]
                if (hypot(s.x - rv.pos.x, s.y - rv.pos.y) < 1.0f + 0.4f * rv.quality) { blockT = s.t; blockIdx = i; break }
            }
            if (blockIdx >= 0) break
        }
        if (blockIdx >= 0 && rng.nextFloat() < (0.55f - shooterQ * 0.2f)) {
            val bs = traj.at(blockT)
            return ShotEval(ShotOutcome.BLOCKED, blockT, null, looseBall(Vec(bs.x, bs.y), false), "¡TIRO BLOQUEADO!", "Un defensor se interpone")
        }
        val g = traj.goalCross
            ?: return ShotEval(ShotOutcome.OFF_TARGET, traj.duration, null, null, "FUERA", "El balón se va desviado")
        val off = abs(g.y - Pitch.CENTER_Y)
        if (off > Pitch.GOAL_HALF + 0.25f || g.z > Pitch.CROSSBAR + 0.25f)
            return ShotEval(ShotOutcome.OFF_TARGET, g.t, null, null, if (g.z > Pitch.CROSSBAR) "POR ENCIMA" else "FUERA", "Se va desviado")
        if (off > Pitch.GOAL_HALF || g.z > Pitch.CROSSBAR)
            return ShotEval(ShotOutcome.POST, g.t, null, looseBall(Vec(104f, g.y), true), "¡AL PALO!", "Por centímetros")
        val kp = w.keeper
        val kq = kp?.quality ?: 0.5f
        val ky = kp?.pos?.y ?: Pitch.CENTER_Y
        val need = abs(g.y - ky)
        val dist = hypot(Pitch.LENGTH - from.x, Pitch.CENTER_Y - from.y)
        val reach = 1.2f + 3.0f * kq - (if (dist < 9f) 0.7f else 0f)
        val speedPen = ((g.speed - 16f) / 20f).coerceIn(0f, 0.6f)
        var p = if (need > reach) 0.04f else 0.95f * (1f - (need / reach).pow(1.6f))
        p *= (1f - speedPen * 0.55f)
        if (g.z > 1.9f) p *= 0.85f
        p = p.coerceIn(0.03f, 0.93f)
        val keeperTo = Vec(104f, g.y.coerceIn(Pitch.CENTER_Y - 3.4f, Pitch.CENTER_Y + 3.4f))
        if (rng.nextFloat() < p) {
            val parry = rng.nextFloat() < 0.35f + g.speed / 90f
            return if (parry) ShotEval(ShotOutcome.PARRIED, g.t, keeperTo, looseBall(Vec(103.4f, keeperTo.y), true), "¡PARADÓN!", "El portero rechaza")
            else ShotEval(ShotOutcome.SAVED, g.t, keeperTo, null, "¡PARADA!", "El portero la atrapa")
        }
        return ShotEval(ShotOutcome.GOAL, g.t, keeperTo, null, "¡GOOOL!", "")
    }

    private fun shotByPlayer(inp: ResolveInput, r: ActionResult, w: World, st: Strike) {
        val ev = evalShot(st.from, st.traj, st.skill, w)
        r.shotOutcome = ev.outcome
        r.quality = when (ev.outcome) {
            ShotOutcome.GOAL -> 0.9f; ShotOutcome.SAVED, ShotOutcome.PARRIED -> 0.6f
            ShotOutcome.POST -> 0.55f; ShotOutcome.BLOCKED -> 0.3f; else -> 0.15f
        } + st.skill * 0.1f
        r.success = ev.outcome == ShotOutcome.GOAL
        val moves = ArrayList<ActorMove>()
        val kt = ev.keeperTo
        if (kt != null && w.keeper != null) { moves.add(ActorMove(ActorKind.KEEPER, 0, kt)); w.keeper!!.pos = kt }
        endShotBeats(inp.moment.minute, r, w, ev, st.traj, true, moves, false, inp.moment.depth)
    }

    private fun endShotBeats(
        minute: Int, r: ActionResult, w: World, ev: ShotEval, traj: Trajectory, byPlayer: Boolean,
        moves: List<ActorMove>, assistable: Boolean, depth: Int
    ) {
        val goal = ev.outcome == ShotOutcome.GOAL
        val tone = when (ev.outcome) {
            ShotOutcome.GOAL -> Tone.GOAL
            ShotOutcome.OFF_TARGET, ShotOutcome.BLOCKED -> Tone.BAD
            else -> Tone.NEUTRAL
        }
        var detail = ev.detail
        if (!byPlayer) detail = when (ev.outcome) {
            ShotOutcome.GOAL -> if (assistable) "¡Asistencia tuya!" else "Tu compañero marca"
            ShotOutcome.OFF_TARGET -> "Tu compañero no acierta"
            ShotOutcome.SAVED, ShotOutcome.PARRIED -> "Tu compañero remata y el portero responde"
            else -> ev.detail
        }
        r.beats.add(Beat(traj.slice(ev.endT), ev.label, detail, tone, moves, if (goal) 1.7f else 0.95f, goal))
        if (!byPlayer) r.teamShot = true
        if (ev.outcome != ShotOutcome.OFF_TARGET) r.chanceCreated = true
        when (ev.outcome) {
            ShotOutcome.GOAL -> {
                r.teamGoal = true
                if (byPlayer) r.goalByPlayer = true else if (assistable) r.assist = true
            }
            ShotOutcome.BLOCKED, ShotOutcome.POST, ShotOutcome.PARRIED -> afterLoose(minute, r, w, ev.rebound, depth)
            else -> {}
        }
    }

    // ------------------------------------------------------------------ balón suelto (rebotes)
    private fun firstReach(traj: Trajectory, pos: Vec, speed: Float, radius: Float, delay: Float, maxZ: Float, who: Int, idx: Int): Reach? {
        for (s in traj.samples) {
            if (s.t < 0.25f || s.z > maxZ) continue
            val d = hypot(s.x - pos.x, s.y - pos.y)
            val avail = max(0f, s.t - delay) * speed + radius
            if (d <= avail) return Reach(who, idx, s.t, Vec(s.x, s.y), s.z, avail - d)
        }
        return null
    }

    private fun afterLoose(minute: Int, r: ActionResult, w: World, reb: Trajectory?, depth: Int) {
        if (reb == null) return
        val cand = ArrayList<Reach>()
        val pr = firstReach(reb, w.player, PositioningPhase.runSpeed(A) * 0.95f, 2.0f, 0.15f, 1.5f, 0, -1)
        if (pr != null) cand.add(pr)
        for (i in w.mates.indices) {
            val m = w.mates[i]
            firstReach(reb, m.pos, m.speed(), 1.2f, 0.2f, 1.5f, 1, i)?.let { cand.add(it) }
        }
        for (i in w.rivals.indices) {
            val rv = w.rivals[i]
            firstReach(reb, rv.pos, rv.speed(), 1.2f, 0.2f, 1.5f, 2, i)?.let { cand.add(it) }
        }
        var first: Reach? = null
        for (c in cand) if (first == null || c.t < first.t) first = c
        if (pr != null && first != null && pr.t <= first.t + 0.35f) first = pr
        if (first == null) {
            r.beats.add(Beat(reb.samples, "BALÓN SUELTO", "Nadie llega", Tone.NEUTRAL, emptyList(), 0.5f))
            return
        }
        when (first.who) {
            0 -> {
                val sp = gen.reboundMoment(w, reb, minute, depth + 1)
                if (sp != null) {
                    r.beats.add(Beat(reb.slice(sp.startT), "¡REBOTE!", "", Tone.NEUTRAL, emptyList(), 0.15f))
                    r.next = sp.moment; r.rebound = true; r.chanceCreated = true
                } else r.beats.add(Beat(reb.samples, "BALÓN SUELTO", "", Tone.NEUTRAL, emptyList(), 0.4f))
            }
            1 -> {
                r.beats.add(Beat(reb.slice(first.t), "REBOTE", "Un compañero llega primero", Tone.NEUTRAL,
                    listOf(ActorMove(ActorKind.MATE, first.idx, first.pos)), 0.3f))
                w.mates[first.idx].pos = first.pos
                if (depth < 2) mateShoot(r, w, first.idx, first.pos, Chain(minute, depth + 1, false, 0f, false))
            }
            else -> {
                r.beats.add(Beat(reb.slice(first.t), "EL RIVAL DESPEJA", "", Tone.BAD,
                    listOf(ActorMove(ActorKind.RIVAL, first.idx, first.pos)), 0.8f))
                r.turnover = true
                r.opponentThreat = max(r.opponentThreat, 0.06f)
            }
        }
    }

    // ------------------------------------------------------------------ pases / centros
    private fun threatAt(p: Vec): Float = (0.07f + (1f - p.x / Pitch.LENGTH) * 0.30f).coerceIn(0.05f, 0.4f)

    private fun receive(inp: ResolveInput, r: ActionResult, w: World, st: Strike, kind: IntentKind) {
        val traj = st.traj
        val aerial = kind == IntentKind.CROSS
        val target = inp.intent.mate
        val tIdx = if (target == null) -1 else inp.world.mates.indexOfFirst { it.id == target.id }
        val maxZ = if (aerial) 2.4f else 1.15f
        val reaches = ArrayList<Reach>()
        for (i in w.mates.indices) {
            val m = w.mates[i]
            val boost = i == tIdx
            val sp = m.speed() * (if (boost) 1.2f else 1f)
            val rad = if (boost) 1.7f else 1.0f + 0.7f * m.quality
            for (s in traj.samples) {
                if (s.t < 0.25f || s.z > maxZ) continue
                val adv = min(m.speed() * 0.9f * s.t, m.pos.dist(m.run))
                val rp = m.pos + (m.run - m.pos).norm() * adv
                val d = hypot(s.x - rp.x, s.y - rp.y)
                val avail = rad + sp * 0.55f * max(0f, s.t - 0.3f)
                if (d <= avail) { reaches.add(Reach(1, i, s.t, Vec(s.x, s.y), s.z, avail - d)); break }
            }
        }
        for (i in w.rivals.indices) {
            val rv = w.rivals[i]
            firstReach(traj, rv.pos, rv.speed(), 1.0f + 0.6f * rv.quality, 0.25f, maxZ, 2, i)?.let { reaches.add(it) }
        }
        val passAcc = passAccuracy(traj, inp.intent)
        val minute = inp.moment.minute
        for (rc in reaches.sortedBy { it.t }) {
            if (rc.who == 2) {
                val rv = w.rivals[rc.idx]
                var p = 0.30f + 0.45f * rv.quality + 0.15f * (rc.margin.coerceIn(0f, 3f) / 3f)
                if (rc.z > 1.15f) p *= 0.8f
                p = p.coerceIn(0.1f, 0.85f)
                if (rng.nextFloat() < p) {
                    r.turnover = true; r.quality = 0.1f
                    r.opponentThreat = threatAt(rc.pos)
                    r.beats.add(Beat(traj.slice(rc.t), if (aerial) "DESPEJA LA DEFENSA" else "PASE INTERCEPTADO",
                        "Pierdes la posesión", Tone.BAD, listOf(ActorMove(ActorKind.RIVAL, rc.idx, rc.pos)), 0.95f))
                    return
                }
            } else {
                val m = w.mates[rc.idx]
                val press = OpponentAI.pressureAt(m.pos, w.rivals)
                val spd = traj.speedAt(rc.t)
                var pc = 0.45f + 0.40f * m.quality + 0.12f * (rc.margin.coerceIn(0f, 3f) / 3f) + 0.15f * passAcc
                pc -= 0.25f * ((spd - 20f) / 10f).coerceIn(0f, 1f)
                pc -= 0.15f * press
                if (aerial) pc -= 0.05f
                pc = pc.coerceIn(0.15f, 0.97f)
                val moves = listOf(ActorMove(ActorKind.MATE, rc.idx, rc.pos))
                if (rng.nextFloat() < pc) {
                    r.success = true
                    r.passCompleted = !aerial
                    r.quality = (passAcc * 0.5f + st.skill * 0.5f).coerceIn(0.1f, 1f)
                    val forward = rc.pos.x - inp.ball.x > 8f
                    val head = when {
                        aerial -> "¡BUEN CENTRO!"
                        inp.intent.toSpace -> "PASE AL ESPACIO"
                        forward -> "PASE AL FRENTE"
                        else -> "PASE COMPLETADO"
                    }
                    r.beats.add(Beat(traj.slice(rc.t), head, "", Tone.GOOD, moves, 0.35f))
                    val m2 = w.mates[rc.idx]
                    m2.pos = rc.pos
                    mateAct(r, w, rc.idx, rc.pos, Chain(minute, inp.moment.depth, true, inp.ball.dist(rc.pos), aerial))
                } else {
                    r.turnover = true; r.quality = 0.15f
                    r.opponentThreat = threatAt(rc.pos)
                    r.beats.add(Beat(traj.slice(rc.t), "MAL CONTROL", "Tu compañero no domina el balón", Tone.BAD, moves, 0.95f))
                }
                return
            }
        }
        r.turnover = true; r.quality = 0.1f
        r.opponentThreat = threatAt(traj.endPos) * 0.6f
        r.beats.add(Beat(traj.samples, if (traj.outOfPlay) "SE VA FUERA" else "PASE SIN DESTINO", "Pierdes la posesión", Tone.BAD, emptyList(), 0.95f))
    }

    private fun passAccuracy(traj: Trajectory, intent: ActionIntent): Float {
        var best = 99f
        for (s in traj.samples) best = min(best, hypot(s.x - intent.target.x, s.y - intent.target.y))
        return (1f - best / 5f).coerceIn(0f, 1f)
    }

    // ------------------------------------------------------------------ cadena del compañero
    private fun mateAct(r: ActionResult, w: World, mi: Int, at: Vec, ch: Chain) {
        val m = w.mates[mi]
        val press = OpponentAI.pressureAt(m.pos, w.rivals)
        val free = OpponentAI.pressureAt(w.player, w.rivals) < 0.65f
        val dec = if (ch.aerial) TeammateAI.Decision.SHOOT
        else TeammateAI.decide(m, TeammateAI.Ctx(at, press, ch.fromPlayer, ch.passDist, w.player, free, ch.depth, w.mates.size > 1), rng)
        when (dec) {
            TeammateAI.Decision.SHOOT -> mateShoot(r, w, mi, at, ch)
            TeammateAI.Decision.RETURN -> mateReturn(r, w, mi, at, ch)
            TeammateAI.Decision.PASS_OTHER -> matePassOther(r, w, mi, at, ch)
            TeammateAI.Decision.CROSS -> mateCross(r, w, mi, at, ch)
            TeammateAI.Decision.LOSE -> mateLose(r, w, mi, at, ch)
        }
    }

    private fun mateShoot(r: ActionResult, w: World, mi: Int, at: Vec, ch: Chain) {
        val m = w.mates[mi]
        val kp = w.keeper
        val ky = kp?.pos?.y ?: Pitch.CENTER_Y
        val side = if (ky >= Pitch.CENTER_Y) -1f else 1f
        val tgtY = Pitch.CENTER_Y + side * (1.6f + rng.nextFloat() * 1.7f)
        val dir = Vec(Pitch.LENGTH - at.x, tgtY - at.y).norm()
        val press = OpponentAI.pressureAt(m.pos, w.rivals)
        val sigma = (0.03f + (1f - m.quality) * 0.09f + press * 0.03f) * (if (ch.aerial) 1.5f else 1f)
        val speed = 17f + rng.nextFloat() * 10f + m.quality * 4f
        val elev = 0.04f + abs(rng.gauss()) * 0.05f * (1.2f - m.quality)
        val l = BallPhysics.launch(dir.rot(rng.gauss() * sigma), speed, elev, 0f)
        val traj = BallPhysics.simulate(at, if (ch.aerial) 1.8f else 0.15f, l)
        val ev = evalShot(at, traj, m.quality, w)
        val moves = ArrayList<ActorMove>()
        val kt = ev.keeperTo
        if (kt != null && w.keeper != null) { moves.add(ActorMove(ActorKind.KEEPER, 0, kt)); w.keeper!!.pos = kt }
        endShotBeats(ch.minute, r, w, ev, traj, false, moves, ch.fromPlayer && ch.depth <= 1, ch.depth)
    }

    private fun mateReturn(r: ActionResult, w: World, mi: Int, at: Vec, ch: Chain) {
        val m = w.mates[mi]
        val press = OpponentAI.pressureAt(m.pos, w.rivals)
        val ok = (0.55f + 0.35f * m.quality - 0.25f * press).coerceIn(0.2f, 0.95f)
        val p = w.player
        val fwd = Vec(Pitch.LENGTH - p.x, Pitch.CENTER_Y - p.y).norm()
        val side = fwd.rot(1.5708f) * rf(-2.5f, 2.5f)
        val ahead = Geo.clampPitch(p + fwd * rf(5f, 9f) + side)
        val t = rf(0.95f, 1.4f)
        if (rng.nextFloat() >= ok) {
            val astray = Geo.clampPitch(ahead + Vec(rf(-9f, 9f), rf(-9f, 9f)))
            val tr = Trajectory.arc(at, astray, 0.1f, 0.1f, 0f, t, true)
            r.turnover = true
            r.opponentThreat = threatAt(astray)
            r.beats.add(Beat(tr.samples, "PARED FALLIDA", "La devolución se pierde", Tone.BAD, emptyList(), 0.95f))
            return
        }
        val traj = Trajectory.arc(at, ahead, 0.1f, 0.1f, if (rng.nextFloat() < 0.3f) 0.7f else 0f, t, true)
        val newPlayer = Geo.clampPitch(ahead - fwd * rf(1.0f, 2.4f))
        w.player = newPlayer
        val first = traj.samples[0]
        r.beats.add(Beat(listOf(BallSample(0f, first.x, first.y, first.z)), "¡PARED!", "Te devuelven el balón", Tone.GOOD,
            listOf(ActorMove(ActorKind.PLAYER, 0, newPlayer)), 0.45f))
        val mm = gen.oneTwoMoment(w, traj, ahead, ch.minute, ch.depth + 1)
        if (mm != null) { r.next = mm; r.oneTwo = true; r.chanceCreated = true }
    }

    private fun matePassOther(r: ActionResult, w: World, mi: Int, at: Vec, ch: Chain) {
        val m = w.mates[mi]
        val press = OpponentAI.pressureAt(m.pos, w.rivals)
        var j = -1; var bs = -1e9f
        for (i in w.mates.indices) {
            if (i == mi) continue
            val o = w.mates[i]
            val s = o.pos.x + TeammateAI.openness(o, w.rivals) * 10f
            if (s > bs) { bs = s; j = i }
        }
        if (j < 0) { mateLose(r, w, mi, at, ch); return }
        val o = w.mates[j]
        val to = Geo.clampPitch(o.pos + (o.run - o.pos).norm() * 3f)
        val ok = (0.5f + 0.4f * m.quality - 0.3f * press).coerceIn(0.15f, 0.92f)
        val tr = Trajectory.arc(at, to, 0.1f, 0.1f, 0f, rf(0.8f, 1.3f), true)
        if (rng.nextFloat() < ok) {
            r.beats.add(Beat(tr.samples, "PASE DEL COMPAÑERO", "", Tone.NEUTRAL, listOf(ActorMove(ActorKind.MATE, j, to)), 0.3f))
            o.pos = to
            if (ch.depth < 2) mateShoot(r, w, j, to, Chain(ch.minute, ch.depth + 1, false, 0f, false))
        } else {
            r.turnover = true; r.opponentThreat = threatAt(at)
            r.beats.add(Beat(tr.samples, "PASE FALLIDO", "Tu compañero pierde el balón", Tone.BAD, emptyList(), 0.95f))
        }
    }

    private fun mateCross(r: ActionResult, w: World, mi: Int, at: Vec, ch: Chain) {
        val m = w.mates[mi]
        val press = OpponentAI.pressureAt(m.pos, w.rivals)
        val pOk = (0.35f + 0.5f * m.quality - 0.25f * press).coerceIn(0.1f, 0.9f)
        val good = rng.nextFloat() < pOk
        val tgt = Vec(rf(93f, 99f), rf(28f, 40f))
        val land = if (good) tgt else Vec(rf(80f, 100f), rf(10f, 58f))
        val traj = Trajectory.arc(at, land, 0.2f, 1.6f, 4.5f, rf(1.3f, 1.8f), false)
        val playerInBox = w.player.x > 86f && abs(w.player.y - Pitch.CENTER_Y) < 22f
        if (good && playerInBox && ch.depth < 2) {
            val sp = gen.headerFromCross(w, traj, ch.minute, ch.depth + 1)
            if (sp != null) {
                r.beats.add(Beat(traj.slice(sp.startT), "¡CENTRO!", "", Tone.NEUTRAL, emptyList(), 0.1f))
                r.next = sp.moment; r.chanceCreated = true
                return
            }
        }
        r.beats.add(Beat(traj.samples, "¡CENTRO!", "", Tone.NEUTRAL, emptyList(), 0.3f))
        if (good) {
            var si = -1; var bx = -1f
            for (i in w.mates.indices) if (i != mi && w.mates[i].pos.x > bx) { bx = w.mates[i].pos.x; si = i }
            if (si >= 0 && ch.depth < 2) {
                w.mates[si].pos = land
                mateShoot(r, w, si, land, Chain(ch.minute, ch.depth + 1, false, 0f, true))
                return
            }
        }
        r.turnover = true; r.opponentThreat = threatAt(land) * 0.5f
        r.beats.add(Beat(listOf(BallSample(0f, land.x, land.y, 0.1f)), "CENTRO DESPEJADO", "", Tone.BAD, emptyList(), 0.8f))
    }

    private fun mateLose(r: ActionResult, w: World, mi: Int, at: Vec, ch: Chain) {
        r.turnover = true
        r.opponentThreat = threatAt(at)
        val ri = OpponentAI.nearest(at, w.rivals)
        val mv = if (ri >= 0) listOf(ActorMove(ActorKind.RIVAL, ri, at)) else emptyList()
        r.beats.add(Beat(listOf(BallSample(0f, at.x, at.y, 0.1f)), "PIERDE EL BALÓN", "Tu compañero es presionado", Tone.BAD, mv, 0.95f))
    }

    // ------------------------------------------------------------------ despeje
    private fun clearance(inp: ResolveInput): ActionResult {
        val r = ActionResult(IntentKind.CLEARANCE)
        r.clearanceDone = true
        val w = inp.world.copyOf()
        val st = strikeTrajectory(inp, IntentKind.CLEARANCE, true)
        val traj = st.traj
        val end = traj.endPos
        val side = traj.outOfPlay && (end.y <= 0.5f || end.y >= Pitch.WIDTH - 0.5f)
        val ownLine = traj.outOfPlay && end.x <= 0.5f
        val farOut = traj.outOfPlay && end.x >= Pitch.LENGTH - 0.5f
        var good = side || farOut || (!traj.outOfPlay && end.x > 32f)
        if (ownLine) good = false
        r.success = good
        r.quality = ((end.x / 60f).coerceIn(0f, 1f) * 0.5f + st.skill * 0.5f).coerceIn(0.1f, 1f)
        if (good) {
            r.beats.add(Beat(traj.samples, if (side) "¡DESPEJE A BANDA!" else "¡DESPEJE!", "Alejas el peligro", Tone.GOOD, emptyList(), 1.0f))
            if (!traj.outOfPlay) r.opponentThreat = 0.04f
        } else {
            val head = if (ownLine) "CÓRNER EN CONTRA" else "DESPEJE CORTO"
            r.opponentThreat = 0.22f + (1f - (end.x / 35f).coerceIn(0f, 1f)) * 0.12f
            val inbox = !traj.outOfPlay && inp.moment.depth < 2 && rng.nextFloat() < 0.5f
            val sp = if (inbox) gen.clearanceLoose(w, traj, inp.moment.minute, inp.moment.depth + 1) else null
            if (sp != null) {
                r.beats.add(Beat(traj.slice(sp.startT), head, "El balón sigue en la zona", Tone.BAD, emptyList(), 0.4f))
                r.next = sp.moment
            } else r.beats.add(Beat(traj.samples, head, "El balón sigue en la zona", Tone.BAD, emptyList(), 0.95f))
        }
        return r
    }

    // ------------------------------------------------------------------ intercepción
    private fun intercept(inp: ResolveInput): ActionResult {
        val r = ActionResult(IntentKind.INTERCEPT)
        val m = inp.moment
        val inc = m.incoming
        val cp = m.contact
        val w = inp.world.copyOf()
        if (inc == null || cp == null) { r.beats.add(Beat(emptyList<BallSample>().ifEmpty { listOf(BallSample(0f, w.player.x, w.player.y, 0f)) }, "NO LLEGAS", "", Tone.BAD, emptyList(), 0.8f)); return r }
        val dir = inp.aim.dir
        val reachDist = 1.5f + inp.aim.power * 6.5f
        val end = w.player + dir * reachDist
        var near = inc.samples[0]; var bd = 1e9f
        for (s in inc.samples) { val d = hypot(s.x - end.x, s.y - end.y); if (d < bd && s.z < 1.8f) { bd = d; near = s } }
        val reachR = 1.4f + (A.positioning + A.decisions) / 200f * 1.4f + A.control / 100f * 0.4f
        val sp = PositioningPhase.runSpeed(A) * (0.7f + 0.3f * inp.aim.power)
        val tPlayer = w.player.dist(end) / max(1f, sp)
        val okGeo = bd <= reachR && tPlayer <= near.t + 0.25f + rng.gauss() * 0.08f
        val execQ = (inp.timing * inp.arrive).coerceIn(0.2f, 1f)
        val ok = okGeo && rng.nextFloat() < (0.6f + 0.4f * execQ)
        val nearPos = Vec(near.x, near.y)
        r.interception = ok
        if (!ok) {
            r.quality = 0.1f
            r.opponentThreat = 0.06f + (1f - w.player.x / Pitch.LENGTH) * 0.25f
            val ri = OpponentAI.nearest(Vec(inc.endPos.x, inc.endPos.y), w.rivals)
            val mv = ArrayList<ActorMove>()
            mv.add(ActorMove(ActorKind.PLAYER, 0, end))
            if (ri >= 0) mv.add(ActorMove(ActorKind.RIVAL, ri, inc.endPos))
            r.beats.add(Beat(inc.samples, "NO LLEGAS", "El balón sigue su camino", Tone.BAD, mv, 0.95f))
            return r
        }
        r.success = true
        r.quality = (1f - bd / reachR).coerceIn(0.2f, 1f)
        val clean = rng.nextFloat() < (0.45f + 0.5f * (A.control / 100f) * (0.6f + 0.4f * execQ))
        val moves = listOf(ActorMove(ActorKind.PLAYER, 0, nearPos))
        if (clean) {
            r.beats.add(Beat(inc.slice(near.t), "¡INTERCEPTADO!", "Recuperas la posesión", Tone.GOOD, moves, 0.5f))
            w.player = nearPos
            val nm = gen.passAfterIntercept(w, nearPos, m.minute, m.depth + 1)
            if (nm != null) r.next = nm
        } else {
            r.beats.add(Beat(inc.slice(near.t), "¡TE ADELANTAS!", "Desvías el balón", Tone.GOOD, moves, 0.9f))
            if (rng.nextFloat() < 0.5f) r.opponentThreat = 0.05f
        }
        return r
    }

    // ------------------------------------------------------------------ primer toque
    private fun firstTouch(inp: ResolveInput): ActionResult {
        val r = ActionResult(IntentKind.CONTROL)
        val m = inp.moment
        val w = inp.world.copyOf()
        val dir = inp.aim.dir
        val touchLen = 0.8f + inp.aim.power * 4.2f
        val skill = (A.control * 0.5f + A.composure * 0.2f + A.dribbling * 0.15f + A.decisions * 0.15f) / 100f
        val inc = m.incoming
        val incSpeed = inc?.speedAt(max(0f, m.timeWindow - 0.15f)) ?: 8f
        val diff = 0.18f * (incSpeed / 20f) + inp.pressure * 0.35f
        val score = skill * 0.9f * inp.timing * inp.arrive - diff + 0.22f + rng.gauss() * 0.08f
        val here = w.player
        val newPos = Geo.clampPitch(here + dir * touchLen * (if (score > 0.18f) 1f else 1.6f))
        val moves = listOf(ActorMove(ActorKind.PLAYER, 0, newPos))
        val head = inc?.samples ?: listOf(BallSample(0f, here.x, here.y, 0.1f))
        if (score > 0.18f) {
            r.success = true; r.quality = score.coerceIn(0.2f, 1f)
            r.beats.add(Beat(head, if (score > 0.5f) "¡BUEN CONTROL!" else "CONTROL", "", Tone.GOOD, moves, 0.4f))
            w.player = newPos
            val forward = dir.x
            val nm = gen.afterFirstTouch(w, newPos, m.minute, forward, forward < -0.2f, m.depth + 1)
            if (nm != null) r.next = nm
        } else if (score > -0.1f) {
            r.beats.add(Beat(head, "TOQUE LARGO", "El balón se escapa", Tone.BAD, moves, 0.9f))
            if (rng.nextFloat() < 0.5f) { r.turnover = true; r.opponentThreat = threatAt(newPos) }
            else {
                w.player = newPos
                val nm = gen.afterFirstTouch(w, newPos, m.minute, 1f, false, m.depth + 1)
                if (nm != null) r.next = nm else r.turnover = true
            }
        } else {
            r.turnover = true; r.quality = 0.05f
            r.opponentThreat = threatAt(here)
            r.beats.add(Beat(head, "MAL CONTROL", "Pierdes el balón", Tone.BAD, moves, 0.95f))
        }
        return r
    }
}
