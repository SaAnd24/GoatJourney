package com.goatjourney.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import com.goatjourney.core.career.CareerFactory
import com.goatjourney.core.career.CareerState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(tableName = "career_save")
data class CareerSaveEntity(
    @PrimaryKey val id: Int = 1,
    val saveVersion: Int,
    val timestamp: Long,
    val careerStateJson: String
)

@Dao
interface CareerSaveDao {
    @Query("SELECT * FROM career_save WHERE id = 1")
    suspend fun get(): CareerSaveEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: CareerSaveEntity)

    @Query("DELETE FROM career_save")
    suspend fun clear()
}

@Database(entities = [CareerSaveEntity::class], version = 1, exportSchema = false)
abstract class GameDatabase : RoomDatabase() {
    abstract fun careerDao(): CareerSaveDao

    companion object {
        fun build(ctx: Context): GameDatabase =
            Room.databaseBuilder(ctx.applicationContext, GameDatabase::class.java, "goat_journey.db").build()
    }
}

/** Guardado de carrera: estado serializado y versionado dentro de una única fila de Room. */
class SaveSystem(ctx: Context) {
    private val dao = GameDatabase.build(ctx).careerDao()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(state: CareerState): String = json.encodeToString(state)

    suspend fun saveJson(jsonText: String) {
        dao.upsert(CareerSaveEntity(1, CareerFactory.SAVE_VERSION, System.currentTimeMillis(), jsonText))
    }

    suspend fun hasSave(): Boolean = dao.get() != null

    suspend fun load(): CareerState? {
        val e = dao.get() ?: return null
        return try { json.decodeFromString<CareerState>(migrate(e.careerStateJson, e.saveVersion)) } catch (ex: Exception) { null }
    }

    suspend fun delete() = dao.clear()

    /** Punto de migración: cuando cambie el modelo, transforma el JSON antiguo aquí según [fromVersion]. */
    private fun migrate(jsonText: String, fromVersion: Int): String = jsonText
}

data class Settings(val music: Boolean = true, val sfx: Boolean = true, val vibration: Boolean = true)

private val Context.dataStore by preferencesDataStore(name = "settings")

/** DataStore: SOLO preferencias (nunca la carrera). */
class SettingsStore(private val ctx: Context) {
    private val kMusic = booleanPreferencesKey("music")
    private val kSfx = booleanPreferencesKey("sfx")
    private val kVib = booleanPreferencesKey("vibration")

    val flow: Flow<Settings> = ctx.dataStore.data.map {
        Settings(it[kMusic] ?: true, it[kSfx] ?: true, it[kVib] ?: true)
    }

    suspend fun save(s: Settings) {
        ctx.dataStore.edit { it[kMusic] = s.music; it[kSfx] = s.sfx; it[kVib] = s.vibration }
    }
}
