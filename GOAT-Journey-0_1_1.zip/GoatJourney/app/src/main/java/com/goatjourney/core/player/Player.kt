package com.goatjourney.core.player

import kotlinx.serialization.Serializable
import kotlin.math.roundToInt

@Serializable
enum class Position(val label: String, val short: String) {
    CENTER_BACK("Defensa central", "DFC"),
    FULL_BACK("Lateral", "LAT"),
    MIDFIELDER("Mediocampista", "MED"),
    WINGER("Extremo", "EXT"),
    STRIKER("Delantero", "DEL")
}

@Serializable
enum class Foot(val label: String) { RIGHT("Derecho"), LEFT("Izquierdo"), BOTH("Ambidiestro") }

@Serializable
data class Attributes(
    var passing: Int, var control: Int, var dribbling: Int, var crossing: Int, var shooting: Int, var finishing: Int,
    var speed: Int, var acceleration: Int, var strength: Int, var endurance: Int,
    var vision: Int, var decisions: Int, var composure: Int, var positioning: Int
) {
    fun toArray(): IntArray = intArrayOf(
        passing, control, dribbling, crossing, shooting, finishing,
        speed, acceleration, strength, endurance,
        vision, decisions, composure, positioning
    )

    companion object {
        /** Orden canónico de los atributos (técnicos 0-5, físicos 6-9, mentales 10-13). */
        val NAMES = listOf(
            "Pase", "Control", "Regate", "Centro", "Disparo", "Definición",
            "Velocidad", "Aceleración", "Fuerza", "Resistencia",
            "Visión", "Decisiones", "Sangre fría", "Posicionamiento"
        )

        fun fromArray(a: IntArray) = Attributes(
            a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11], a[12], a[13]
        )
    }
}

@Serializable
data class Appearance(val skin: Int = 0, val hair: Int = 0, val hairStyle: Int = 0, val shirt: Int = 0) {
    companion object {
        val SKINS = intArrayOf(
            0xFFFBD5B5.toInt(), 0xFFEAB98C.toInt(), 0xFFC98E5F.toInt(),
            0xFFA46A3F.toInt(), 0xFF7A4A28.toInt(), 0xFF4E2E1A.toInt()
        )
        val HAIRS = intArrayOf(
            0xFF1A1208.toInt(), 0xFF4A2C12.toInt(), 0xFF8B5A2B.toInt(),
            0xFFD9B35B.toInt(), 0xFFB5381E.toInt(), 0xFFE8E8E8.toInt()
        )
        /** Color de mangas / botines (acento personal; la camiseta usa los colores del club). */
        val ACCENTS = intArrayOf(
            0xFFFFC857.toInt(), 0xFFFF5470.toInt(), 0xFF2EE6A6.toInt(), 0xFFFFFFFF.toInt(),
            0xFF5AB0FF.toInt(), 0xFFB26BFF.toInt(), 0xFFFF9A3C.toInt(), 0xFF222222.toInt()
        )
        val HAIR_STYLE_NAMES = listOf("Corto", "Plano", "Largo", "Rapado")
    }
}

@Serializable
data class Player(
    val name: String,
    val surname: String,
    var age: Int,
    val nationality: String,
    val preferredFoot: Foot,
    val position: Position,
    var overall: Int,
    var attributes: Attributes,
    val shirtNumber: Int,
    var clubId: Int,
    val appearance: Appearance
) {
    fun fullName() = "$name $surname"
}

@Serializable
data class PlayerStats(
    var matches: Int = 0, var starts: Int = 0, var minutes: Int = 0,
    var goals: Int = 0, var assists: Int = 0, var shots: Int = 0, var shotsOnTarget: Int = 0,
    var passesAttempted: Int = 0, var passesCompleted: Int = 0,
    var dribblesAttempted: Int = 0, var dribblesCompleted: Int = 0,
    var crosses: Int = 0, var interceptions: Int = 0, var clearances: Int = 0,
    var matchRatings: MutableList<Float> = mutableListOf()
) {
    fun averageRating(): Float = if (matchRatings.isEmpty()) 0f else matchRatings.sum() / matchRatings.size

    fun add(o: PlayerStats) {
        matches += o.matches; starts += o.starts; minutes += o.minutes
        goals += o.goals; assists += o.assists; shots += o.shots; shotsOnTarget += o.shotsOnTarget
        passesAttempted += o.passesAttempted; passesCompleted += o.passesCompleted
        dribblesAttempted += o.dribblesAttempted; dribblesCompleted += o.dribblesCompleted
        crosses += o.crosses; interceptions += o.interceptions; clearances += o.clearances
        matchRatings.addAll(o.matchRatings)
    }
}

/** OVR calculado a partir de atributos y posición. Para añadir una posición: añade su fila de pesos. */
object OvrCalculator {
    // Orden: pas, ctl, dri, cro, sho, fin, spd, acc, str, end, vis, dec, com, pos
    private val WEIGHTS: Map<Position, IntArray> = mapOf(
        Position.CENTER_BACK to intArrayOf(3, 3, 1, 0, 0, 0, 4, 3, 6, 4, 2, 5, 4, 6),
        Position.FULL_BACK to intArrayOf(4, 4, 4, 5, 1, 0, 6, 5, 3, 5, 3, 4, 3, 4),
        Position.MIDFIELDER to intArrayOf(6, 5, 4, 2, 3, 1, 3, 3, 3, 5, 6, 5, 4, 4),
        Position.WINGER to intArrayOf(3, 5, 7, 5, 4, 3, 6, 6, 2, 3, 3, 3, 3, 2),
        Position.STRIKER to intArrayOf(2, 5, 4, 1, 6, 8, 5, 5, 4, 2, 2, 3, 5, 5)
    )

    fun weights(p: Position): IntArray = WEIGHTS.getValue(p)

    fun fromArray(a: IntArray, p: Position): Int {
        val w = weights(p)
        var s = 0; var t = 0
        for (i in a.indices) { s += a[i] * w[i]; t += w[i] }
        return (s.toFloat() / t).roundToInt().coerceIn(1, 100)
    }

    fun calculate(a: Attributes, p: Position): Int = fromArray(a.toArray(), p)
}

object PlayerFactory {
    /** Genera atributos coherentes con la posición cuyo OVR calculado coincide con [target]. */
    fun generateAttributes(position: Position, target: Int): Attributes {
        val w = OvrCalculator.weights(position)
        val avg = w.average().toFloat()
        var base = target.toFloat()
        val arr = IntArray(14)
        for (iter in 0 until 60) {
            for (i in 0 until 14) arr[i] = (base + (w[i] - avg) * 1.6f).roundToInt().coerceIn(1, 99)
            val ovr = OvrCalculator.fromArray(arr, position)
            if (ovr == target) break
            base += (target - ovr) * 0.5f
        }
        return Attributes.fromArray(arr)
    }

    fun create(
        name: String, surname: String, nationality: String, foot: Foot, position: Position,
        shirtNumber: Int, appearance: Appearance, clubId: Int
    ): Player {
        val attrs = generateAttributes(position, 45)
        return Player(
            name, surname, 15, nationality, foot, position,
            OvrCalculator.calculate(attrs, position), attrs, shirtNumber, clubId, appearance
        )
    }
}
