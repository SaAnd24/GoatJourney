package com.goatjourney.game

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.MotionEvent
import com.goatjourney.core.career.CareerManager
import com.goatjourney.core.career.CareerFactory
import com.goatjourney.core.career.CareerState
import com.goatjourney.core.player.Player
import com.goatjourney.core.simulation.MatchMode
import com.goatjourney.core.simulation.MatchResult
import com.goatjourney.core.simulation.MatchSimulationEngine
import com.goatjourney.data.SaveSystem
import com.goatjourney.data.Settings
import com.goatjourney.data.SettingsStore
import com.goatjourney.input.GestureListener
import com.goatjourney.input.GestureProcessor
import com.goatjourney.input.TouchInput
import com.goatjourney.rendering.*
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue

enum class GameState {
    TITLE, CREATION, CAREER, PLAYER, CALENDAR, MATCH_PREVIEW,
    MATCH_SIMULATION, MATCH_OPPORTUNITY, MATCH_RESULT, TABLE, SETTINGS
}

/**
 * Dueño del estado del juego y del game loop lógico:
 *   updateInput -> updateTransition -> screen.update (simulación + animaciones) -> render
 */
class GameController(val context: Context) {
    val viewport = Viewport()
    val ui = UI()
    val touch = TouchInput()
    private val saves = SaveSystem(context.applicationContext)
    private val settingsStore = SettingsStore(context.applicationContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val actions = ConcurrentLinkedQueue<() -> Unit>()

    @Volatile var settings = Settings(); private set
    @Volatile var hasSave = false; private set
    val feedback = Feedback(context.applicationContext) { settings }

    var career: CareerState? = null
    var state = GameState.TITLE; private set
    lateinit var lastResult: MatchResult
    val matchScreen = MatchScreen(this)

    private val screens = HashMap<GameState, ScreenRenderer>()
    private lateinit var current: ScreenRenderer

    // transición: 0 = ninguna, 1 = fundido de salida, 2 = fundido de entrada
    private var transPhase = 0
    private var transT = 0f
    private var nextState = GameState.TITLE

    private val gestures = GestureProcessor(object : GestureListener {
        override fun onDown(x: Float, y: Float) = current.onDown(x, y)
        override fun onTap(x: Float, y: Float) = current.onTap(x, y)
        override fun onDragStart(x: Float, y: Float) = current.onDragStart(x, y)
        override fun onDrag(x: Float, y: Float, startX: Float, startY: Float) = current.onDrag(x, y, startX, startY)
        override fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) = current.onRelease(x, y, startX, startY, dragged)
        override fun onLongPress(x: Float, y: Float) = current.onLongPress(x, y)
    })

    init {
        screens[GameState.TITLE] = TitleScreen(this)
        screens[GameState.CREATION] = CreationScreen(this)
        screens[GameState.CAREER] = CareerScreen(this)
        screens[GameState.PLAYER] = PlayerScreen(this)
        screens[GameState.CALENDAR] = CalendarScreen(this)
        screens[GameState.MATCH_PREVIEW] = MatchPreviewScreen(this)
        screens[GameState.MATCH_SIMULATION] = matchScreen
        screens[GameState.MATCH_OPPORTUNITY] = matchScreen
        screens[GameState.MATCH_RESULT] = MatchResultScreen(this)
        screens[GameState.TABLE] = TableScreen(this)
        screens[GameState.SETTINGS] = SettingsScreen(this)
        current = screens.getValue(GameState.TITLE)
        current.onEnter()
        scope.launch { hasSave = saves.hasSave() }
        scope.launch { settingsStore.flow.collect { settings = it } }
    }

    // ---------- navegación ----------
    fun go(s: GameState) {
        if (transPhase != 0) return
        nextState = s; transPhase = 1; transT = 0f
    }

    /** Cambio interno sin transición (el partido alterna entre simulación y oportunidad). */
    fun setMatchState(s: GameState) { state = s }

    fun post(a: () -> Unit) { actions.add(a) }

    fun onBack(): Boolean {
        if (state == GameState.TITLE) return false
        post { if (transPhase == 0) current.onBack() }
        return true
    }

    // ---------- carrera ----------
    fun newCareer(p: Player) {
        career = CareerFactory.newCareer(p)
        saveNow()
        go(GameState.CAREER)
    }

    fun continueCareer() {
        scope.launch {
            val s = saves.load()
            if (s != null) post { career = s; go(GameState.CAREER) }
        }
    }

    fun saveNow() {
        val s = career ?: return
        val json = saves.encode(s) // se serializa en el hilo del juego; se escribe en IO
        scope.launch { saves.saveJson(json); hasSave = true }
    }

    fun deleteCareer() {
        scope.launch { saves.delete(); hasSave = false; post { career = null; go(GameState.TITLE) } }
    }

    fun updateSettings(s: Settings) {
        settings = s
        scope.launch { settingsStore.save(s) }
    }

    fun startMatch(mode: MatchMode) {
        val s = career ?: return
        val entry = s.nextEntry() ?: return
        val fx = s.fixtureOf(entry) ?: return
        val engine = MatchSimulationEngine(fx, s.player, s.clubById(fx.homeId), s.clubById(fx.awayId), mode)
        if (mode == MatchMode.SIMULATE) {
            engine.playAll()
            finishMatch(engine)
        } else {
            matchScreen.begin(engine)
            go(GameState.MATCH_SIMULATION)
        }
    }

    fun finishMatch(engine: MatchSimulationEngine) {
        val s = career ?: return
        val r = engine.buildResult()
        CareerManager.applyResult(s, r)
        lastResult = r
        saveNow()
        go(GameState.MATCH_RESULT)
    }

    fun advanceTraining() {
        val s = career ?: return
        CareerManager.advance(s)
        saveNow()
    }

    fun newSeason() {
        val s = career ?: return
        CareerManager.startNewSeason(s)
        saveNow()
    }

    fun pause() { saveNow() }

    // ---------- game loop ----------
    fun update(dt: Float) {
        while (true) { val a = actions.poll() ?: break; a() }
        // updateInput
        touch.drain { raw ->
            if (transPhase == 0) {
                val x = viewport.toRefX(raw.x); val y = viewport.toRefY(raw.y)
                when (raw.action) {
                    MotionEvent.ACTION_DOWN -> gestures.down(x, y, raw.time)
                    MotionEvent.ACTION_MOVE -> gestures.move(x, y)
                    else -> gestures.up(x, y)
                }
            }
        }
        gestures.update(SystemClock.uptimeMillis())
        updateTransition(dt)
        // updateSimulation + updateAnimations
        current.update(dt)
    }

    private fun updateTransition(dt: Float) {
        if (transPhase == 1) {
            transT += dt / 0.18f
            if (transT >= 1f) {
                state = nextState
                current = screens.getValue(state)
                current.onEnter()
                transPhase = 2; transT = 0f
            }
        } else if (transPhase == 2) {
            transT += dt / 0.22f
            if (transT >= 1f) { transPhase = 0; transT = 0f }
        }
    }

    fun render(c: Canvas) {
        c.drawColor(current.background)
        c.save()
        viewport.apply(c)
        current.render(c)
        if (transPhase != 0) {
            val a = if (transPhase == 1) transT else 1f - transT
            ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, withAlpha(0xFF000000.toInt(), (a.coerceIn(0f, 1f) * 255).toInt()))
        }
        c.restore()
    }
}
