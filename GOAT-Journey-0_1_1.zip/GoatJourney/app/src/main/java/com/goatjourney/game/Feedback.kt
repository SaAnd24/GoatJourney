package com.goatjourney.game

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.goatjourney.data.Settings

/** Vibración y efectos sonoros mínimos (sin assets). La música queda como ajuste para versiones futuras. */
class Feedback(ctx: Context, private val settings: () -> Settings) {
    @Suppress("DEPRECATION")
    private val vib = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    private val tone: ToneGenerator? = try { ToneGenerator(AudioManager.STREAM_MUSIC, 45) } catch (e: Exception) { null }

    @Suppress("DEPRECATION")
    fun vibrate(ms: Long) {
        if (!settings().vibration) return
        try {
            if (Build.VERSION.SDK_INT >= 26) vib?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            else vib?.vibrate(ms)
        } catch (e: Exception) { }
    }

    fun tick() { beep(ToneGenerator.TONE_PROP_BEEP, 35) }
    fun goal() { vibrate(220); beep(ToneGenerator.TONE_PROP_ACK, 220) }
    fun whistle() { beep(ToneGenerator.TONE_DTMF_S, 160) }

    private fun beep(t: Int, ms: Int) {
        if (!settings().sfx) return
        try { tone?.startTone(t, ms) } catch (e: Exception) { }
    }
}
