package com.goatjourney.core.progression

import com.goatjourney.core.career.CareerState

/**
 * Punto de extensión (v0.2+): XP, skill tree, evolución por temporada.
 * En 0.1 NO hay progresión: el jugador mantiene su OVR.
 */
interface ProgressionSystem {
    fun onMatchPlayed(state: CareerState) {}
    fun onSeasonEnd(state: CareerState) {}
}

object NoProgression : ProgressionSystem
