package com.goatjourney.rendering

import android.graphics.Canvas
import com.goatjourney.game.GameController
import kotlin.math.min

/** Pantalla con botones dibujados, animación de entrada y hit-testing propio (sin vistas Android). */
abstract class BaseScreen(protected val game: GameController) : ScreenRenderer {
    protected val ui: UI get() = game.ui
    protected val buttons = ArrayList<Btn>()
    protected var downBtn: Btn? = null
    protected var time = 0f
    protected var enterP = 0f
    private var enterT = 0f

    protected fun btn(id: String, x: Float, y: Float, w: Float, h: Float, label: String, style: Int = 0, icon: Int = -1): Btn {
        val b = Btn(id, x, y, w, h, label, style, icon); buttons.add(b); return b
    }

    override fun onEnter() { time = 0f; enterT = 0f; enterP = 0f; downBtn = null }

    override fun update(dt: Float) {
        time += dt
        enterT = min(1f, enterT + dt / 0.4f)
        enterP = Ease.outCubic(enterT)
    }

    override fun render(c: Canvas) {
        c.save(); c.translate(0f, (1f - enterP) * 28f)
        draw(c)
        c.restore()
    }

    protected abstract fun draw(c: Canvas)

    protected fun drawButtons(c: Canvas) {
        for (i in buttons.indices) { val b = buttons[i]; if (b.visible) ui.button(c, b, b === downBtn) }
    }

    protected fun hit(x: Float, y: Float): Btn? {
        for (i in buttons.indices) { val b = buttons[i]; if (b.visible && b.contains(x, y)) return b }
        return null
    }

    override fun onDown(x: Float, y: Float) { downBtn = hit(x, y)?.takeIf { it.enabled } }
    override fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) { downBtn = null }
    override fun onTap(x: Float, y: Float) {
        val b = hit(x, y)
        if (b != null && b.enabled) { game.feedback.tick(); onButton(b.id) }
    }

    protected open fun onButton(id: String) {}
}
