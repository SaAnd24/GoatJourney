package com.goatjourney.rendering

import android.graphics.Canvas
import android.graphics.Paint
import com.goatjourney.core.career.CareerFactory
import com.goatjourney.core.player.*
import com.goatjourney.game.GameController
import com.goatjourney.game.GameState
import kotlin.math.abs
import kotlin.math.sin

/** TITLE SCREEN (vertical 720x1280) */
class TitleScreen(g: GameController) : BaseScreen(g) {
    private val bNew = btn("new", 130f, 700f, 460f, 88f, "NUEVA CARRERA")
    private val bCont = btn("cont", 130f, 808f, 460f, 88f, "CONTINUAR", 1)
    private val bSet = btn("set", 130f, 916f, 460f, 72f, "AJUSTES", 1)
    private val skin = Appearance(1, 1, 0, 0)

    override fun onEnter() { super.onEnter(); bCont.enabled = game.hasSave }
    override fun update(dt: Float) { super.update(dt); bCont.enabled = game.hasSave }

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.fillRect(c, 0f, 0f, Ref.W, 640f, withAlpha(Palette.BG2, 120))
        ui.stroke.color = withAlpha(Palette.WHITE, 20); ui.stroke.strokeWidth = 5f
        c.drawCircle(360f, 1060f, 300f, ui.stroke)
        c.drawLine(0f, 1060f, Ref.W, 1060f, ui.stroke)
        val pulse = 1f + sin(time * 2f) * 0.015f
        c.save(); c.scale(pulse, pulse, 360f, 300f)
        ui.text(c, "GOAT", 360f, 330f, 210f, Palette.GOLD, Paint.Align.CENTER)
        c.restore()
        ui.text(c, "JOURNEY", 360f, 450f, 118f, Palette.ACCENT, Paint.Align.CENTER)
        ui.text(c, "0.1.1  ·  MOMENTOS DE PARTIDO", 360f, 510f, 28f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.fillRect(c, 0f, 1196f, Ref.W, 4f, withAlpha(Palette.GRASS1, 200))
        val bx = 40f + (time * 150f) % 640f
        val by = 1176f - abs(sin(time * 3.2f)) * 26f
        ui.player(c, bx - 46f, 1196f, 1.05f, skin, 0xFF1E88E5.toInt(), 0xFFFFFFFF.toInt(), 1f, time * 14f, true)
        ui.ball(c, bx, by, 13f, time * 10f)
        drawButtons(c)
    }

    override fun onButton(id: String) {
        when (id) {
            "new" -> game.go(GameState.CREATION)
            "cont" -> game.continueCareer()
            "set" -> game.go(GameState.SETTINGS)
        }
    }
}

/** Creación del futbolista (con teclado dibujado en Canvas). */
class CreationScreen(g: GameController) : BaseScreen(g) {
    private val nations = listOf("Argentina", "Brasil", "España", "México", "Colombia", "Francia", "Inglaterra", "Alemania", "Italia", "Portugal", "Uruguay", "Chile")
    private val firstNames = listOf("Leo", "Mateo", "Diego", "Sergio", "Lucas", "Bruno", "Tomás", "Iker", "Nico", "Hugo")
    private val lastNames = listOf("Rivera", "Santos", "Moreno", "Duarte", "Vega", "Castro", "Ortega", "Silva", "Pardo", "Luna")
    private val defaultNumbers = intArrayOf(4, 2, 8, 11, 9)

    private var name = ""
    private var surname = ""
    private var nation = 0
    private var foot = 0
    private var pos = 4
    private var number = 9
    private var skin = 1
    private var hair = 1
    private var style = 0
    private var accent = 0
    private var editing = -1 // 0 nombre, 1 apellido

    private val bBack = btn("back", 24f, 90f, 150f, 50f, "MENÚ", 1)
    private val bRand = btn("rand", 190f, 90f, 220f, 50f, "ALEATORIO", 1)
    private val bStart = btn("start", 60f, 1170f, 600f, 80f, "EMPEZAR CARRERA")
    private val bName = Btn("f0", 24f, 456f, 324f, 62f, "")
    private val bSurname = Btn("f1", 372f, 456f, 324f, 62f, "")
    private val rowY = floatArrayOf(530f, 600f, 670f, 740f)       // nacionalidad, pie, posición, número
    private val rowAppY = floatArrayOf(830f, 892f, 954f, 1016f)   // piel, pelo, peinado, acento
    private val arrows = ArrayList<Btn>()
    private val keys = ArrayList<Btn>()

    init {
        for (i in 0 until 4) { arrows.add(Btn("l$i", 24f, rowY[i], 62f, 62f, "", 1, ICON_LEFT)); arrows.add(Btn("r$i", 634f, rowY[i], 62f, 62f, "", 1, ICON_RIGHT)) }
        for (i in 0 until 4) { arrows.add(Btn("al$i", 24f, rowAppY[i], 54f, 54f, "", 1, ICON_LEFT)); arrows.add(Btn("ar$i", 642f, rowAppY[i], 54f, 54f, "", 1, ICON_RIGHT)) }
        val rows = arrayOf("QWERTYUIOP", "ASDFGHJKLÑ", "ZXCVBNM")
        for (r in rows.indices) {
            val n = rows[r].length
            val startX = (Ref.W - (n * 70f - 8f)) / 2f
            for (i in 0 until n) keys.add(Btn("k:" + rows[r][i], startX + i * 70f, 800f + r * 90f, 62f, 78f, rows[r][i].toString(), 1))
        }
        keys.add(Btn("kdel", 24f, 1080f, 170f, 78f, "BORRAR", 2))
        keys.add(Btn("kspace", 210f, 1080f, 290f, 78f, "ESPACIO", 1))
        keys.add(Btn("kdone", 516f, 1080f, 180f, 78f, "LISTO", 0))
    }

    override fun onEnter() {
        super.onEnter(); editing = -1
        name = firstNames.random(); surname = lastNames.random()
        nation = (nations.indices).random(); foot = 0; pos = 4; number = 9
        randomLook()
    }

    private fun randomLook() { skin = (0..5).random(); hair = (0..5).random(); style = (0..3).random(); accent = (0..7).random() }
    private fun cyc(v: Int, d: Int, n: Int) = ((v + d) % n + n) % n

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "NUEVO FUTBOLISTA")
        // vista previa
        ui.panel(c, 24f, 150f, 672f, 290f, withAlpha(Palette.PANEL, 160))
        val club = CareerFactory.CLUBS[0]
        val app = Appearance(skin, hair, style, accent)
        ui.player(c, 360f, 410f, 3.0f, app, club.primary, club.secondary, 1f, time * 3f, false, abs(sin(time * 2f)) * 6f)
        ui.textFit(c, "$name $surname", 360f, 184f, 30f, 640f, Palette.WHITE, Paint.Align.CENTER)
        // campos de texto
        for (i in 0 until 2) {
            val b = if (i == 0) bName else bSurname
            val v = if (i == 0) name else surname
            ui.panel(c, b.x, b.y, b.w, b.h, Palette.BG2, if (editing == i) Palette.ACCENT else Palette.PANEL_LIGHT, 14f)
            ui.text(c, if (i == 0) "NOMBRE" else "APELLIDO", b.x + 14f, b.y + 22f, 17f, Palette.TEXT_DIM)
            val cur = if (editing == i && (time * 2f).toInt() % 2 == 0) "_" else ""
            ui.textFit(c, v + cur, b.x + 14f, b.y + 52f, 32f, b.w - 28f, Palette.WHITE, Paint.Align.LEFT)
        }
        val vals = arrayOf(nations[nation], Foot.values()[foot].label, Position.values()[pos].label, "#$number")
        val labs = arrayOf("NACIONALIDAD", "PIE DOMINANTE", "POSICIÓN", "NÚMERO")
        for (i in 0 until 4) {
            ui.panel(c, 24f, rowY[i], 672f, 62f, Palette.BG2, Palette.PANEL_LIGHT, 14f)
            ui.text(c, labs[i], 360f, rowY[i] + 20f, 17f, Palette.TEXT_DIM, Paint.Align.CENTER)
            ui.text(c, vals[i], 360f, rowY[i] + 50f, 30f, Palette.WHITE, Paint.Align.CENTER)
        }
        val al = arrayOf("PIEL", "PELO", "PEINADO", "MANGAS / BOTINES")
        val av = arrayOf("Tono ${skin + 1}", "Color ${hair + 1}", Appearance.HAIR_STYLE_NAMES[style], "Color ${accent + 1}")
        for (i in 0 until 4) {
            ui.panel(c, 24f, rowAppY[i], 672f, 54f, Palette.BG2, Palette.PANEL_LIGHT, 12f)
            ui.text(c, al[i], 100f, rowAppY[i] + 36f, 20f, Palette.TEXT_DIM)
            ui.text(c, av[i], 620f, rowAppY[i] + 37f, 24f, Palette.WHITE, Paint.Align.RIGHT)
            if (i == 3) ui.circle(c, 440f, rowAppY[i] + 27f, 12f, Appearance.ACCENTS[accent])
            if (i == 0) ui.circle(c, 440f, rowAppY[i] + 27f, 12f, Appearance.SKINS[skin])
            if (i == 1) ui.circle(c, 440f, rowAppY[i] + 27f, 12f, Appearance.HAIRS[hair])
        }
        ui.text(c, "Edad 15  ·  OVR 45", 360f, 1100f, 32f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, "Los atributos se generan según la posición.", 360f, 1136f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        for (a in arrows) ui.button(c, a, a === downBtn)
        drawButtons(c)
        if (editing >= 0) {
            ui.fillRect(c, 0f, 700f, Ref.W, 580f, withAlpha(0xFF050B14.toInt(), 245))
            ui.text(c, if (editing == 0) "ESCRIBE EL NOMBRE" else "ESCRIBE EL APELLIDO", 360f, 750f, 28f, Palette.ACCENT, Paint.Align.CENTER)
            for (k in keys) ui.button(c, k, k === downBtn)
        }
    }

    override fun onDown(x: Float, y: Float) {
        downBtn = (if (editing >= 0) keys.firstOrNull { it.contains(x, y) } else (arrows + buttons).firstOrNull { it.contains(x, y) })
    }

    override fun onTap(x: Float, y: Float) {
        if (editing >= 0) {
            val k = keys.firstOrNull { it.contains(x, y) } ?: return
            game.feedback.tick()
            val cur = if (editing == 0) name else surname
            val next = when {
                k.id == "kdone" -> { editing = -1; return }
                k.id == "kdel" -> cur.dropLast(1)
                k.id == "kspace" -> if (cur.isNotEmpty() && !cur.endsWith(" ")) "$cur " else cur
                cur.length >= 12 -> cur
                else -> cur + (if (cur.isEmpty() || cur.endsWith(" ")) k.label else k.label.lowercase())
            }
            if (editing == 0) name = next else surname = next
            return
        }
        val a = arrows.firstOrNull { it.contains(x, y) }
        if (a != null) {
            game.feedback.tick()
            val d = if (a.id.contains('l')) -1 else 1
            val i = a.id.last().digitToInt()
            if (a.id.startsWith("a")) when (i) {
                0 -> skin = cyc(skin, d, 6); 1 -> hair = cyc(hair, d, 6); 2 -> style = cyc(style, d, 4); else -> accent = cyc(accent, d, 8)
            } else when (i) {
                0 -> nation = cyc(nation, d, nations.size); 1 -> foot = cyc(foot, d, 3)
                2 -> { pos = cyc(pos, d, 5); number = defaultNumbers[pos] }
                else -> number = cyc(number - 1, d, 99) + 1
            }
            return
        }
        if (bName.contains(x, y)) { editing = 0; return }
        if (bSurname.contains(x, y)) { editing = 1; return }
        super.onTap(x, y)
    }

    override fun onButton(id: String) {
        when (id) {
            "back" -> game.go(GameState.TITLE)
            "rand" -> { name = firstNames.random(); surname = lastNames.random(); nation = nations.indices.random(); randomLook() }
            "f0" -> editing = 0
            "f1" -> editing = 1
            "start" -> {
                val n = name.trim().ifEmpty { "Jugador" }; val s = surname.trim().ifEmpty { "Nuevo" }
                game.newCareer(PlayerFactory.create(n, s, nations[nation], Foot.values()[foot], Position.values()[pos], number, Appearance(skin, hair, style, accent), 0))
            }
        }
    }

    override fun onBack(): Boolean { if (editing >= 0) editing = -1 else game.go(GameState.TITLE); return true }
}

/** AJUSTES: música, efectos, vibración, borrar carrera. */
class SettingsScreen(g: GameController) : BaseScreen(g) {
    private val bMusic = btn("music", 110f, 200f, 500f, 84f, "")
    private val bSfx = btn("sfx", 110f, 304f, 500f, 84f, "")
    private val bVib = btn("vib", 110f, 408f, 500f, 84f, "")
    private val bDel = btn("del", 110f, 580f, 500f, 80f, "BORRAR CARRERA", 2)
    private val bMenu = btn("menu", 110f, 1020f, 240f, 72f, "MENÚ", 1)
    private val bBack = btn("back", 370f, 1020f, 240f, 72f, "VOLVER", 1)
    private var confirm = false

    override fun onEnter() { super.onEnter(); confirm = false; refresh() }
    private fun onOff(v: Boolean) = if (v) "SÍ" else "NO"
    private fun refresh() {
        val s = game.settings
        bMusic.label = "MÚSICA:  " + onOff(s.music); bSfx.label = "EFECTOS:  " + onOff(s.sfx); bVib.label = "VIBRACIÓN:  " + onOff(s.vibration)
        bDel.label = if (confirm) "¿SEGURO? TOCA DE NUEVO" else "BORRAR CARRERA"
        bDel.enabled = game.hasSave || game.career != null
    }

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "AJUSTES")
        ui.text(c, "La música es un ajuste reservado (sin audio aún).", 360f, 1180f, 22f, Palette.TEXT_DIM, Paint.Align.CENTER)
        drawButtons(c)
    }

    override fun onButton(id: String) {
        val s = game.settings
        when (id) {
            "music" -> game.updateSettings(s.copy(music = !s.music))
            "sfx" -> game.updateSettings(s.copy(sfx = !s.sfx))
            "vib" -> game.updateSettings(s.copy(vibration = !s.vibration))
            "del" -> { if (confirm) game.deleteCareer() else confirm = true }
            "menu" -> game.go(GameState.TITLE)
            "back" -> onBack()
        }
        refresh()
    }

    override fun onBack(): Boolean { game.go(if (game.career != null) GameState.CAREER else GameState.TITLE); return true }
}
