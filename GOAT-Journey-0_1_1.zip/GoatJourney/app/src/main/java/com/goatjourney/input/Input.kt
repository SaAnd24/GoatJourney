package com.goatjourney.input

import android.view.MotionEvent
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.hypot

class RawTouch(val action: Int, val x: Float, val y: Float, val time: Long)

/** Recoge MotionEvents en el hilo de UI y los entrega al game loop (sin tocar el estado del juego). */
class TouchInput {
    private val queue = ConcurrentLinkedQueue<RawTouch>()

    fun onMotionEvent(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                queue.add(RawTouch(e.actionMasked, e.x, e.y, e.eventTime))
        }
    }

    fun drain(handler: (RawTouch) -> Unit) {
        while (true) { val r = queue.poll() ?: break; handler(r) }
    }
}

/** Coordenadas ya en espacio de referencia (1280x720). */
interface GestureListener {
    fun onDown(x: Float, y: Float) {}
    fun onTap(x: Float, y: Float) {}
    fun onDragStart(x: Float, y: Float) {}
    fun onDrag(x: Float, y: Float, startX: Float, startY: Float) {}
    fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) {}
    fun onLongPress(x: Float, y: Float) {}
}

/** Traduce ACTION_DOWN/MOVE/UP a Tap, Drag, Release y Long Press. */
class GestureProcessor(private val listener: GestureListener) {
    private var isDown = false
    private var dragging = false
    private var longFired = false
    private var sx = 0f
    private var sy = 0f
    private var downTime = 0L
    private val slop = 16f
    private val longPressMs = 550L

    fun down(x: Float, y: Float, t: Long) {
        isDown = true; dragging = false; longFired = false; sx = x; sy = y; downTime = t
        listener.onDown(x, y)
    }

    fun move(x: Float, y: Float) {
        if (!isDown) return
        if (!dragging && hypot(x - sx, y - sy) > slop) { dragging = true; listener.onDragStart(sx, sy) }
        if (dragging) listener.onDrag(x, y, sx, sy)
    }

    fun up(x: Float, y: Float) {
        if (!isDown) return
        isDown = false
        listener.onRelease(x, y, sx, sy, dragging)
        if (!dragging && !longFired) listener.onTap(x, y)
    }

    fun update(now: Long) {
        if (isDown && !dragging && !longFired && now - downTime >= longPressMs) {
            longFired = true
            listener.onLongPress(sx, sy)
        }
    }
}
