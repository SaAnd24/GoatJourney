package com.goatjourney.core.match

import kotlin.math.*
import kotlin.random.Random

/** Campo en metros. Tu equipo ataca hacia x = 105. */
object Pitch {
    const val LENGTH = 105f
    const val WIDTH = 68f
    const val CENTER_Y = 34f
    const val GOAL_HALF = 3.66f
    const val CROSSBAR = 2.44f
}

data class Vec(val x: Float, val y: Float) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Float) = Vec(x * k, y * k)
    fun len() = hypot(x, y)
    fun dist(o: Vec) = hypot(x - o.x, y - o.y)
    fun norm(): Vec { val l = len(); return if (l < 1e-4f) Vec(1f, 0f) else Vec(x / l, y / l) }
    fun dot(o: Vec) = x * o.x + y * o.y
    fun rot(a: Float): Vec { val c = cos(a); val s = sin(a); return Vec(x * c - y * s, x * s + y * c) }
    fun lerp(o: Vec, t: Float) = Vec(x + (o.x - x) * t, y + (o.y - y) * t)
}

fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/** Ruido ~N(0,1) barato. */
fun Random.gauss(): Float = (nextFloat() + nextFloat() + nextFloat() - 1.5f) * 2f

object Geo {
    fun closest(p: Vec, a: Vec, b: Vec): Vec {
        val abx = b.x - a.x; val aby = b.y - a.y
        val l2 = abx * abx + aby * aby
        if (l2 < 1e-4f) return a
        val t = (((p.x - a.x) * abx + (p.y - a.y) * aby) / l2).coerceIn(0f, 1f)
        return Vec(a.x + abx * t, a.y + aby * t)
    }
    fun distToSegment(p: Vec, a: Vec, b: Vec): Float = p.dist(closest(p, a, b))
    fun clampPitch(v: Vec) = Vec(v.x.coerceIn(1.5f, Pitch.LENGTH - 1.5f), v.y.coerceIn(1.5f, Pitch.WIDTH - 1.5f))
}

enum class MatchImportance { NORMAL, IMPORTANT }

/** Cómo se interviene: con ventana de posicionamiento, reacción inmediata o acrobacia (ventana mínima). */
enum class MomentMode { POSITIONING, REACTION, ACROBATIC }

/** Lo que el gesto del jugador acaba significando (se infiere del gesto; no hay menú de acciones). */
enum class IntentKind { PASS, SPACE_PASS, SHOT, CROSS, HEADER, CLEARANCE, CONTROL, INTERCEPT, VOLLEY, CHILENA, BLOCK }

enum class Role { GK, DEF, MID, WING, FWD }

enum class Zone { OWN_BOX, OWN_THIRD, MIDFIELD, FINAL_THIRD, WIDE_FINAL, BOX }

/** Tipos de KeyMoment. [implemented] = false => arquitectura preparada, aún sin generador/resolución propia. */
enum class KeyMomentType(val label: String, val implemented: Boolean) {
    PASS_MOMENT("PASE", true),
    SHOT_MOMENT("TIRO", true),
    CROSS_MOMENT("CENTRO", true),
    HEADER_MOMENT("CABEZAZO", true),
    VOLLEY_MOMENT("REMATE DE PRIMERA", true),
    CHILENA_MOMENT("¡CHILENA!", true),
    ONE_TWO_MOMENT("PARED", true),
    INTERCEPTION_MOMENT("INTERCEPCIÓN", true),
    CLEARANCE_MOMENT("DESPEJE", true),
    REBOUND_MOMENT("REBOTE", true),
    FIRST_TOUCH_MOMENT("PRIMER TOQUE", true),
    BLOCK_MOMENT("BLOQUEO", false),
    TACKLE_MOMENT("ENTRADA", false),
    DRIBBLE_MOMENT("REGATE", false)
}

/** Compañero con agencia propia: calidad interna, rol y carrera hacia un destino. */
class Mate(val id: Int, var pos: Vec, var run: Vec, val quality: Float, val role: Role) {
    fun copyOf() = Mate(id, pos, run, quality, role)
    fun speed() = 4.8f + quality * 2.2f
}

class Rival(var pos: Vec, val quality: Float, val role: Role) {
    fun copyOf() = Rival(pos, quality, role)
    fun speed() = 4.6f + quality * 2.4f
}

class Keeper(var pos: Vec, val quality: Float) {
    fun copyOf() = Keeper(pos, quality)
}

/** Estado vivo de todos los actores durante un momento. */
class World(var player: Vec, val mates: MutableList<Mate>, val rivals: MutableList<Rival>, var keeper: Keeper?) {
    fun copyOf() = World(player, mates.map { it.copyOf() }.toMutableList(), rivals.map { it.copyOf() }.toMutableList(), keeper?.copyOf())
}

class ContactPoint(val pos: Vec, val z: Float)

/**
 * Situación significativa del partido donde el protagonista puede cambiar el resultado.
 * Es inmutable: la sesión (MomentSession) trabaja sobre copias vivas de los actores.
 */
class KeyMoment(
    val type: KeyMomentType,
    val mode: MomentMode,
    val minute: Int,
    val player: Vec,
    val ball: Vec,
    val ballHeight: Float,
    val ballVel: Vec,
    val mates: List<Mate>,
    val rivals: List<Rival>,
    val keeper: Keeper?,
    val pressure: Float,
    val timeWindow: Float,
    val zone: Zone,
    val context: String,
    val danger: Float,
    val actions: Set<IntentKind>,
    val allowsPositioning: Boolean,
    val incoming: Trajectory?,
    val contact: ContactPoint?,
    val canContinue: Boolean,
    val readQuality: Float,
    val spaceHints: List<Vec>,
    val depth: Int
) {
    fun makeWorld() = World(player, mates.map { it.copyOf() }.toMutableList(), rivals.map { it.copyOf() }.toMutableList(), keeper?.copyOf())
    val ballDirection: Vec get() = ballVel.norm()
    val ballSpeed: Float get() = ballVel.len()
}

// ------------------------------------------------------------------ resultado de una acción

enum class Tone { GOOD, BAD, NEUTRAL, GOAL }
enum class ActorKind { MATE, RIVAL, KEEPER, PLAYER }
class ActorMove(val kind: ActorKind, val index: Int, val to: Vec)

/** Un tramo de la jugada: el balón recorre [samples]; después se muestra un titular. */
class Beat(
    val samples: List<BallSample>,
    val headline: String,
    val detail: String,
    val tone: Tone,
    val moves: List<ActorMove>,
    val hold: Float,
    val celebrate: Boolean = false
)

enum class ShotOutcome { NONE, GOAL, SAVED, PARRIED, BLOCKED, OFF_TARGET, POST }

/** Resultado completo de una acción (puede encadenar varios tramos y un nuevo KeyMoment). */
class ActionResult(val intent: IntentKind) {
    var success = false
    var quality = 0f
    val beats = ArrayList<Beat>()
    var next: KeyMoment? = null

    var passAttempt = false
    var passCompleted = false
    var crossAttempt = false
    var protagonistShot = false
    var shotOutcome = ShotOutcome.NONE
    var teamShot = false
    var teamGoal = false
    var goalByPlayer = false
    var assist = false
    var chanceCreated = false
    var turnover = false
    var foul = false
    var rebound = false
    var oneTwo = false
    var interception = false
    var clearanceDone = false
    var dribbleAttempt = false
    var dribbleWon = false
    /** Probabilidad (0..~0.4) de que el rival genere peligro tras esta acción. */
    var opponentThreat = 0f
}
