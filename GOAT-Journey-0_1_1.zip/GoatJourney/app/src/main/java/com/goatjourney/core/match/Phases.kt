package com.goatjourney.core.match

import com.goatjourney.core.player.Attributes
import kotlin.math.*

/** Parámetros físicos de cada tipo de golpeo. */
class Profile(
    val minSpeed: Float, val maxSpeed: Float, val baseElev: Float, val liftRange: Float,
    val minElev: Float, val maxElev: Float, val z0: Float, val precision: Float
)

object ActionProfiles {
    fun of(k: IntentKind): Profile = when (k) {
        IntentKind.PASS, IntentKind.SPACE_PASS -> Profile(6f, 26f, 0f, 0.65f, 0f, 1.1f, 0.1f, 1.0f)
        IntentKind.SHOT -> Profile(12f, 34f, 0.05f, 0.55f, 0f, 0.9f, 0.15f, 1.15f)
        IntentKind.CROSS -> Profile(13f, 26f, 0.52f, 0.35f, 0.2f, 1.0f, 0.15f, 1.2f)
        IntentKind.HEADER -> Profile(8f, 25f, -0.10f, 0.5f, -0.35f, 0.7f, 1.8f, 1.25f)
        IntentKind.CLEARANCE -> Profile(10f, 32f, 0.5f, 0.4f, 0.1f, 1.0f, 0.15f, 1.4f)
        IntentKind.VOLLEY -> Profile(12f, 32f, 0.02f, 0.5f, -0.1f, 0.8f, 0.8f, 1.6f)
        IntentKind.CHILENA -> Profile(12f, 30f, 0.1f, 0.5f, -0.1f, 0.8f, 1.6f, 2.0f)
        else -> Profile(6f, 20f, 0f, 0.4f, 0f, 0.8f, 0.1f, 1.0f)
    }

    /** Distancia aproximada (m) que recorre un pase raso con esa potencia. */
    fun passRange(power: Float): Float {
        val p = of(IntentKind.PASS)
        return mix(p.minSpeed, p.maxSpeed, power) / BallPhysics.ROLL_K * 0.92f
    }
}

class Aim(val dir: Vec, val power: Float, val dragPx: Float)

/** Punto de contacto en el balón: ix -1..1 (izq-der), iy -1..1 (abajo-arriba). Valores continuos. */
class Contact(val ix: Float, val iy: Float)

class ContactEffect(val curve: Float, val lift: Float, val drive: Float, val stability: Float, val spin: Float)

class ActionIntent(val kind: IntentKind, val mate: Mate?, val target: Vec, val toSpace: Boolean)

/** FASE 1 de ejecución: dirección + fuerza a partir del arrastre. */
object AimPhase {
    const val MAX_DRAG = 260f
    const val MIN_DRAG = 26f

    fun power(dragPx: Float): Float = (dragPx / MAX_DRAG).coerceIn(0f, 1f).pow(1.2f)
    fun dragFor(power: Float): Float = MAX_DRAG * power.coerceIn(0f, 1f).pow(1f / 1.2f)

    fun fromDrag(worldDir: Vec, dragPx: Float): Aim? =
        if (dragPx < MIN_DRAG) null else Aim(worldDir.norm(), power(dragPx), dragPx)

    /** Interpreta el gesto: no hay menú de acciones; el gesto y el contexto dicen qué se intenta. */
    fun infer(m: KeyMoment, origin: Vec, mates: List<Mate>, aim: Aim): ActionIntent {
        val dir = aim.dir
        val goal = Vec(Pitch.LENGTH, Pitch.CENTER_Y)
        when (m.type) {
            KeyMomentType.HEADER_MOMENT -> return ActionIntent(IntentKind.HEADER, null, goal, false)
            KeyMomentType.VOLLEY_MOMENT -> return ActionIntent(IntentKind.VOLLEY, null, goal, false)
            KeyMomentType.CHILENA_MOMENT -> return ActionIntent(IntentKind.CHILENA, null, goal, false)
            KeyMomentType.FIRST_TOUCH_MOMENT -> return ActionIntent(IntentKind.CONTROL, null, origin + dir * 3f, false)
            KeyMomentType.INTERCEPTION_MOMENT -> return ActionIntent(IntentKind.INTERCEPT, null, origin + dir * (aim.power * 6f), false)
            KeyMomentType.CLEARANCE_MOMENT -> return ActionIntent(IntentKind.CLEARANCE, null, origin + dir * 30f, false)
            KeyMomentType.CROSS_MOMENT -> if (aim.power >= 0.3f) return ActionIntent(IntentKind.CROSS, null, origin + dir * 28f, false)
            else -> {}
        }
        if (IntentKind.SHOT in m.actions && dir.x > 0.2f) {
            val tt = (Pitch.LENGTH - origin.x) / dir.x
            val gy = origin.y + dir.y * tt
            if (abs(gy - Pitch.CENTER_Y) < 9f && origin.dist(goal) < 40f)
                return ActionIntent(IntentKind.SHOT, null, Vec(Pitch.LENGTH, gy), false)
        }
        val range = ActionProfiles.passRange(aim.power)
        var best: Mate? = null; var bestScore = 1e9f; var bestAlong = 0f
        for (mt in mates) {
            val v = mt.pos - origin
            val along = v.dot(dir)
            if (along < 3f || along > range * 1.4f + 6f) continue
            val lateral = abs(v.x * dir.y - v.y * dir.x)
            val tol = 3.2f + along * 0.10f
            if (lateral > tol) continue
            val score = lateral / tol
            if (score < bestScore) { bestScore = score; best = mt; bestAlong = along }
        }
        val end = origin + dir * range
        if (best == null) return ActionIntent(IntentKind.SPACE_PASS, null, end, true)
        return if (range > bestAlong + 5.5f) ActionIntent(IntentKind.SPACE_PASS, best, end, true)
        else ActionIntent(IntentKind.PASS, best, best.pos, false)
    }
}

/** FASE 2: punto de contacto con el balón (zonas suaves, valores continuos). */
object ContactPhase {
    const val DEAD = 0.14f

    /** nx, ny normalizados dentro del disco del balón; ny positivo = parte SUPERIOR. */
    fun fromTouch(nx: Float, ny: Float): Contact {
        var x = nx; var y = ny
        val l = hypot(x, y)
        if (l > 1f) { x /= l; y /= l }
        val m = hypot(x, y)
        if (m < DEAD) return Contact(0f, 0f)
        val k = (m - DEAD) / (1f - DEAD) / m
        return Contact(x * k, y * k)
    }

    fun effect(c: Contact, power: Float, technique: Float): ContactEffect {
        val off = hypot(c.ix, c.iy).coerceAtMost(1f)
        val stability = (1f - off * (0.60f - 0.30f * technique)).coerceIn(0.25f, 1f)
        val curve = c.ix * 5.5f * (0.45f + 0.55f * power)
        return ContactEffect(curve, -c.iy, max(0f, c.iy), stability, c.ix)
    }
}

/** Movimiento contextual del protagonista durante la ventana de posicionamiento. */
object PositioningPhase {
    fun runSpeed(a: Attributes): Float = 3.0f + (a.speed * 0.6f + a.acceleration * 0.4f) / 100f * 4.5f

    /** Metros totales que puede desplazarse durante la ventana. */
    fun maxMove(a: Attributes, window: Float, withBall: Boolean): Float =
        runSpeed(a) * window * (if (withBall) 0.8f else 0.95f) * 0.85f
}
