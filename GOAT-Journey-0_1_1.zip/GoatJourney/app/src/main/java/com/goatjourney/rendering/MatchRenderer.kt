package com.goatjourney.rendering

import android.graphics.Canvas
import android.graphics.Paint
import com.goatjourney.core.match.*
import com.goatjourney.core.player.Position
import com.goatjourney.core.simulation.MatchSimulationEngine
import com.goatjourney.game.GameController
import com.goatjourney.game.GameState
import kotlin.math.*

/**
 * Cámara VERTICAL: el campo se dibuja girado; tu equipo ataca hacia ARRIBA.
 * sx recibe la coordenada y del mundo (ancho), sy recibe la x del mundo (largo).
 */
class Camera {
    var cx = 52.5f; var cy = 34f; var zoom = 10.4f
    var tx = 52.5f; var ty = 34f; var tz = 10.4f
    var shake = 0f
    private var t = 0f
    private var ox = 0f; private var oy = 0f
    private val anchorY = 650f

    fun overview() { tx = 52.5f; ty = 34f; tz = 10.4f }
    fun snapOverview() { overview(); cx = tx; cy = ty; zoom = tz }
    fun snap() { cx = tx; cy = ty; zoom = tz }

    fun update(dt: Float) {
        val f = min(1f, dt * 5f)
        cx += (tx - cx) * f; cy += (ty - cy) * f; zoom += (tz - zoom) * f
        shake = max(0f, shake - dt * 2.2f); t += dt
        ox = sin(t * 61f) * shake * 9f; oy = cos(t * 53f) * shake * 9f
    }

    fun sx(wy: Float) = (wy - cy) * zoom + 360f + ox
    fun sy(wx: Float) = (cx - wx) * zoom + anchorY + oy
}

/**
 * Pantalla de partido (MATCH_SIMULATION / MATCH_OPPORTUNITY), VERTICAL.
 * Fases: SIM -> INTRO -> MOMENT (posicionar / apuntar / contacto) -> FLIGHT (tramos del balón) -> SIM ...
 * Toda la lógica de fútbol vive en core (MomentSession, ActionResolver, BallPhysics); aquí solo se anima y se dibuja.
 */
class MatchScreen(g: GameController) : BaseScreen(g) {
    private enum class Phase { SIM, INTRO, MOMENT, FLIGHT, FULLTIME }
    private enum class Touch { NONE, MOVE, AIM_START, AIM, CONTACT }

    override val background: Int get() = Palette.GRASS_DARK

    private var eng: MatchSimulationEngine? = null
    private var phase = Phase.SIM
    private val cam = Camera()
    private val particles = Particles()

    private var myShirt = 0; private var myShorts = 0; private var oppShirt = 0; private var oppShorts = 0
    private var speed = 1f
    private var pt = 0f
    private var spin = 0f
    private var finishCalled = false

    // simulación abstracta
    private var bwx = 52.5f; private var bwy = 34f
    private val FX = floatArrayOf(0.04f, 0.22f, 0.20f, 0.20f, 0.22f, 0.42f, 0.45f, 0.42f, 0.68f, 0.72f, 0.68f)
    private val FY = floatArrayOf(0.5f, 0.88f, 0.62f, 0.38f, 0.12f, 0.3f, 0.5f, 0.7f, 0.85f, 0.5f, 0.15f)

    // escena del momento
    private var sess: MomentSession? = null
    private var result: ActionResult? = null
    private var curP = Vec(0f, 0f)
    private var curM = ArrayList<Vec>()
    private var curR = ArrayList<Vec>()
    private var curK: Vec? = null
    private var ballPos = Vec(0f, 0f)
    private var ballZ = 0f

    // tramos (beats)
    private var beatIdx = 0
    private var beatT = 0f
    private var beatDur = 1f
    private var beatScale = 1f
    private var holding = false
    private var holdT = 0f
    private var fromP = Vec(0f, 0f); private var toP = Vec(0f, 0f)
    private var fromM = ArrayList<Vec>(); private var toM = ArrayList<Vec>()
    private var fromR = ArrayList<Vec>(); private var toR = ArrayList<Vec>()
    private var fromK: Vec? = null; private var toK: Vec? = null
    private var trailSamples: List<BallSample> = emptyList()
    private var bannerHead = ""; private var bannerDetail = ""; private var bannerColor = Palette.ACCENT
    private var bannerOn = false; private var celebrate = false; private var bannerT = 0f

    // input
    private var touch = Touch.NONE
    private var dragX = 0f; private var dragY = 0f
    private var fingerX = 0f; private var fingerY = 0f
    private var anchorX = 0f; private var anchorY = 0f
    private var cNx = 0f; private var cNy = 0f
    private var preview: AimPreview? = null
    private val CB_X = 360f; private val CB_Y = 700f; private val CB_R = 210f

    // caches de texto
    private var clockSec = -1; private var clockStr = "00:00"
    private var scoreKey = -1; private var scoreStr = ""
    private var evCount = -1; private var evStr = ""
    private var ratingStr = "6.0"

    private fun wx(v: Vec) = cam.sx(v.y)
    private fun wy(v: Vec) = cam.sy(v.x)
    private fun worldDir(dx: Float, dy: Float) = Vec(-dy, dx).norm()

    fun begin(e: MatchSimulationEngine) {
        eng = e
        myShirt = e.myClub.primary; myShorts = e.myClub.secondary
        val o = e.oppClub
        val dr = abs((myShirt shr 16 and 255) - (o.primary shr 16 and 255)) +
            abs((myShirt shr 8 and 255) - (o.primary shr 8 and 255)) + abs((myShirt and 255) - (o.primary and 255))
        oppShirt = if (dr < 110) o.secondary else o.primary
        oppShorts = darken(oppShirt, 0.6f)
        phase = Phase.SIM; speed = 1f; pt = 0f; finishCalled = false
        cam.snapOverview(); bwx = 52.5f; bwy = 34f
        sess = null; result = null; touch = Touch.NONE; bannerOn = false
        clockSec = -1; scoreKey = -1; evCount = -1
        game.setMatchState(GameState.MATCH_SIMULATION)
        game.feedback.whistle()
    }

    override fun onBack(): Boolean = true // no se abandona un partido a medias

    // ------------------------------------------------------------------ update
    override fun update(dt: Float) {
        super.update(dt)
        val e = eng ?: return
        cam.update(dt); particles.update(dt); spin += dt * 9f; pt += dt
        if (bannerOn) bannerT += dt
        when (phase) {
            Phase.SIM -> {
                e.update(dt * speed)
                val tx = 52.5f + e.momentum * 38f + sin(time * 0.9f) * 6f
                val ty = 34f + sin(time * 1.3f) * 14f
                val f = min(1f, dt * 2.5f)
                bwx += (tx - bwx) * f; bwy += (ty - bwy) * f
                val p = e.pending
                if (p != null) startMoment(p)
                else if (e.finished) { phase = Phase.FULLTIME; pt = 0f; game.feedback.whistle() }
            }
            Phase.INTRO -> if (pt >= 0.8f) { phase = Phase.MOMENT; pt = 0f }
            Phase.MOMENT -> updateMoment(dt)
            Phase.FLIGHT -> updateFlight(dt)
            Phase.FULLTIME -> if (pt >= 2.0f && !finishCalled) { finishCalled = true; game.finishMatch(e) }
        }
    }

    private fun startMoment(m: KeyMoment) {
        val e = eng ?: return
        val s = e.beginMoment()
        sess = s; result = null
        phase = Phase.INTRO; pt = 0f; touch = Touch.NONE; bannerOn = false; preview = null
        sync(s)
        game.setMatchState(GameState.MATCH_OPPORTUNITY)
        // encuadre: todos los actores + trayectoria entrante + portería si hay ocasión
        var x0 = 999f; var x1 = -999f; var y0 = 999f; var y1 = -999f
        fun add(v: Vec) { x0 = min(x0, v.x); x1 = max(x1, v.x); y0 = min(y0, v.y); y1 = max(y1, v.y) }
        add(s.world.player)
        for (mt in s.world.mates) { add(mt.pos); add(mt.run) }
        for (r in s.world.rivals) add(r.pos)
        s.world.keeper?.let { add(it.pos) }
        m.incoming?.let { inc -> add(Vec(inc.samples[0].x, inc.samples[0].y)); add(inc.endPos) }
        if (IntentKind.SHOT in m.actions || m.type == KeyMomentType.CROSS_MOMENT) add(Vec(Pitch.LENGTH, Pitch.CENTER_Y))
        if (m.type == KeyMomentType.CLEARANCE_MOMENT) add(Vec(0f, Pitch.CENTER_Y))
        // margen para el movimiento posible
        if (m.mode == MomentMode.POSITIONING) { add(Vec(s.world.player.x + s.maxMove * 0.7f, s.world.player.y)); add(Vec(s.world.player.x - s.maxMove * 0.4f, s.world.player.y)) }
        fitTo(x0, x1, y0, y1)
    }

    private fun fitTo(x0: Float, x1: Float, y0: Float, y1: Float) {
        val w = max(34f, (y1 - y0)) + 10f
        val h = max(34f, (x1 - x0)) + 14f
        cam.tz = min(660f / w, 860f / h).coerceIn(10.4f, 24f)
        cam.tx = (x0 + x1) / 2f; cam.ty = (y0 + y1) / 2f
    }

    private fun sync(s: MomentSession) {
        curP = s.world.player
        curM = ArrayList(s.world.mates.map { it.pos })
        curR = ArrayList(s.world.rivals.map { it.pos })
        curK = s.world.keeper?.pos
        ballPos = s.ball; ballZ = s.ballZ
    }

    private fun updateMoment(dt: Float) {
        val s = sess ?: return
        s.update(dt)
        sync(s)
        if (touch == Touch.AIM && s.phase == MomentSession.Phase.AIM) {
            val len = hypot(dragX, dragY)
            preview = if (len >= AimPhase.MIN_DRAG) s.preview(worldDir(dragX, dragY), len) else null
        } else preview = null
        if (s.expired && s.phase == MomentSession.Phase.AIM) startFlight(s.timeoutResolve())
    }

    // ------------------------------------------------------------------ vuelo (tramos)
    private fun startFlight(r: ActionResult) {
        val s = sess ?: return
        result = r
        touch = Touch.NONE; preview = null
        phase = Phase.FLIGHT; pt = 0f
        sync(s)
        var x0 = 999f; var x1 = -999f; var y0 = 999f; var y1 = -999f
        fun add(x: Float, y: Float) { x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y) }
        add(curP.x, curP.y)
        for (v in curM) add(v.x, v.y)
        for (v in curR) add(v.x, v.y)
        for (b in r.beats) for (smp in b.samples) add(smp.x, smp.y)
        fitTo(x0, x1, y0, y1)
        startBeat(0)
    }

    private fun startBeat(i: Int) {
        val r = result ?: return
        if (i >= r.beats.size) { endFlight(); return }
        val b = r.beats[i]
        beatIdx = i; beatT = 0f; holding = false; holdT = 0f; bannerOn = false
        val last = if (b.samples.isEmpty()) 0f else b.samples[b.samples.size - 1].t
        beatScale = max(1f, last / 2.4f)
        beatDur = max(0.05f, last / beatScale)
        fromP = curP; fromM = ArrayList(curM); fromR = ArrayList(curR); fromK = curK
        toP = curP; toM = ArrayList(curM); toR = ArrayList(curR); toK = curK
        for (mv in b.moves) when (mv.kind) {
            ActorKind.PLAYER -> toP = mv.to
            ActorKind.MATE -> if (mv.index in toM.indices) toM[mv.index] = mv.to
            ActorKind.RIVAL -> if (mv.index in toR.indices) toR[mv.index] = mv.to
            ActorKind.KEEPER -> toK = mv.to
        }
        trailSamples = b.samples
    }

    private fun sampleAt(list: List<BallSample>, t: Float): BallSample {
        if (list.isEmpty()) return BallSample(0f, ballPos.x, ballPos.y, 0f)
        if (t <= list[0].t) return list[0]
        val last = list[list.size - 1]
        if (t >= last.t) return last
        var i = 1
        while (i < list.size && list[i].t < t) i++
        val a = list[i - 1]; val b = list[i]
        val u = (t - a.t) / max(1e-4f, b.t - a.t)
        return BallSample(t, mix(a.x, b.x, u), mix(a.y, b.y, u), mix(a.z, b.z, u))
    }

    private fun updateFlight(dt: Float) {
        val r = result ?: return
        val b = r.beats.getOrNull(beatIdx)
        if (b == null) { endFlight(); return }
        if (!holding) {
            beatT += dt
            val prog = (beatT / beatDur).coerceIn(0f, 1f)
            val ease = Ease.outQuad(prog)
            curP = fromP.lerp(toP, ease)
            for (i in curM.indices) curM[i] = fromM[i].lerp(toM[i], ease)
            for (i in curR.indices) curR[i] = fromR[i].lerp(toR[i], ease)
            val fk = fromK; val tk = toK
            if (fk != null && tk != null) curK = fk.lerp(tk, ease)
            val smp = sampleAt(b.samples, beatT * beatScale)
            ballPos = Vec(smp.x, smp.y); ballZ = smp.z
            if (beatT >= beatDur) { holding = true; holdT = 0f; onLanded(b) }
        } else {
            holdT += dt
            if (holdT >= b.hold) startBeat(beatIdx + 1)
        }
    }

    private fun onLanded(b: Beat) {
        if (b.headline.isNotEmpty()) {
            bannerOn = true; bannerT = 0f
            bannerHead = b.headline; bannerDetail = b.detail
            bannerColor = when (b.tone) { Tone.GOAL -> Palette.GOLD; Tone.GOOD -> Palette.ACCENT; Tone.BAD -> Palette.RED; Tone.NEUTRAL -> Palette.WHITE }
        }
        celebrate = b.celebrate
        if (b.celebrate) { particles.burst(360f, 420f); cam.shake = 1f; game.feedback.goal() }
        else if (b.tone == Tone.BAD) game.feedback.vibrate(25)
    }

    private fun endFlight() {
        val e = eng ?: return
        val r = result
        if (r != null) { e.finishMoment(r); e.continueAfterResult() }
        sess = null; result = null; bannerOn = false; celebrate = false
        val nxt = e.pending
        if (nxt != null) startMoment(nxt)
        else if (e.finished) { phase = Phase.FULLTIME; pt = 0f; game.feedback.whistle() }
        else { phase = Phase.SIM; pt = 0f; cam.overview(); game.setMatchState(GameState.MATCH_SIMULATION) }
    }

    // ------------------------------------------------------------------ input
    override fun onTap(x: Float, y: Float) { if (phase == Phase.SIM) speed = if (speed > 1f) 1f else 3f }

    private fun updateMove(x: Float, y: Float) {
        val s = sess ?: return
        fingerX = x; fingerY = y
        val dx = x - wx(curP); val dy = y - wy(curP)
        val d = hypot(dx, dy)
        if (d < 12f) s.setMove(null, 0f) else s.setMove(worldDir(dx, dy), (d / 150f).coerceIn(0.35f, 1f))
    }

    private fun setContact(x: Float, y: Float) {
        cNx = ((x - CB_X) / CB_R).coerceIn(-1.2f, 1.2f)
        cNy = (-(y - CB_Y) / CB_R).coerceIn(-1.2f, 1.2f)
    }

    override fun onDown(x: Float, y: Float) {
        if (phase != Phase.MOMENT) return
        val s = sess ?: return
        dragX = 0f; dragY = 0f
        when (s.phase) {
            MomentSession.Phase.POSITIONING -> {
                val bx = wx(ballPos); val by = wy(ballPos)
                if (hypot(x - bx, y - by) < 84f) { touch = Touch.AIM_START; anchorX = bx; anchorY = by }
                else { touch = Touch.MOVE; updateMove(x, y) }
            }
            MomentSession.Phase.AIM -> { touch = Touch.AIM; anchorX = x; anchorY = y }
            MomentSession.Phase.CONTACT -> { touch = Touch.CONTACT; setContact(x, y) }
            else -> {}
        }
    }

    override fun onDrag(x: Float, y: Float, startX: Float, startY: Float) {
        val s = sess ?: return
        if (phase != Phase.MOMENT) return
        when (touch) {
            Touch.MOVE -> updateMove(x, y)
            Touch.AIM_START -> { s.beginAim(); touch = Touch.AIM; dragX = x - startX; dragY = y - startY }
            Touch.AIM -> { dragX = x - startX; dragY = y - startY }
            Touch.CONTACT -> setContact(x, y)
            else -> {}
        }
    }

    override fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) {
        val s = sess ?: return
        if (phase != Phase.MOMENT) { touch = Touch.NONE; return }
        when (touch) {
            Touch.MOVE -> s.setMove(null, 0f)
            Touch.AIM -> {
                val len = hypot(dragX, dragY)
                if (len >= AimPhase.MIN_DRAG) {
                    if (s.releaseAim(worldDir(dragX, dragY), len)) {
                        val done = s.result
                        if (s.phase == MomentSession.Phase.DONE && done != null) startFlight(done)
                        else { cNx = 0f; cNy = 0f }
                    }
                } else s.cancelAim()
            }
            Touch.CONTACT -> {
                setContact(x, y)
                startFlight(s.commitContact(cNx, cNy))
            }
            else -> {}
        }
        touch = Touch.NONE; dragX = 0f; dragY = 0f
    }

    // ------------------------------------------------------------------ render
    override fun render(c: Canvas) { draw(c) }

    override fun draw(c: Canvas) {
        val e = eng ?: return
        drawPitch(c)
        if (phase == Phase.SIM || phase == Phase.FULLTIME) drawSim(c, e) else drawScene(c, e)
        drawHud(c, e)
        if (phase == Phase.INTRO || phase == Phase.MOMENT) drawMomentUi(c)
        if (phase == Phase.FLIGHT && bannerOn) drawBanner(c)
        particles.draw(c, ui)
        if (phase == Phase.FULLTIME) {
            ui.fillRect(c, 0f, 520f, Ref.W, 200f, withAlpha(0xFF000000.toInt(), 170))
            ui.text(c, "FINAL DEL PARTIDO", 360f, 610f, 62f, Palette.GOLD, Paint.Align.CENTER)
            ui.text(c, scoreStr, 360f, 676f, 44f, Palette.WHITE, Paint.Align.CENTER)
        }
    }

    private fun drawPitch(c: Canvas) {
        val l = cam.sx(0f); val r = cam.sx(68f); val top = cam.sy(105f); val bot = cam.sy(0f)
        val n = 14; val h = (bot - top) / n
        for (i in 0 until n) { ui.fill.color = if (i % 2 == 0) Palette.GRASS1 else Palette.GRASS2; c.drawRect(l, top + i * h, r, top + (i + 1) * h, ui.fill) }
        val z = cam.zoom
        ui.stroke.color = withAlpha(Palette.WHITE, 210); ui.stroke.strokeWidth = max(2f, z * 0.17f)
        c.drawRect(l, top, r, bot, ui.stroke)
        val my = cam.sy(52.5f); c.drawLine(l, my, r, my, ui.stroke)
        val cx = cam.sx(34f)
        c.drawCircle(cx, my, 9.15f * z, ui.stroke)
        ui.fill.color = Palette.WHITE; c.drawCircle(cx, my, max(2f, z * 0.3f), ui.fill)
        c.drawRect(cam.sx(13.84f), top, cam.sx(54.16f), cam.sy(88.5f), ui.stroke)
        c.drawRect(cam.sx(13.84f), cam.sy(16.5f), cam.sx(54.16f), bot, ui.stroke)
        c.drawRect(cam.sx(24.84f), top, cam.sx(43.16f), cam.sy(99.5f), ui.stroke)
        c.drawRect(cam.sx(24.84f), cam.sy(5.5f), cam.sx(43.16f), bot, ui.stroke)
        ui.fill.color = withAlpha(Palette.WHITE, 70)
        c.drawRect(cam.sx(30.34f), cam.sy(107.4f), cam.sx(37.66f), top, ui.fill)
        c.drawRect(cam.sx(30.34f), bot, cam.sx(37.66f), cam.sy(-2.4f), ui.fill)
        c.drawRect(cam.sx(30.34f), cam.sy(107.4f), cam.sx(37.66f), top, ui.stroke)
        c.drawRect(cam.sx(30.34f), bot, cam.sx(37.66f), cam.sy(-2.4f), ui.stroke)
    }

    private fun drawSim(c: Canvas, e: MatchSimulationEngine) {
        val z = cam.zoom
        val shift = (bwx - 52.5f) * 0.35f
        val rad = max(5f, z * 0.85f)
        val idx = when (e.player.position) {
            Position.CENTER_BACK -> 3
            Position.FULL_BACK -> 4
            Position.MIDFIELDER -> 6
            Position.WINGER -> 10
            Position.STRIKER -> 9
        }
        for (i in 0 until 11) {
            val wob = sin(time * 1.7f + i) * 1.1f
            val mxw = FX[i] * 105f + shift * (if (i == 0) 0.2f else 1f)
            val myw = FY[i] * 68f + wob
            val px = cam.sx(myw); val py = cam.sy(mxw)
            ui.circle(c, px, py, rad, myShirt)
            ui.stroke.color = withAlpha(Palette.WHITE, 200); ui.stroke.strokeWidth = 2f
            c.drawCircle(px, py, rad, ui.stroke)
            val oxw = 105f - FX[i] * 105f + shift * (if (i == 0) 0.2f else 1f)
            val oyw = 68f - FY[i] * 68f + wob
            ui.circle(c, cam.sx(oyw), cam.sy(oxw), rad, oppShirt)
            c.drawCircle(cam.sx(oyw), cam.sy(oxw), rad, ui.stroke)
            if (i == idx && e.minute in e.startMinute..e.endMinute) {
                ui.stroke.color = Palette.GOLD; ui.stroke.strokeWidth = 4f
                c.drawCircle(px, py, rad + 6f + sin(time * 5f) * 2f, ui.stroke)
                ui.text(c, "TÚ", px, py - rad - 14f, 22f, Palette.GOLD, Paint.Align.CENTER)
            }
        }
        ui.ball(c, cam.sx(bwy), cam.sy(bwx), max(5f, z * 0.6f), spin)
        if (phase == Phase.SIM) ui.text(c, if (speed > 1f) "VELOCIDAD x3  (toca para normal)" else "Toca la pantalla: velocidad x3", 360f, 1252f, 20f, withAlpha(Palette.WHITE, 170), Paint.Align.CENTER)
    }

    private fun figS() = cam.zoom * 2.3f / 83f

    private fun drawScene(c: Canvas, e: MatchSimulationEngine) {
        val s = sess
        val z = cam.zoom; val sc = figS()
        val m = s?.moment
        // trayectoria entrante (reacción) y punto de contacto
        if (m != null && phase != Phase.FLIGHT) {
            val inc = m.incoming
            if (inc != null) {
                ui.dash.color = withAlpha(Palette.WHITE, 120)
                var i = 1
                while (i < inc.samples.size) {
                    val a = inc.samples[i - 1]; val b = inc.samples[i]
                    c.drawLine(cam.sx(a.y), cam.sy(a.x) - a.z * z * 0.5f, cam.sx(b.y), cam.sy(b.x) - b.z * z * 0.5f, ui.dash)
                    i += 2
                }
            }
            val cp = m.contact
            if (cp != null && s != null && m.mode != MomentMode.POSITIONING) {
                val u = (s.elapsed / s.window).coerceIn(0f, 1f)
                val rr = 14f + 70f * (1f - u)
                ui.stroke.color = withAlpha(if (m.mode == MomentMode.ACROBATIC) Palette.RED else Palette.GOLD, 230); ui.stroke.strokeWidth = 4f
                c.drawCircle(cam.sx(cp.pos.y), cam.sy(cp.pos.x) - cp.z * z * 0.5f, rr, ui.stroke)
            }
        }
        // rivales y portero
        for (i in curR.indices) { val d = curR[i]; ui.opponent(c, wx(d), wy(d) + 20f * sc, sc, oppShirt, oppShorts, if (i % 2 == 0) 1f else -1f, time * 6f, phase == Phase.MOMENT) }
        val kv = curK
        if (kv != null) ui.figure(c, wx(kv), wy(kv) + 20f * sc, sc, 0xFFD9A77F.toInt(), 0xFF2A1A10.toInt(), 1, 0xFF22AA44.toInt(), 0xFF145A26.toInt(), 0xFF145A26.toInt(), 1f, 0f, false)
        // compañeros: pistas de Vision (más sutiles cuanto peor es la lectura de juego)
        val rq = m?.readQuality ?: 0f
        val showHints = phase != Phase.FLIGHT && s != null
        for (i in curM.indices) {
            val t = curM[i]
            if (showHints && s != null && i < s.world.mates.size) {
                val mt = s.world.mates[i]
                val open = TeammateAI.openness(mt, s.world.rivals)
                val al = (40 + 160 * rq).toInt()
                val col = if (open > 0.55f) Palette.ACCENT else if (open > 0.3f && rq > 0.4f) Palette.GOLD else if (rq > 0.6f) Palette.RED else 0
                if (col != 0) {
                    ui.stroke.color = withAlpha(col, al); ui.stroke.strokeWidth = 3f
                    c.drawCircle(wx(t), wy(t), z * 1.5f + sin(time * 5f + i) * 1.5f, ui.stroke)
                }
                if (rq > 0.35f) {
                    ui.line(c, wx(t), wy(t), cam.sx(mt.run.y), cam.sy(mt.run.x), 2f, withAlpha(Palette.WHITE, 70))
                }
            }
            ui.figure(c, wx(t), wy(t) + 20f * sc, sc, 0xFFEAB98C.toInt(), 0xFF2A1A10.toInt(), 0, myShirt, myShorts, darken(myShirt, 0.7f), 1f, time * 8f, false)
        }
        if (m != null && showHints && rq >= 0.55f && m.mode == MomentMode.POSITIONING) {
            for (h in m.spaceHints) {
                ui.circle(c, wx(h), wy(h), 5f + sin(time * 4f) * 1.5f, withAlpha(Palette.GOLD, (60 + 120 * rq).toInt()))
            }
        }
        // protagonista
        val moving = (phase == Phase.MOMENT && touch == Touch.MOVE) || (phase == Phase.FLIGHT && curP.dist(toP) > 0.2f)
        val jump = if (phase == Phase.FLIGHT && celebrate && holding) abs(sin(holdT * 9f)) * 16f else 0f
        val px = wx(curP); val py = wy(curP) + 20f * sc
        ui.player(c, px, py, sc * 1.08f, e.player.appearance, myShirt, myShorts, 1f, time * 14f, moving, jump)
        if (phase != Phase.FLIGHT) ui.icon(c, ICON_DOWN, px, py - 100f * sc - 8f + sin(time * 6f) * 3f, 9f, Palette.GOLD)
        // balón (con altura, sombra y estela)
        val bx = wx(ballPos); val by = wy(ballPos)
        val h = ballZ * z * 0.5f
        if (phase == Phase.FLIGHT) {
            val tNow = beatT * beatScale
            for (k in 1..4) {
                val q = sampleAt(trailSamples, max(0f, tNow - k * 0.05f))
                ui.circle(c, cam.sx(q.y), cam.sy(q.x) - q.z * z * 0.5f, max(3f, z * 0.45f) * (1f - k * 0.18f), withAlpha(Palette.WHITE, 90 - k * 18))
            }
        }
        if (h > 1f) ui.circle(c, bx, by, max(4f, z * 0.4f), 0x55000000)
        ui.ball(c, bx, by - h, max(6f, z * 0.62f), spin)
    }

    // ------------------------------------------------------------------ interfaz del momento
    private fun intentLabel(k: IntentKind) = when (k) {
        IntentKind.PASS -> "PASE"; IntentKind.SPACE_PASS -> "AL ESPACIO"; IntentKind.SHOT -> "TIRO"
        IntentKind.CROSS -> "CENTRO"; IntentKind.HEADER -> "CABEZAZO"; IntentKind.CLEARANCE -> "DESPEJE"
        IntentKind.CONTROL -> "PRIMER TOQUE"; IntentKind.INTERCEPT -> "INTERCEPTAR"; IntentKind.VOLLEY -> "REMATE"
        IntentKind.CHILENA -> "CHILENA"; IntentKind.BLOCK -> "BLOQUEO"
    }

    private fun drawMomentUi(c: Canvas) {
        val s = sess ?: return
        val m = s.moment
        // banner del momento
        val k = Ease.outBack((pt / 0.35f).coerceIn(0f, 1f).let { if (phase == Phase.MOMENT) 1f else it })
        if (s.phase != MomentSession.Phase.CONTACT) {
            c.save(); c.scale(k, k, 360f, 150f)
            ui.panel(c, 60f, 108f, 600f, 86f, withAlpha(0xFF050B14.toInt(), 220), if (m.mode == MomentMode.POSITIONING) Palette.GOLD else Palette.RED, 16f)
            ui.text(c, m.type.label, 84f, 158f, 40f, Palette.GOLD)
            val tag = when (m.mode) { MomentMode.POSITIONING -> "POSICIÓNATE"; MomentMode.REACTION -> "¡REACCIONA!"; MomentMode.ACROBATIC -> "¡ACROBACIA!" }
            ui.text(c, tag, 636f, 150f, 22f, if (m.mode == MomentMode.POSITIONING) Palette.ACCENT else Palette.RED, Paint.Align.RIGHT)
            ui.textFit(c, m.context, 636f, 180f, 20f, 360f, Palette.WHITE, Paint.Align.RIGHT)
            c.restore()
        }
        if (phase != Phase.MOMENT) return
        when (s.phase) {
            MomentSession.Phase.POSITIONING -> {
                val px = wx(curP); val py = wy(curP)
                if (s.timeLeft > 0f) {
                    ui.rect.set(px - 46f, py - 46f, px + 46f, py + 46f)
                    ui.stroke.color = withAlpha(Palette.ACCENT, 230); ui.stroke.strokeWidth = 5f
                    c.drawArc(ui.rect, -90f, 360f * (s.timeLeft / s.window), false, ui.stroke)
                    if (touch == Touch.MOVE) ui.line(c, px, py, fingerX, fingerY, 4f, withAlpha(Palette.WHITE, 150))
                    ui.text(c, "ARRASTRA PARA MOVERTE", 360f, 1196f, 24f, withAlpha(Palette.WHITE, 220 - (sin(time * 4f) * 40f).toInt()), Paint.Align.CENTER)
                    ui.text(c, "ARRASTRA DESDE EL BALÓN PARA EJECUTAR", 360f, 1228f, 20f, withAlpha(Palette.GOLD, 220), Paint.Align.CENTER)
                } else {
                    ui.text(c, "ARRASTRA DESDE EL BALÓN", 360f, 1210f, 26f, withAlpha(Palette.GOLD, 230), Paint.Align.CENTER)
                }
            }
            MomentSession.Phase.AIM -> {
                if (s.isReaction) {
                    val u = (s.elapsed / s.window).coerceIn(0f, 1f)
                    ui.bar(c, 110f, 212f, 500f, 14f, 1f - u, if (u < 0.7f) Palette.ACCENT else Palette.RED)
                    if (touch != Touch.AIM) ui.text(c, "¡ARRASTRA YA!", 360f, 1210f, 34f, withAlpha(Palette.RED, 230 - (sin(time * 8f) * 50f).toInt()), Paint.Align.CENTER)
                }
                if (touch == Touch.AIM) drawAim(c, s)
            }
            MomentSession.Phase.CONTACT -> drawContact(c, s)
            else -> {}
        }
    }

    private fun drawAim(c: Canvas, s: MomentSession) {
        val len = hypot(dragX, dragY)
        val power = AimPhase.power(len)
        val col = if (power < 0.5f) Palette.ACCENT else if (power < 0.85f) Palette.GOLD else Palette.RED
        val ex = anchorX + dragX; val ey = anchorY + dragY
        val pv = preview
        if (pv != null) {
            val smp = pv.samples
            if (smp != null) {
                val cnt = (smp.size * 0.7f).toInt()
                var i = 0
                while (i < cnt) {
                    val q = smp[i]
                    val lofted = q.z > 0.4f
                    ui.circle(c, cam.sx(q.y), cam.sy(q.x) - q.z * cam.zoom * 0.5f, if (lofted) 4.5f else 3.5f, withAlpha(if (lofted) Palette.WHITE else Palette.GOLD, 200))
                    i += 2
                }
            }
            ui.text(c, intentLabel(pv.intent.kind), ex, ey - 26f, 26f, Palette.WHITE, Paint.Align.CENTER)
        }
        ui.line(c, anchorX, anchorY, ex, ey, 8f, withAlpha(col, 230))
        ui.circle(c, ex, ey, 14f, col)
        ui.text(c, "FUERZA", 360f, 1210f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.bar(c, 160f, 1224f, 400f, 20f, power, col)
    }

    private fun drawContact(c: Canvas, s: MomentSession) {
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, withAlpha(0xFF050B14.toInt(), 215))
        val it = s.intent; val a = s.aim
        if (it != null && a != null)
            ui.text(c, intentLabel(it.kind) + "  ·  FUERZA ${(a.power * 100).toInt()}%", 360f, 190f, 34f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, "TOCA DÓNDE GOLPEAS EL BALÓN", 360f, 236f, 24f, Palette.WHITE, Paint.Align.CENTER)
        ui.ball(c, CB_X, CB_Y, CB_R, 0.6f)
        ui.stroke.color = withAlpha(0xFF222222.toInt(), 120); ui.stroke.strokeWidth = 2f
        c.drawCircle(CB_X, CB_Y, CB_R * ContactPhase.DEAD, ui.stroke)
        c.drawLine(CB_X - CB_R, CB_Y, CB_X + CB_R, CB_Y, ui.stroke)
        c.drawLine(CB_X, CB_Y - CB_R, CB_X, CB_Y + CB_R, ui.stroke)
        ui.text(c, "RASANTE", CB_X, CB_Y - CB_R - 18f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, "ELEVADO", CB_X, CB_Y + CB_R + 34f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, "← EFECTO", CB_X - CB_R - 4f, CB_Y - CB_R - 18f, 18f, Palette.TEXT_DIM, Paint.Align.LEFT)
        ui.text(c, "EFECTO →", CB_X + CB_R + 4f, CB_Y - CB_R - 18f, 18f, Palette.TEXT_DIM, Paint.Align.RIGHT)
        val mx = CB_X + cNx.coerceIn(-1f, 1f) * CB_R; val my = CB_Y - cNy.coerceIn(-1f, 1f) * CB_R
        ui.line(c, CB_X, CB_Y, mx, my, 4f, withAlpha(Palette.GOLD, 160))
        ui.circle(c, mx, my, 16f, Palette.GOLD)
        ui.stroke.color = Palette.WHITE; ui.stroke.strokeWidth = 3f; c.drawCircle(mx, my, 16f, ui.stroke)
        val ct = ContactPhase.fromTouch(cNx, cNy)
        val curve = if (abs(ct.ix) < 0.12f) "recto" else if (ct.ix > 0f) "efecto a la derecha" else "efecto a la izquierda"
        val lift = if (abs(ct.iy) < 0.12f) "trayectoria neutra" else if (ct.iy < 0f) "elevado" else "rasante y potente"
        ui.text(c, "$curve  ·  $lift", 360f, 1040f, 26f, Palette.WHITE, Paint.Align.CENTER)
        ui.text(c, "Suelta para golpear", 360f, 1090f, 22f, Palette.ACCENT, Paint.Align.CENTER)
    }

    private fun drawBanner(c: Canvas) {
        val k = Ease.outBack((bannerT / 0.3f).coerceIn(0f, 1f))
        c.save(); c.scale(k, k, 360f, 250f)
        ui.text(c, bannerHead, 360f, 260f, if (celebrate) 84f else 58f, bannerColor, Paint.Align.CENTER)
        if (bannerDetail.isNotEmpty()) ui.textFit(c, bannerDetail, 360f, 306f, 28f, 660f, Palette.WHITE, Paint.Align.CENTER)
        c.restore()
    }

    private fun drawHud(c: Canvas, e: MatchSimulationEngine) {
        val sec = e.clockSeconds.toInt().coerceAtMost(5400)
        if (sec != clockSec) { clockSec = sec; clockStr = "%02d:%02d".format(sec / 60, sec % 60) }
        val key = e.homeGoals * 100 + e.awayGoals
        if (key != scoreKey) {
            scoreKey = key
            scoreStr = "${e.home.abbr}  ${e.homeGoals} - ${e.awayGoals}  ${e.away.abbr}"
            ratingStr = "%.1f".format(e.currentRating())
        }
        ui.panel(c, 130f, 8f, 380f, 88f, withAlpha(0xFF050B14.toInt(), 215), Palette.PANEL_LIGHT, 16f)
        ui.text(c, clockStr, 320f, 40f, 28f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, scoreStr, 320f, 82f, 34f, Palette.WHITE, Paint.Align.CENTER)
        ui.circle(c, 156f, 52f, 12f, e.home.primary); ui.circle(c, 484f, 52f, 12f, e.away.primary)
        ui.panel(c, 560f, 8f, 144f, 88f, withAlpha(0xFF050B14.toInt(), 200), Palette.PANEL_LIGHT, 14f)
        ui.text(c, ratingStr, 632f, 70f, 44f, Palette.ACCENT, Paint.Align.CENTER)
        ui.text(c, "RATING", 632f, 32f, 14f, Palette.TEXT_DIM, Paint.Align.CENTER)
        if (phase == Phase.SIM) {
            if (e.events.size != evCount) {
                evCount = e.events.size
                val ev = e.events[e.events.size - 1]
                evStr = "%02d'  %s".format(ev.minute, ev.text)
            }
            ui.textFit(c, evStr, 360f, 1208f, 26f, 680f, Palette.WHITE, Paint.Align.CENTER)
        }
    }
}
