package com.goatjourney.core.match

import com.goatjourney.core.player.Attributes
import kotlin.math.*
import kotlin.random.Random

/**
 * Controla al protagonista cuando el usuario no interviene (SIMULATE): genera movimiento, dirección,
 * fuerza y punto de contacto y los pasa por la MISMA MomentSession / ActionResolver que el gesto humano.
 */
object AIPlayerController {
    private val GOAL = Vec(Pitch.LENGTH, Pitch.CENTER_Y)

    fun play(s: MomentSession, a: Attributes, rng: Random): ActionResult {
        val m = s.moment
        if (m.mode == MomentMode.POSITIONING) positionAI(s, a, rng)
        else s.advanceTo(s.window * (0.35f + rng.nextFloat() * 0.45f))
        val g = chooseGesture(s, a, rng)
        if (m.mode == MomentMode.POSITIONING) s.beginAim()
        s.releaseAim(g.dir, AimPhase.dragFor(g.power))
        val done = s.result
        if (s.phase == MomentSession.Phase.DONE && done != null) return done
        val tech = (a.control * 0.6f + a.dribbling * 0.2f + a.composure * 0.2f) / 100f
        val n = (1f - tech) * 0.12f
        return s.commitContact(g.ix + rng.gauss() * n, g.iy + rng.gauss() * n)
    }

    private class Gesture(val dir: Vec, val power: Float, val ix: Float, val iy: Float)

    private fun positionAI(s: MomentSession, a: Attributes, rng: Random) {
        val w = s.world
        val dec = a.decisions / 100f
        var bestDir = Vec(1f, 0f); var bestScore = -1e9f
        val reach = min(s.maxMove, s.runSpeed * 0.8f * s.window * 0.7f)
        for (i in 0 until 8) {
            val d = Vec(1f, 0f).rot(i * 0.7854f)
            val p = Geo.clampPitch(w.player + d * reach)
            var near = 99f
            for (r in w.rivals) near = min(near, r.pos.dist(p))
            var score = min(near, 9f) * 1.0f
            if (IntentKind.SHOT in s.moment.actions) score += (1f - p.dist(GOAL) / 60f) * 6f
            else score += (p.x / 105f) * 3f
            score += rng.gauss() * (1f - dec) * 2.5f
            if (score > bestScore) { bestScore = score; bestDir = d }
        }
        var t = 0f
        s.setMove(bestDir, 1f)
        while (t < s.window * 0.7f && s.canMove()) { s.update(0.05f); t += 0.05f }
        s.setMove(null, 0f)
    }

    private fun powerFor(s: MomentSession, dir: Vec, targetDist: Float, c: Contact): Float {
        var bestP = 0.5f; var bestCost = 1e9f
        var p = 0.15f
        while (p <= 1.001f) {
            val tr = s.previewAt(dir, p, c)
            if (tr != null) {
                var md = 1e9f
                val tp = s.origin() + dir * targetDist
                for (smp in tr.samples) md = min(md, hypot(smp.x - tp.x, smp.y - tp.y))
                val cost = md + 0.15f * p
                if (cost < bestCost) { bestCost = cost; bestP = p }
            }
            p += 0.05f
        }
        return bestP
    }

    private fun shotGesture(s: MomentSession, a: Attributes, rng: Random): Gesture {
        val o = s.origin()
        val kp = s.world.keeper
        val side = if ((kp?.pos?.y ?: 34f) >= 34f) -1f else 1f
        val ty = Pitch.CENTER_Y + side * rng.nextFloat().coerceIn(0.4f, 1f) * 2.6f
        val dir = Vec(Pitch.LENGTH - o.x, ty - o.y).norm()
        return Gesture(dir, 0.75f + rng.nextFloat() * 0.15f, 0f, 0.15f)
    }

    private fun chooseGesture(s: MomentSession, a: Attributes, rng: Random): Gesture {
        val m = s.moment
        val w = s.world
        val o = s.origin()
        val dec = a.decisions / 100f
        when (m.type) {
            KeyMomentType.HEADER_MOMENT, KeyMomentType.VOLLEY_MOMENT, KeyMomentType.CHILENA_MOMENT -> return shotGesture(s, a, rng)
            KeyMomentType.INTERCEPTION_MOMENT -> {
                val cp = m.contact?.pos ?: o
                val d = w.player.dist(cp)
                return Gesture((cp - w.player).norm(), ((d - 1.5f) / 6.5f).coerceIn(0.2f, 1f), 0f, 0f)
            }
            KeyMomentType.CLEARANCE_MOMENT ->
                return Gesture(Vec(0.5f, if (o.y > 34f) 0.8f else -0.8f).rot(rng.gauss() * (1f - dec) * 0.15f).norm(), 0.85f, 0f, -0.3f)
            KeyMomentType.FIRST_TOUCH_MOMENT -> {
                val open = Vec(Pitch.LENGTH - o.x, Pitch.CENTER_Y - o.y).norm()
                return Gesture(open.rot(rng.gauss() * 0.3f), 0.3f, 0f, 0f)
            }
            KeyMomentType.CROSS_MOMENT -> {
                val tgt = Vec(rng.nextFloat() * 5f + 92f, 34f + rng.gauss() * 3f)
                val dir = (tgt - o).norm()
                val c = Contact(0f, -0.25f)
                return Gesture(dir, powerFor(s, dir, o.dist(tgt), c), 0f, -0.25f)
            }
            else -> {}
        }
        // PASE / TIRO / REBOTE / PARED: ¿tirar o pasar?
        val dist = o.dist(GOAL)
        val canShoot = IntentKind.SHOT in m.actions
        val shotValue = if (canShoot && dist < 32f) ((1f - (dist - 6f) / 26f).coerceIn(0.05f, 1f)) * (0.45f + a.finishing / 100f * 0.6f) else 0f
        var bestMate: Mate? = null; var bestVal = -1f
        for (mt in w.mates) {
            val open = TeammateAI.openness(mt, w.rivals)
            val prog = ((mt.pos.x - o.x) / 40f).coerceIn(-0.3f, 0.8f)
            val dd = mt.pos.dist(o)
            var v = open * 0.6f + prog * 0.4f + (if (mt.pos.x > 78f) 0.15f else 0f)
            if (dd < 6f || dd > 38f) v -= 0.3f
            v += rng.gauss() * (1f - dec) * 0.2f
            if (v > bestVal) { bestVal = v; bestMate = mt }
        }
        val shotWins = canShoot && (m.mode != MomentMode.POSITIONING || shotValue + rng.gauss() * 0.05f >= bestVal * 0.55f) && shotValue > 0f
        if (shotWins || bestMate == null) {
            if (canShoot) return shotGesture(s, a, rng)
            val dir = Vec(1f, rng.gauss() * 0.3f).norm()
            return Gesture(dir, 0.5f, 0f, 0f)
        }
        val mt = bestMate!!
        val lead = mt.pos + (mt.run - mt.pos).norm() * 2.5f
        val dir = (lead - o).norm()
        val c = Contact(0f, 0f)
        return Gesture(dir, powerFor(s, dir, o.dist(lead), c), 0f, 0f)
    }
}
