package com.goatjourney.core.career

import com.goatjourney.core.match.MatchImportance
import com.goatjourney.core.player.Player
import com.goatjourney.core.player.PlayerStats
import com.goatjourney.core.simulation.MatchResult
import kotlinx.serialization.Serializable
import kotlin.math.exp
import kotlin.math.pow
import kotlin.random.Random

@Serializable
data class Club(val id: Int, val name: String, val abbr: String, val primary: Int, val secondary: Int, val strength: Int)

@Serializable enum class EntryType { TRAINING, MATCH }
@Serializable enum class MatchStatus { SCHEDULED, PLAYED }

@Serializable
data class Fixture(
    val id: Int, val matchday: Int, val day: Int, val homeId: Int, val awayId: Int,
    var status: MatchStatus = MatchStatus.SCHEDULED, var homeGoals: Int = 0, var awayGoals: Int = 0,
    val importance: MatchImportance = MatchImportance.NORMAL
)

@Serializable
data class CalendarEntry(val day: Int, val type: EntryType, val fixtureId: Int = -1)

@Serializable
data class TableRow(
    val clubId: Int, var played: Int = 0, var won: Int = 0, var drawn: Int = 0, var lost: Int = 0,
    var gf: Int = 0, var ga: Int = 0, var points: Int = 0
) { val gd: Int get() = gf - ga }

@Serializable
data class MatchRecord(
    val season: Int, val matchday: Int, val opponent: String, val home: Boolean,
    val goalsFor: Int, val goalsAgainst: Int, val rating: Float, val goals: Int, val assists: Int, val minutes: Int
)

/** Estado central y serializable de la carrera. Nada aquí depende del renderizado. */
@Serializable
data class CareerState(
    var player: Player,
    var clubs: List<Club>,
    var season: Int,
    var currentDay: Int,
    var competition: String,
    var calendar: List<CalendarEntry>,
    var fixtures: MutableList<Fixture>,
    var calendarIndex: Int,
    var table: MutableList<TableRow>,
    var careerStats: PlayerStats,
    var seasonStats: PlayerStats,
    var matchHistory: MutableList<MatchRecord>,
    var saveVersion: Int
) {
    fun clubById(id: Int): Club = clubs.first { it.id == id }
    fun club(): Club = clubById(player.clubId)
    fun nextEntry(): CalendarEntry? = calendar.getOrNull(calendarIndex)
    fun fixtureOf(e: CalendarEntry): Fixture? = if (e.fixtureId < 0) null else fixtures.firstOrNull { it.id == e.fixtureId }
    fun seasonOver(): Boolean = calendarIndex >= calendar.size
    fun tablePosition(): Int = table.indexOfFirst { it.clubId == player.clubId } + 1
}

object CareerDate {
    private val names = arrayOf("SEP", "OCT", "NOV", "DIC", "ENE", "FEB", "MAR", "ABR", "MAY", "JUN")
    private val len = intArrayOf(30, 31, 30, 31, 31, 28, 31, 30, 31, 30)
    fun format(day: Int): String {
        var d = day; var m = 0
        while (m < len.size - 1 && d >= len[m]) { d -= len[m]; m++ }
        return "%02d %s".format(d + 1, names[m])
    }
}

object CareerFactory {
    const val SAVE_VERSION = 1
    const val COMPETITION = "Liga Regional"

    val CLUBS: List<Club> = listOf(
        Club(0, "GOAT United", "GOU", 0xFF1E88E5.toInt(), 0xFFFFFFFF.toInt(), 38),
        Club(1, "Deportivo Norte", "DNO", 0xFFD32F2F.toInt(), 0xFFFFFFFF.toInt(), 52),
        Club(2, "Atlético Central", "ACE", 0xFFFFC107.toInt(), 0xFF212121.toInt(), 58),
        Club(3, "Real del Sur", "RSU", 0xFF7B1FA2.toInt(), 0xFFFFFFFF.toInt(), 60),
        Club(4, "Sporting Valle", "SVA", 0xFF2E7D32.toInt(), 0xFFFFFFFF.toInt(), 48),
        Club(5, "CD Montaña", "CMO", 0xFF6D4C41.toInt(), 0xFFFFE0B2.toInt(), 45),
        Club(6, "Atlético Norte", "ANO", 0xFFEF6C00.toInt(), 0xFF212121.toInt(), 55),
        Club(7, "Unión Costera", "UCO", 0xFF00ACC1.toInt(), 0xFFFFFFFF.toInt(), 50),
        Club(8, "FC Puerto", "FPU", 0xFF37474F.toInt(), 0xFFFFFFFF.toInt(), 42),
        Club(9, "Racing Oeste", "ROE", 0xFFC2185B.toInt(), 0xFFFFFFFF.toInt(), 47)
    )

    fun newCareer(player: Player): CareerState {
        player.clubId = 0
        val (fixtures, calendar) = generateSeason(CLUBS, player.clubId)
        return CareerState(
            player, CLUBS, 1, 0, COMPETITION, calendar, fixtures, 0, freshTable(CLUBS),
            PlayerStats(), PlayerStats(), mutableListOf(), SAVE_VERSION
        )
    }

    fun freshTable(clubs: List<Club>): MutableList<TableRow> = clubs.map { TableRow(it.id) }.toMutableList()

    fun generateSeason(clubs: List<Club>, myClubId: Int): Pair<MutableList<Fixture>, List<CalendarEntry>> {
        val n = clubs.size
        val ids = clubs.map { it.id }.toMutableList()
        val rounds = n - 1
        val first = ArrayList<List<Pair<Int, Int>>>()
        for (r in 0 until rounds) {
            val pairs = ArrayList<Pair<Int, Int>>()
            for (i in 0 until n / 2) {
                val a = ids[i]; val b = ids[n - 1 - i]
                pairs.add(if ((r + i) % 2 == 0) a to b else b to a)
            }
            first.add(pairs)
            val last = ids.removeAt(n - 1); ids.add(1, last)
        }
        val fixtures = mutableListOf<Fixture>()
        val calendar = mutableListOf<CalendarEntry>()
        var fid = 0
        for (md in 0 until rounds * 2) {
            val pairs = if (md < rounds) first[md] else first[md - rounds].map { it.second to it.first }
            val imp = if (md == rounds - 1 || md == rounds * 2 - 1) MatchImportance.IMPORTANT else MatchImportance.NORMAL
            var mine: Fixture? = null
            for ((h, a) in pairs) {
                val f = Fixture(fid++, md, md * 7 + 3, h, a, importance = imp)
                fixtures.add(f)
                if (h == myClubId || a == myClubId) mine = f
            }
            calendar.add(CalendarEntry(md * 7 + 1, EntryType.TRAINING))
            calendar.add(CalendarEntry(md * 7 + 3, EntryType.MATCH, mine!!.id))
        }
        return fixtures to calendar
    }
}

object CareerManager {
    private fun sortTable(s: CareerState) {
        s.table.sortWith(compareByDescending<TableRow> { it.points }.thenByDescending { it.gd }.thenByDescending { it.gf })
    }

    private fun updateRow(s: CareerState, f: Fixture) {
        val h = s.table.first { it.clubId == f.homeId }
        val a = s.table.first { it.clubId == f.awayId }
        h.played++; a.played++
        h.gf += f.homeGoals; h.ga += f.awayGoals
        a.gf += f.awayGoals; a.ga += f.homeGoals
        when {
            f.homeGoals > f.awayGoals -> { h.won++; h.points += 3; a.lost++ }
            f.homeGoals < f.awayGoals -> { a.won++; a.points += 3; h.lost++ }
            else -> { h.drawn++; a.drawn++; h.points++; a.points++ }
        }
    }

    private fun poisson(lambda: Float, rng: Random): Int {
        val l = exp(-lambda); var k = 0; var p = 1f
        do { k++; p *= rng.nextFloat() } while (p > l)
        return k - 1
    }

    /** Resultado abstracto para los partidos en los que el jugador no participa. */
    fun quickScore(h: Club, a: Club, rng: Random): Pair<Int, Int> {
        val hs = h.strength + 3f; val aw = a.strength.toFloat()
        return poisson(1.3f * (hs / aw).pow(0.9f), rng) to poisson(1.1f * (aw / hs).pow(0.9f), rng)
    }

    fun applyResult(s: CareerState, r: MatchResult, rng: Random = Random) {
        val fx = s.fixtures.first { it.id == r.fixtureId }
        fx.status = MatchStatus.PLAYED; fx.homeGoals = r.homeGoals; fx.awayGoals = r.awayGoals
        updateRow(s, fx)
        for (o in s.fixtures) {
            if (o.matchday == fx.matchday && o.status == MatchStatus.SCHEDULED && o.id != fx.id) {
                val (hg, ag) = quickScore(s.clubById(o.homeId), s.clubById(o.awayId), rng)
                o.status = MatchStatus.PLAYED; o.homeGoals = hg; o.awayGoals = ag
                updateRow(s, o)
            }
        }
        sortTable(s)
        s.careerStats.add(r.stats); s.seasonStats.add(r.stats)
        val oppId = if (r.playerHome) fx.awayId else fx.homeId
        s.matchHistory.add(
            MatchRecord(
                s.season, fx.matchday + 1, s.clubById(oppId).name, r.playerHome,
                if (r.playerHome) r.homeGoals else r.awayGoals, if (r.playerHome) r.awayGoals else r.homeGoals,
                r.rating, r.stats.goals, r.stats.assists, r.playerMinutes
            )
        )
        advance(s)
    }

    fun advance(s: CareerState) {
        s.calendarIndex++
        s.currentDay = s.calendar.getOrNull(s.calendarIndex)?.day ?: (s.calendar.last().day + 1)
    }

    /** Nueva temporada: +1 año de edad, calendario y tabla nuevos. (Sin progresión en 0.1.) */
    fun startNewSeason(s: CareerState) {
        val (fx, cal) = CareerFactory.generateSeason(s.clubs, s.player.clubId)
        s.season++; s.player.age++
        s.fixtures = fx; s.calendar = cal; s.calendarIndex = 0; s.currentDay = 0
        s.table = CareerFactory.freshTable(s.clubs)
        s.seasonStats = PlayerStats()
    }
}
