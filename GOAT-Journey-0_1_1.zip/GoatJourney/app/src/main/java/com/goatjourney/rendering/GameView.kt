package com.goatjourney.rendering

import android.content.Context
import android.graphics.Canvas
import android.os.Build
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.goatjourney.game.GameController

/** Vista Canvas única del juego. El hilo ejecuta: update(dt) -> render(canvas). */
class GameView(context: Context, private val game: GameController) : SurfaceView(context), SurfaceHolder.Callback {
    private var thread: LoopThread? = null

    init { holder.addCallback(this); isFocusable = true }

    override fun surfaceCreated(h: SurfaceHolder) {
        thread = LoopThread(h).also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) { game.viewport.resize(w, hh) }

    override fun surfaceDestroyed(h: SurfaceHolder) {
        val t = thread ?: return
        t.running = false
        try { t.join() } catch (e: InterruptedException) { }
        thread = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean { game.touch.onMotionEvent(event); return true }

    private inner class LoopThread(private val h: SurfaceHolder) : Thread("GameLoop") {
        @Volatile var running = true
        override fun run() {
            var last = System.nanoTime()
            while (running) {
                val now = System.nanoTime()
                val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
                last = now
                game.update(dt)
                var c: Canvas? = null
                try {
                    c = if (Build.VERSION.SDK_INT >= 26) h.lockHardwareCanvas() else h.lockCanvas()
                    if (c != null) game.render(c)
                } catch (e: Exception) {
                } finally {
                    if (c != null) try { h.unlockCanvasAndPost(c) } catch (e: Exception) { }
                }
                val spent = (System.nanoTime() - now) / 1_000_000L
                if (spent < 16) try { sleep(16 - spent) } catch (e: InterruptedException) { }
            }
        }
    }
}
