package com.goatjourney.core.match

import kotlin.math.*
import kotlin.random.Random

/** IA rival: marca, presiona, cierra espacios. No es perfecta (retardo de reacción, marcajes sencillos). */
object OpponentAI {
    fun nearest(p: Vec, rivals: List<Rival>): Int {
        var bi = -1; var bd = 1e9f
        for (i in rivals.indices) { val d = rivals[i].pos.dist(p); if (d < bd) { bd = d; bi = i } }
        return bi
    }

    /** 0 = libre, 1 = completamente agobiado. */
    fun pressureAt(p: Vec, rivals: List<Rival>): Float {
        var d1 = 99f; var d2 = 99f
        for (r in rivals) {
            val d = r.pos.dist(p)
            if (d < d1) { d2 = d1; d1 = d } else if (d < d2) d2 = d
        }
        return ((1f - d1 / 8f).coerceIn(0f, 1f) * 0.75f + (1f - d2 / 10f).coerceIn(0f, 1f) * 0.25f)
    }

    fun step(w: World, ball: Vec, dt: Float, carrier: Boolean, elapsed: Float) {
        if (w.rivals.isNotEmpty()) {
            val marker = nearest(w.player, w.rivals)
            for (i in w.rivals.indices) {
                val r = w.rivals[i]
                val target: Vec
                var k = 0.85f
                if (i == marker) {
                    target = if (carrier) w.player + (r.pos - w.player).norm() * 1.6f else ball
                    if (carrier && elapsed < 0.4f) k = 0.55f
                } else {
                    var bi = -1; var bd = 1e9f
                    for (j in w.mates.indices) { val d = w.mates[j].pos.dist(r.pos); if (d < bd) { bd = d; bi = j } }
                    target = if (bi >= 0) {
                        val m = w.mates[bi]
                        Vec(m.pos.x + 1.8f, m.pos.y + (Pitch.CENTER_Y - m.pos.y) * 0.06f)
                    } else r.pos
                    k = 0.7f
                }
                val d = r.pos.dist(target)
                if (d > 0.25f) r.pos = r.pos + (target - r.pos).norm() * min(d, r.speed() * k * dt)
            }
        }
        val kp = w.keeper
        if (kp != null) {
            val ty = Pitch.CENTER_Y + (ball.y - Pitch.CENTER_Y) * 0.15f
            kp.pos = Vec(kp.pos.x, kp.pos.y + (ty - kp.pos.y).coerceIn(-3f * dt, 3f * dt))
        }
    }
}

/** IA de compañeros: se desmarcan hacia su destino y deciden qué hacer con el balón. */
object TeammateAI {
    enum class Decision { SHOOT, RETURN, PASS_OTHER, CROSS, LOSE }

    class Ctx(
        val ball: Vec, val pressure: Float, val fromPlayer: Boolean, val passDist: Float,
        val player: Vec, val playerIsFree: Boolean, val depth: Int, val hasOthers: Boolean
    )

    fun step(w: World, dt: Float) {
        for (m in w.mates) {
            val d = m.pos.dist(m.run)
            if (d > 0.3f) m.pos = m.pos + (m.run - m.pos).norm() * min(d, m.speed() * 0.9f * dt)
        }
    }

    fun openness(m: Mate, rivals: List<Rival>): Float {
        var d = 99f
        for (r in rivals) d = min(d, r.pos.dist(m.pos))
        return (d / 9f).coerceIn(0.05f, 1f)
    }

    fun decide(m: Mate, c: Ctx, rng: Random): Decision {
        val toGoal = hypot(Pitch.LENGTH - m.pos.x, Pitch.CENTER_Y - m.pos.y)
        val inRange = toGoal < 30f && m.pos.x > 70f
        val roleShoot = when (m.role) { Role.FWD -> 1f; Role.WING -> 0.75f; Role.MID -> 0.45f; else -> 0.1f }
        val wShoot = if (inRange) roleShoot * (1.2f - toGoal / 40f).coerceAtLeast(0.1f) * (0.4f + m.quality * 0.8f) else 0.02f
        val wide = abs(m.pos.y - Pitch.CENTER_Y) > 20f && m.pos.x > 62f
        val wCross = if (wide) 0.8f else 0f
        val wReturn = if (c.fromPlayer && c.depth == 0 && c.passDist < 24f && c.playerIsFree) 0.55f * (0.5f + m.quality * 0.7f) else 0f
        val wOther = if (c.hasOthers) 0.28f else 0f
        val wLose = c.pressure * (1.1f - m.quality) * 0.7f
        val total = wShoot + wCross + wReturn + wOther + wLose
        var r = rng.nextFloat() * total
        if (r < wShoot) return Decision.SHOOT; r -= wShoot
        if (r < wCross) return Decision.CROSS; r -= wCross
        if (r < wReturn) return Decision.RETURN; r -= wReturn
        if (r < wOther) return Decision.PASS_OTHER
        return Decision.LOSE
    }
}
