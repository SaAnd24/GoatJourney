package com.goatjourney.core.match

import kotlin.math.*

class BallSample(val t: Float, val x: Float, val y: Float, val z: Float)

class GoalCross(val y: Float, val z: Float, val t: Float, val speed: Float)

class Launch(val vx: Float, val vy: Float, val vz: Float, val curve: Float)

/** Trayectoria muestreada del balón (x,y en metros de mundo, z = altura). */
class Trajectory(
    val samples: List<BallSample>,
    val goalCross: GoalCross?,
    val outOfPlay: Boolean,
    val bounces: Int
) {
    val duration: Float get() = samples[samples.size - 1].t
    val endPos: Vec get() { val s = samples[samples.size - 1]; return Vec(s.x, s.y) }

    fun at(t: Float): BallSample {
        if (t <= 0f) return samples[0]
        val last = samples[samples.size - 1]
        if (t >= last.t) return last
        var i = 1
        while (i < samples.size && samples[i].t < t) i++
        val a = samples[i - 1]; val b = samples[i]
        val u = (t - a.t) / max(1e-4f, b.t - a.t)
        return BallSample(t, mix(a.x, b.x, u), mix(a.y, b.y, u), mix(a.z, b.z, u))
    }

    fun slice(tEnd: Float): List<BallSample> {
        val out = ArrayList<BallSample>()
        for (s in samples) { if (s.t < tEnd) out.add(s) else break }
        val e = at(tEnd); out.add(BallSample(tEnd, e.x, e.y, e.z))
        return out
    }

    /** Sub-tramo [t0,t1] con el tiempo reiniciado a 0 (para un momento que arranca con el balón en vuelo). */
    fun sub(t0: Float, t1: Float): Trajectory {
        val out = ArrayList<BallSample>()
        val a = at(t0); out.add(BallSample(0f, a.x, a.y, a.z))
        for (s in samples) if (s.t > t0 + 1e-3f && s.t < t1 - 1e-3f) out.add(BallSample(s.t - t0, s.x, s.y, s.z))
        val b = at(t1); out.add(BallSample(t1 - t0, b.x, b.y, b.z))
        return Trajectory(out, null, false, 0)
    }

    fun velAt(t: Float): Vec {
        val a = at(t); val b = at(t + 0.05f)
        return Vec((b.x - a.x) / 0.05f, (b.y - a.y) / 0.05f)
    }

    fun speedAt(t: Float): Float = velAt(t).len()

    companion object {
        /** Trayectoria guiada (pases entrantes, centros): línea recta con arco opcional. */
        fun arc(a: Vec, b: Vec, z0: Float, z1: Float, peak: Float, dur: Float, easeOut: Boolean): Trajectory {
            val n = max(4, (dur / BallPhysics.DT).roundToInt())
            val s = ArrayList<BallSample>()
            for (i in 0..n) {
                val u = i.toFloat() / n
                val e = if (easeOut) 1f - (1f - u) * (1f - u) else u
                val z = mix(z0, z1, u) + 4f * peak * u * (1f - u)
                s.add(BallSample(u * dur, mix(a.x, b.x, e), mix(a.y, b.y, e), max(0f, z)))
            }
            return Trajectory(s, null, false, 0)
        }
    }
}

/**
 * Física simple pero consistente: gravedad, rozamiento aéreo, rodadura, bote, curva lateral.
 * curve > 0 = el balón gira hacia la derecha de su trayectoria (en pantalla vertical, sentido horario).
 */
object BallPhysics {
    const val G = 9.8f
    const val AIR_DRAG = 0.10f
    const val ROLL_K = 0.55f
    const val BOUNCE = 0.55f
    const val DT = 1f / 30f

    fun launch(dir: Vec, speed: Float, elevation: Float, curve: Float): Launch {
        val d = dir.norm()
        val hs = speed * cos(elevation)
        return Launch(d.x * hs, d.y * hs, speed * sin(elevation), curve)
    }

    fun simulate(from: Vec, z0: Float, l: Launch, maxT: Float = 4f): Trajectory {
        var x = from.x; var y = from.y; var z = z0
        var vx = l.vx; var vy = l.vy; var vz = l.vz
        var curve = l.curve
        var t = 0f
        var bounces = 0
        var goal: GoalCross? = null
        var out = false
        val s = ArrayList<BallSample>()
        s.add(BallSample(0f, x, y, z))
        val roll = exp(-ROLL_K * DT)
        while (t < maxT) {
            t += DT
            val hs0 = hypot(vx, vy)
            val airborne = z > 0.03f || vz > 0.5f
            if (hs0 > 0.5f && curve != 0f) {
                val k = if (airborne) 1f else 0.25f
                val ax = -vy / hs0 * curve * k
                val ay = vx / hs0 * curve * k
                vx += ax * DT; vy += ay * DT
                curve *= (1f - 0.4f * DT)
            }
            if (airborne) {
                vz -= G * DT
                val f = 1f - AIR_DRAG * DT
                vx *= f; vy *= f
                z += vz * DT
                if (z <= 0f) {
                    z = 0f
                    if (abs(vz) > 1.5f) { vz = -vz * BOUNCE; vx *= 0.85f; vy *= 0.85f; bounces++ } else vz = 0f
                }
            } else {
                vx *= roll; vy *= roll; z = 0f; vz = 0f
            }
            val px = x; val py = y
            x += vx * DT; y += vy * DT
            if (x >= Pitch.LENGTH && px < Pitch.LENGTH) {
                val f = (Pitch.LENGTH - px) / max(1e-4f, x - px)
                val gy = py + (y - py) * f
                goal = GoalCross(gy, z, t, hypot(vx, vy))
                s.add(BallSample(t, Pitch.LENGTH, gy, z))
                break
            }
            if (x < 0f || x > Pitch.LENGTH || y < 0f || y > Pitch.WIDTH) {
                out = true
                s.add(BallSample(t, x.coerceIn(0f, Pitch.LENGTH), y.coerceIn(0f, Pitch.WIDTH), z))
                break
            }
            s.add(BallSample(t, x, y, z))
            if (!(z > 0.03f || vz > 0.5f) && hypot(vx, vy) < 0.6f) break
        }
        return Trajectory(s, goal, out, bounces)
    }
}
