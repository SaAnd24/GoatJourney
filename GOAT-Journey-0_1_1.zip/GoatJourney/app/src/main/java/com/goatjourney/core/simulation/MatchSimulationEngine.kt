package com.goatjourney.core.simulation

import com.goatjourney.core.career.Club
import com.goatjourney.core.career.Fixture
import com.goatjourney.core.match.*
import com.goatjourney.core.player.Player
import com.goatjourney.core.player.PlayerStats
import com.goatjourney.core.player.Position
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.random.Random

enum class MatchMode { PLAY, SIMULATE }

class MatchEvent(val minute: Int, val text: String, val important: Boolean = false)

class MatchResult(
    val fixtureId: Int, val homeId: Int, val awayId: Int,
    val homeGoals: Int, val awayGoals: Int,
    val stats: PlayerStats, val rating: Float, val playerMinutes: Int, val playerHome: Boolean,
    val events: List<MatchEvent>, val homeShots: Int, val awayShots: Int, val possessionHome: Int
)

object RatingLabel {
    fun of(r: Float): String = when {
        r >= 9f -> "MAGISTRAL"
        r >= 8f -> "EXCELENTE"
        r >= 7f -> "BUENA"
        r >= 6f -> "CORRECTA"
        r >= 5f -> "FLOJA"
        else -> "MUY MALA"
    }
}

/**
 * Motor único de partido (PLAY y SIMULATE lo comparten).
 * Avanza minuto a minuto de forma abstracta; cuando el protagonista entra en juego se genera un KeyMoment:
 *  - PLAY: el motor se detiene (pending) hasta que el usuario resuelve una MomentSession.
 *  - SIMULATE: AIPlayerController resuelve la misma MomentSession con el mismo ActionResolver.
 * Una jugada puede encadenar varios KeyMoments (ActionResult.next).
 */
class MatchSimulationEngine(
    val fixture: Fixture, val player: Player, val home: Club, val away: Club, val mode: MatchMode,
    seed: Long = System.nanoTime()
) {
    private val rng = Random(seed)

    val playerIsHome: Boolean = fixture.homeId == player.clubId
    val myClub: Club = if (playerIsHome) home else away
    val oppClub: Club = if (playerIsHome) away else home
    val importance: MatchImportance = fixture.importance

    private val homeStr = home.strength + 3f
    private val awayStr = away.strength.toFloat()
    private val myStr = if (playerIsHome) homeStr else awayStr
    private val oppStr = if (playerIsHome) awayStr else homeStr

    private val gen = KeyMomentGenerator(rng, player.attributes, player.position, myStr, oppStr)
    private val resolver = ActionResolver(rng, gen)

    var minute: Int = 0; private set
    var homeGoals: Int = 0; private set
    var awayGoals: Int = 0; private set
    var homeShots: Int = 0; private set
    var awayShots: Int = 0; private set
    private var homePoss = 0
    val events = ArrayList<MatchEvent>()
    var pending: KeyMoment? = null; private set
    var session: MomentSession? = null; private set
    var lastResult: ActionResult? = null; private set
    private var queued: KeyMoment? = null
    var finished: Boolean = false; private set
    /** -1 (rival domina) .. +1 (tu equipo ataca): lo usa el renderizador para mover el balón. */
    var momentum: Float = 0f; private set
    val stats = PlayerStats(matches = 1)

    val startMinute: Int = if (rng.nextFloat() < 0.8f) 0 else rng.nextInt(46, 66)
    val endMinute: Int = if (rng.nextFloat() < 0.75f) 90 else rng.nextInt(66, 86)
    private var perf = 6.0f
    private var acc = 0f
    private val minuteSeconds = 0.45f

    val clockSeconds: Float get() = minute * 60f + (acc / minuteSeconds).coerceIn(0f, 0.99f) * 60f

    init {
        events.add(MatchEvent(0, "Comienza el partido", true))
        if (startMinute > 0) events.add(MatchEvent(0, "Empiezas el partido en el banquillo"))
    }

    fun update(dt: Float) {
        if (finished || pending != null || session != null) return
        acc += dt
        while (acc >= minuteSeconds && pending == null && !finished) { acc -= minuteSeconds; stepMinute() }
    }

    /** Resuelve todo el partido automáticamente (SIMULAR). */
    fun playAll() { while (!finished) { stepMinute() } }

    private fun stepMinute() {
        minute++
        abstractPlay()
        if (minute == startMinute && startMinute > 0) events.add(MatchEvent(minute, "Entras al campo", true))
        if (minute == 45) events.add(MatchEvent(45, "Final del primer tiempo"))
        if (minute == endMinute && endMinute < 90) events.add(MatchEvent(minute, "Eres sustituido", true))
        if (minute > startMinute && minute <= endMinute) {
            var chance = gen.involvementChance(player.position)
            if (importance == MatchImportance.IMPORTANT) chance *= 1.25f
            if (rng.nextFloat() < chance) raise()
        }
        if (minute >= 90 && pending == null) finish()
    }

    private fun raise() {
        val ratio = myStr / oppStr
        val attacking = rng.nextFloat() < (gen.attackShare(player.position) * ratio.pow(0.3f)).coerceIn(0.1f, 0.95f)
        val sc = gen.pick(player.position, attacking)
        val pressure = (0.2f + (oppStr - myStr) / 100f + rng.nextFloat() * 0.25f).coerceIn(0.1f, 0.9f)
        val m = gen.build(sc, minute, pressure)
        if (mode == MatchMode.PLAY) { events.add(MatchEvent(minute, flavour(m))); pending = m }
        else autoResolve(m)
    }

    fun flavour(m: KeyMoment): String {
        val n = player.name
        return when (m.type) {
            KeyMomentType.PASS_MOMENT -> "$n recibe el balón"
            KeyMomentType.SHOT_MOMENT -> "$n tiene una ocasión"
            KeyMomentType.CROSS_MOMENT -> "$n llega por banda"
            KeyMomentType.HEADER_MOMENT, KeyMomentType.VOLLEY_MOMENT, KeyMomentType.CHILENA_MOMENT -> "Centro al área: $n puede llegar"
            KeyMomentType.INTERCEPTION_MOMENT -> "El balón pasa cerca de $n"
            KeyMomentType.CLEARANCE_MOMENT -> "Balón peligroso en el área de $n"
            KeyMomentType.REBOUND_MOMENT -> "¡Rechace! $n está cerca"
            KeyMomentType.ONE_TWO_MOMENT -> "$n recibe la pared"
            KeyMomentType.FIRST_TOUCH_MOMENT -> "Le llega el balón a $n"
            else -> "$n entra en la jugada"
        }
    }

    // ------------------------------------------------------------------ SIMULATE (mismo motor, controla la IA)
    private fun autoResolve(first: KeyMoment) {
        var m: KeyMoment? = first
        var guard = 0
        while (m != null && guard++ < 8) {
            if (m !== first) events.add(MatchEvent(minute, flavour(m)))
            val s = MomentSession(m, player.attributes, resolver)
            val r = AIPlayerController.play(s, player.attributes, rng)
            apply(r)
            m = r.next
        }
    }

    // ------------------------------------------------------------------ PLAY
    fun beginMoment(): MomentSession {
        val m = pending ?: error("No hay KeyMoment pendiente")
        val s = MomentSession(m, player.attributes, resolver)
        session = s
        return s
    }

    /** El jugador terminó de ver la jugada: se aplican estadísticas, marcador y consecuencias. */
    fun finishMoment(r: ActionResult) {
        apply(r)
        lastResult = r
        queued = r.next
        session = null
        pending = null
    }

    fun continueAfterResult() {
        pending = queued; queued = null
        val p = pending
        if (p != null) events.add(MatchEvent(minute, flavour(p)))
        if (p == null && minute >= 90) finish()
    }

    // ------------------------------------------------------------------ consecuencias
    private fun myGoal() { if (playerIsHome) homeGoals++ else awayGoals++ }
    private fun oppGoal() { if (playerIsHome) awayGoals++ else homeGoals++ }
    private fun myShot() { if (playerIsHome) homeShots++ else awayShots++ }
    private fun oppShot() { if (playerIsHome) awayShots++ else homeShots++ }

    private fun rivalAttack(threat: Float) {
        if (threat <= 0f || rng.nextFloat() >= threat) return
        oppShot()
        val gp = (0.16f * (oppStr / myStr)).coerceIn(0.05f, 0.4f)
        if (rng.nextFloat() < gp) {
            oppGoal(); perf -= 0.3f
            events.add(MatchEvent(minute, "${oppClub.name} marca tras la jugada", true))
        } else events.add(MatchEvent(minute, "Contraataque de ${oppClub.name}: se salva el peligro"))
    }

    private fun apply(r: ActionResult) {
        val q = r.quality
        if (r.passAttempt) {
            stats.passesAttempted++
            if (r.passCompleted) { stats.passesCompleted++; perf += 0.05f + 0.07f * q } else perf -= 0.12f
        }
        if (r.crossAttempt) {
            stats.crosses++
            if (r.success || r.passCompleted || r.chanceCreated) perf += 0.08f + 0.07f * q else perf -= 0.1f
        }
        if (r.dribbleAttempt) { stats.dribblesAttempted++; if (r.dribbleWon) { stats.dribblesCompleted++; perf += 0.05f } }
        if (r.protagonistShot) {
            stats.shots++; myShot()
            when (r.shotOutcome) {
                ShotOutcome.GOAL, ShotOutcome.SAVED, ShotOutcome.PARRIED -> stats.shotsOnTarget++
                else -> {}
            }
            when (r.shotOutcome) {
                ShotOutcome.SAVED, ShotOutcome.PARRIED -> { perf += 0.12f; events.add(MatchEvent(minute, "Tu disparo es detenido")) }
                ShotOutcome.POST -> { perf += 0.08f; events.add(MatchEvent(minute, "Tu disparo da en el palo")) }
                ShotOutcome.BLOCKED -> perf -= 0.02f
                ShotOutcome.OFF_TARGET -> { perf -= 0.06f; events.add(MatchEvent(minute, "Tu disparo se va fuera")) }
                else -> {}
            }
        }
        if (r.teamShot) myShot()
        if (r.teamGoal) {
            myGoal()
            if (r.goalByPlayer) { stats.goals++; perf += 0.9f; events.add(MatchEvent(minute, "¡GOL tuyo para ${myClub.name}!", true)) }
            else if (r.assist) { stats.assists++; perf += 0.6f; events.add(MatchEvent(minute, "¡Asistencia tuya! Gol de ${myClub.name}", true)) }
            else { perf += 0.15f; events.add(MatchEvent(minute, "¡Gol de ${myClub.name} tras tu jugada!", true)) }
        } else if (r.teamShot && !r.protagonistShot) {
            events.add(MatchEvent(minute, "Tu compañero remata y no logra marcar"))
        }
        if (r.oneTwo) perf += 0.06f
        if (r.interception) { stats.interceptions++; perf += 0.22f }
        if (r.clearanceDone) { stats.clearances++; if (r.success) perf += 0.18f else perf -= 0.12f }
        if (r.turnover && !r.teamGoal) {
            perf -= 0.08f
            events.add(MatchEvent(minute, "Pierdes la posesión"))
        }
        if (r.intent == IntentKind.INTERCEPT && !r.success) perf -= 0.08f
        momentum = when {
            r.teamGoal || r.chanceCreated -> 0.8f
            r.turnover -> -0.7f
            r.success -> 0.4f
            else -> momentum
        }
        if (momentum < 0f) { /* el rival tiene la iniciativa */ }
        rivalAttack(r.opponentThreat)
    }

    private fun abstractPlay() {
        val r = homeStr / awayStr
        val pH = (0.16f * r.pow(0.6f)).coerceIn(0.06f, 0.3f)
        val pA = (0.16f / r.pow(0.6f)).coerceIn(0.06f, 0.3f)
        if (rng.nextFloat() < homeStr / (homeStr + awayStr)) homePoss++
        var mom = momentum * 0.7f
        if (rng.nextFloat() < pH) { mom = (if (playerIsHome) 1f else -1f) * (0.4f + rng.nextFloat() * 0.5f); abstractAttack(true) }
        if (rng.nextFloat() < pA) { mom = (if (playerIsHome) -1f else 1f) * (0.4f + rng.nextFloat() * 0.5f); abstractAttack(false) }
        momentum = mom
        val f = rng.nextFloat()
        if (f < 0.06f) events.add(MatchEvent(minute, "El rival recupera el balón"))
        else if (f < 0.12f) events.add(MatchEvent(minute, "Tu equipo roba el balón"))
        else if (f < 0.135f) events.add(MatchEvent(minute, "Tarjeta amarilla para ${if (rng.nextBoolean()) home.name else away.name}"))
    }

    private fun abstractAttack(homeAttacks: Boolean) {
        val atk = if (homeAttacks) homeStr else awayStr
        val dfn = if (homeAttacks) awayStr else homeStr
        if (rng.nextFloat() < 0.55f) {
            if (homeAttacks) homeShots++ else awayShots++
            val gp = (0.14f * (atk / dfn).pow(1.2f)).coerceIn(0.03f, 0.4f)
            if (rng.nextFloat() < gp) {
                if (homeAttacks) homeGoals++ else awayGoals++
                events.add(MatchEvent(minute, "¡GOL de ${if (homeAttacks) home.name else away.name}!", true))
            }
        }
    }

    private fun finish() {
        if (finished) return
        finished = true
        minute = 90
        stats.minutes = (endMinute - startMinute).coerceAtLeast(0)
        stats.starts = if (startMinute == 0) 1 else 0
        if (rng.nextFloat() < 0.05f) { perf -= 0.2f; events.add(MatchEvent(90, "Recibes tarjeta amarilla")) }
        events.add(MatchEvent(90, "Final del partido", true))
    }

    private fun ratingNow(withResult: Boolean): Float {
        val my = if (playerIsHome) homeGoals else awayGoals
        val opp = if (playerIsHome) awayGoals else homeGoals
        var r = perf
        if (withResult) {
            r += when { my > opp -> 0.3f; my < opp -> -0.3f; else -> 0f }
            if (player.position == Position.CENTER_BACK || player.position == Position.FULL_BACK) r -= 0.1f * opp.coerceAtMost(3)
        }
        if (stats.minutes in 1..19) r = 6f + (r - 6f) * 0.5f
        return ((r.coerceIn(3f, 10f)) * 10f).roundToInt() / 10f
    }

    /** Rating en vivo para el HUD. */
    fun currentRating(): Float = ratingNow(false)

    fun buildResult(): MatchResult {
        val rating = ratingNow(true)
        stats.matchRatings.add(rating)
        return MatchResult(
            fixture.id, home.id, away.id, homeGoals, awayGoals, stats, rating, stats.minutes, playerIsHome,
            events, homeShots, awayShots, if (minute == 0) 50 else (homePoss * 100f / minute).roundToInt()
        )
    }
}
