# GOAT Journey 0.1 — The First Match

RPG de carrera futbolística para Android. Partido simulado + oportunidades interactivas con gestos.
Toda la UI se dibuja con Canvas (sin Material, XML ni Compose).

## Compilar
- Requisitos: JDK 17, Android SDK 34, Gradle 8.7.
- Local: `gradle assembleDebug` (o abre en Android Studio). Si quieres wrapper: `gradle wrapper --gradle-version 8.7`.
- GitHub Actions: `.github/workflows/android.yml` compila y sube el APK debug.
- La app es horizontal (sensorLandscape), minSdk 26.

## Arquitectura
```
core/player       Position, Attributes, Player, OvrCalculator, PlayerFactory, PlayerStats
core/career       CareerState (serializable), Club, Fixture, calendario, tabla, CareerManager
core/match        Opportunity, OpportunitySystem, ActionResolver, AutoPlayer, Gesture
core/simulation   MatchSimulationEngine, MatchResult
core/progression  ProgressionSystem (punto de extensión, vacío en 0.1)
rendering         Viewport, UI (componentes), BaseScreen, pantallas, MatchScreen/Camera, GameView
input             TouchInput, GestureProcessor
data              Room (CareerSaveEntity), SaveSystem, SettingsStore (DataStore)
game              GameController (estados, transiciones, flujo de partido), Feedback
app               MainActivity
```
`core` no importa nada de Android ni de `rendering`. El render solo dibuja estado.

## Game loop
`GameView` lanza un hilo: `GameController.update(dt)` (input → transición → `screen.update`) y luego
`render(canvas)`. Los toques se encolan en `TouchInput` y se procesan en el hilo del juego.
Escala: referencia 1280x720, `Viewport` calcula `scale/offsetX/offsetY`; los toques se convierten a coordenadas de referencia.
Estados: TITLE, CREATION, CAREER, PLAYER, CALENDAR, MATCH_PREVIEW, MATCH_SIMULATION, MATCH_OPPORTUNITY, MATCH_RESULT, TABLE, SETTINGS.

## MatchSimulationEngine
Avanza minuto a minuto (≈0,25 s reales por minuto, x3 al tocar). Cada minuto simula ataques/goles abstractos de ambos equipos
(según fuerza + ventaja local) y decide si el jugador participa (probabilidad por posición; x1,25 en partido IMPORTANTE).
- PLAY: genera `Opportunity` y se detiene (`pending`) hasta `submit(gesture)` y `continueAfterResult()`.
- SIMULATE: `AutoPlayer` genera un gesto razonable y pasa por el MISMO `ActionResolver`. Un solo motor.
Registra estadísticas, eventos, sustitución, tarjetas y rating (6.0 base ± acciones ± resultado).

## Oportunidades
`OpportunityType` (PASS, SHOT, DRIBBLE, CROSS, INTERCEPTION, CLEARANCE). `OpportunitySystem` elige tipo con tablas de pesos
por posición y fase (ataque/defensa); nunca hay peso 0, así que cualquier posición puede hacer cualquier cosa.
`ActionResolver` combina atributos, presión, calidad de la ocasión y la ejecución del gesto (dirección y potencia).
Un pase con ocasión o un centro lanzan un remate del compañero; un regate exitoso cerca del área puede encadenar un tiro.

## GestureProcessor
Convierte DOWN/MOVE/UP en Tap, DragStart/Drag, Release y LongPress. En el partido el gesto empieza cerca del balón
(o del jugador en intercepciones); el vector en pantalla se divide por el zoom de cámara para obtener metros de mundo.
Potencia = longitud / `maxLen` del tipo.

## Guardado
`CareerState` → JSON (kotlinx.serialization) → `CareerSaveEntity(id, saveVersion, timestamp, careerStateJson)` en Room.
Autoguardado tras cada partido, al pausar y con GUARDAR. `SaveSystem.migrate` es el hook para migraciones futuras.
DataStore guarda solo música/efectos/vibración.

## Cómo ampliar
- **Nueva oportunidad**: añade un valor a `OpportunityType` (maxLen, range, hint), un `build…` en `OpportunitySystem`,
  una rama en `ActionResolver.resolve`, en `AutoPlayer.gesture` y en `MatchSimulationEngine.apply`; dibuja extras en `MatchScreen`.
- **Nueva pantalla Canvas**: crea una clase que extienda `BaseScreen` (botones con `btn()`, dibuja en `draw`),
  añade un valor a `GameState` y regístrala en `GameController.screens`.
- **Nueva posición**: añade el valor en `Position`, su fila de pesos en `OvrCalculator`, sus pesos en `OpportunitySystem`
  (involvement/attackShare/attackW/defendW) y su casilla en `MatchScreen.drawSim`.
- **Más atributos**: añade el campo en `Attributes` (+ `toArray/fromArray/NAMES`) y una columna de pesos en `OvrCalculator`.

## Futuro (NO implementado en 0.1)
Transferencias, contratos, salarios, agentes, skill tree/XP, personalidad, prensa, redes, relaciones, familia, hijos, fama,
patrocinadores, casas/autos, negocios, enfermedades/lesiones, selecciones, Mundial, premios, retiro, generaciones, GOAT Score,
audio/música real, portero como posición (excluido de 0.1).
