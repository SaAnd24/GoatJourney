package com.goatjourney.core.simulation

import com.goatjourney.core.career.Club
import com.goatjourney.core.career.Fixture
import com.goatjourney.core.match.*
import com.goatjourney.core.player.Player
import com.goatjourney.core.player.PlayerStats
import com.goatjourney.core.player.Position
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.random.Random

enum class MatchMode { PLAY, SIMULATE }

class MatchEvent(val minute: Int, val text: String, val important: Boolean = false)

class MatchResult(
    val fixtureId: Int, val homeId: Int, val awayId: Int,
    val homeGoals: Int, val awayGoals: Int,
    val stats: PlayerStats, val rating: Float, val playerMinutes: Int, val playerHome: Boolean,
    val events: List<MatchEvent>, val homeShots: Int, val awayShots: Int, val possessionHome: Int
)

object RatingLabel {
    fun of(r: Float): String = when {
        r >= 9f -> "MAGISTRAL"
        r >= 8f -> "EXCELENTE"
        r >= 7f -> "BUENA"
        r >= 6f -> "CORRECTA"
        r >= 5f -> "FLOJA"
        else -> "MUY MALA"
    }
}

/**
 * Motor único de partido (JUGAR y SIMULAR lo comparten).
 * Avanza minuto a minuto de forma abstracta; cuando el jugador participa se genera una Opportunity:
 *  - PLAY: el motor se detiene (pending) hasta recibir un gesto con [submit] y luego [continueAfterResult].
 *  - SIMULATE: la oportunidad se resuelve al instante con [AutoPlayer] y el mismo [ActionResolver].
 */
class MatchSimulationEngine(
    val fixture: Fixture, val player: Player, val home: Club, val away: Club, val mode: MatchMode,
    seed: Long = System.nanoTime()
) {
    private val rng = Random(seed)
    private val system = OpportunitySystem(rng)
    private val resolver = ActionResolver(rng)

    val playerIsHome: Boolean = fixture.homeId == player.clubId
    val myClub: Club = if (playerIsHome) home else away
    val oppClub: Club = if (playerIsHome) away else home
    val importance: MatchImportance = fixture.importance

    private val homeStr = home.strength + 3f
    private val awayStr = away.strength.toFloat()
    private val myStr = if (playerIsHome) homeStr else awayStr
    private val oppStr = if (playerIsHome) awayStr else homeStr

    var minute: Int = 0; private set
    var homeGoals: Int = 0; private set
    var awayGoals: Int = 0; private set
    var homeShots: Int = 0; private set
    var awayShots: Int = 0; private set
    private var homePoss = 0
    val events = ArrayList<MatchEvent>()
    var pending: Opportunity? = null; private set
    var lastResult: ActionResult? = null; private set
    private var queued: Opportunity? = null
    var finished: Boolean = false; private set
    /** -1 (rival domina) .. +1 (tu equipo ataca): lo usa el renderizador para mover el balón. */
    var momentum: Float = 0f; private set
    val stats = PlayerStats(matches = 1)

    val startMinute: Int = if (rng.nextFloat() < 0.8f) 0 else rng.nextInt(46, 66)
    val endMinute: Int = if (rng.nextFloat() < 0.75f) 90 else rng.nextInt(66, 86)
    private var perf = 6.0f
    private var acc = 0f
    private val minuteSeconds = 0.25f

    val clockSeconds: Float get() = minute * 60f + (acc / minuteSeconds).coerceIn(0f, 0.99f) * 60f

    init {
        events.add(MatchEvent(0, "Comienza el partido", true))
        if (startMinute > 0) events.add(MatchEvent(0, "Empiezas el partido en el banquillo"))
    }

    fun update(dt: Float) {
        if (finished || pending != null) return
        acc += dt
        while (acc >= minuteSeconds && pending == null && !finished) { acc -= minuteSeconds; stepMinute() }
    }

    /** Resuelve todo el partido automáticamente (SIMULAR). */
    fun playAll() { while (!finished) { stepMinute(); if (pending != null) { val op = pending!!; pending = null; autoResolve(op) } } }

    private fun stepMinute() {
        minute++
        abstractPlay()
        if (minute == startMinute && startMinute > 0) events.add(MatchEvent(minute, "Entras al campo", true))
        if (minute == 45) events.add(MatchEvent(45, "Final del primer tiempo"))
        if (minute == endMinute && endMinute < 90) events.add(MatchEvent(minute, "Eres sustituido", true))
        if (minute > startMinute && minute <= endMinute) {
            var chance = system.involvementChance(player.position)
            if (importance == MatchImportance.IMPORTANT) chance *= 1.25f
            if (rng.nextFloat() < chance) raise()
        }
        if (minute >= 90 && pending == null) finish()
    }

    private fun raise() {
        val ratio = myStr / oppStr
        val attacking = rng.nextFloat() < (system.attackShare(player.position) * ratio.pow(0.3f)).coerceIn(0.1f, 0.95f)
        val type = system.pickType(player.position, attacking)
        val pressure = (0.2f + (oppStr - myStr) / 100f + rng.nextFloat() * 0.25f).coerceIn(0.1f, 0.9f)
        val op = system.build(type, minute, pressure)
        events.add(MatchEvent(minute, flavour(type)))
        if (mode == MatchMode.PLAY) pending = op else autoResolve(op)
    }

    private fun flavour(t: OpportunityType) = when (t) {
        OpportunityType.PASS -> "Recibes el balón y buscas un pase"
        OpportunityType.SHOT -> "Tienes una ocasión de disparo"
        OpportunityType.DRIBBLE -> "Tienes un defensor delante"
        OpportunityType.CROSS -> "Llegas a la banda con espacio"
        OpportunityType.INTERCEPTION -> "El balón pasa cerca de ti"
        OpportunityType.CLEARANCE -> "Balón peligroso en tu área"
    }

    private fun autoResolve(first: Opportunity) {
        var op: Opportunity? = first
        while (op != null) {
            val g = AutoPlayer.gesture(op, player.attributes, rng)
            val r = resolver.resolve(op, g, player.attributes)
            apply(op, r)
            op = queued; queued = null
        }
    }

    /** PLAY: el gesto del jugador (en metros de mundo) se resuelve con el ActionResolver. */
    fun submit(g: Gesture): ActionResult {
        val op = pending ?: error("No hay oportunidad pendiente")
        val r = resolver.resolve(op, g, player.attributes)
        apply(op, r)
        lastResult = r
        return r
    }

    fun continueAfterResult() {
        lastResult = null
        pending = queued; queued = null
        if (pending == null && minute >= 90) finish()
    }

    private fun myGoal() { if (playerIsHome) homeGoals++ else awayGoals++ }
    private fun oppGoal() { if (playerIsHome) awayGoals++ else homeGoals++ }
    private fun myShot() { if (playerIsHome) homeShots++ else awayShots++ }
    private fun oppShot() { if (playerIsHome) awayShots++ else homeShots++ }

    private fun teammateFinish(r: ActionResult, prob: Float) {
        myShot()
        if (rng.nextFloat() < prob) {
            stats.assists++; r.assist = true; myGoal(); perf += 0.6f
            events.add(MatchEvent(minute, "¡Asistencia tuya! Gol de ${myClub.name}", true))
        } else events.add(MatchEvent(minute, "Tu compañero remata y no logra marcar"))
    }

    private fun opponentFinish(prob: Float) {
        oppShot()
        if (rng.nextFloat() < prob) {
            oppGoal(); perf -= 0.3f
            events.add(MatchEvent(minute, "${oppClub.name} marca tras la jugada", true))
        }
    }

    private fun apply(op: Opportunity, r: ActionResult) {
        val q = r.quality
        when (op.type) {
            OpportunityType.PASS -> {
                stats.passesAttempted++
                if (r.success) { stats.passesCompleted++; perf += 0.05f + 0.07f * q } else perf -= 0.12f
                if (r.chanceCreated) teammateFinish(r, 0.10f + 0.28f * q)
                else if (r.turnover && rng.nextFloat() < 0.12f) opponentFinish(0.15f)
            }
            OpportunityType.SHOT -> {
                stats.shots++; myShot()
                if (r.shotOutcome == ShotOutcome.GOAL || r.shotOutcome == ShotOutcome.SAVED) stats.shotsOnTarget++
                when (r.shotOutcome) {
                    ShotOutcome.GOAL -> { stats.goals++; myGoal(); perf += 0.9f; events.add(MatchEvent(minute, "¡GOL tuyo para ${myClub.name}!", true)) }
                    ShotOutcome.SAVED -> perf += 0.12f
                    ShotOutcome.POST -> perf += 0.08f
                    ShotOutcome.BLOCKED -> perf -= 0.02f
                    else -> perf -= 0.06f
                }
            }
            OpportunityType.DRIBBLE -> {
                stats.dribblesAttempted++
                val pe = r.playerEnd
                if (r.success) {
                    stats.dribblesCompleted++; perf += 0.08f + 0.08f * q
                    if (pe != null && pe.x > 72f && rng.nextFloat() < 0.5f) queued = system.buildShotAt(pe, minute, op.pressure)
                } else if (!r.foul) { perf -= 0.1f; if (rng.nextFloat() < 0.1f) opponentFinish(0.15f) }
            }
            OpportunityType.CROSS -> {
                stats.crosses++
                if (r.success) { perf += 0.08f + 0.07f * q; if (r.chanceCreated) teammateFinish(r, 0.10f + 0.2f * q) } else perf -= 0.1f
            }
            OpportunityType.INTERCEPTION -> {
                if (r.success) { stats.interceptions++; perf += 0.22f } else { perf -= 0.08f; if (r.opponentChance) opponentFinish(0.18f) }
            }
            OpportunityType.CLEARANCE -> {
                stats.clearances++
                if (r.success) perf += 0.18f else { perf -= 0.12f; if (r.opponentChance) opponentFinish(0.22f) }
            }
        }
    }

    private fun abstractPlay() {
        val r = homeStr / awayStr
        val pH = (0.16f * r.pow(0.6f)).coerceIn(0.06f, 0.3f)
        val pA = (0.16f / r.pow(0.6f)).coerceIn(0.06f, 0.3f)
        if (rng.nextFloat() < homeStr / (homeStr + awayStr)) homePoss++
        var mom = momentum * 0.7f
        if (rng.nextFloat() < pH) { mom = (if (playerIsHome) 1f else -1f) * (0.4f + rng.nextFloat() * 0.5f); abstractAttack(true) }
        if (rng.nextFloat() < pA) { mom = (if (playerIsHome) -1f else 1f) * (0.4f + rng.nextFloat() * 0.5f); abstractAttack(false) }
        momentum = mom
        val f = rng.nextFloat()
        if (f < 0.06f) events.add(MatchEvent(minute, "El rival recupera el balón"))
        else if (f < 0.12f) events.add(MatchEvent(minute, "Tu equipo roba el balón"))
        else if (f < 0.135f) events.add(MatchEvent(minute, "Tarjeta amarilla para ${if (rng.nextBoolean()) home.name else away.name}"))
    }

    private fun abstractAttack(homeAttacks: Boolean) {
        val atk = if (homeAttacks) homeStr else awayStr
        val dfn = if (homeAttacks) awayStr else homeStr
        if (rng.nextFloat() < 0.55f) {
            if (homeAttacks) homeShots++ else awayShots++
            val gp = (0.14f * (atk / dfn).pow(1.2f)).coerceIn(0.03f, 0.4f)
            if (rng.nextFloat() < gp) {
                if (homeAttacks) homeGoals++ else awayGoals++
                events.add(MatchEvent(minute, "¡GOL de ${if (homeAttacks) home.name else away.name}!", true))
            }
        }
    }

    private fun finish() {
        if (finished) return
        finished = true
        minute = 90
        stats.minutes = (endMinute - startMinute).coerceAtLeast(0)
        stats.starts = if (startMinute == 0) 1 else 0
        if (rng.nextFloat() < 0.05f) { perf -= 0.2f; events.add(MatchEvent(90, "Recibes tarjeta amarilla")) }
        events.add(MatchEvent(90, "Final del partido", true))
    }

    private fun ratingNow(withResult: Boolean): Float {
        val my = if (playerIsHome) homeGoals else awayGoals
        val opp = if (playerIsHome) awayGoals else homeGoals
        var r = perf
        if (withResult) {
            r += when { my > opp -> 0.3f; my < opp -> -0.3f; else -> 0f }
            if (player.position == Position.CENTER_BACK || player.position == Position.FULL_BACK) r -= 0.1f * opp.coerceAtMost(3)
        }
        if (stats.minutes in 1..19) r = 6f + (r - 6f) * 0.5f
        return ((r.coerceIn(3f, 10f)) * 10f).roundToInt() / 10f
    }

    /** Rating en vivo para el HUD. */
    fun currentRating(): Float = ratingNow(false)

    fun buildResult(): MatchResult {
        val rating = ratingNow(true)
        stats.matchRatings.add(rating)
        return MatchResult(
            fixture.id, home.id, away.id, homeGoals, awayGoals, stats, rating, stats.minutes, playerIsHome,
            events, homeShots, awayShots, if (minute == 0) 50 else (homePoss * 100f / minute).roundToInt()
        )
    }
}
