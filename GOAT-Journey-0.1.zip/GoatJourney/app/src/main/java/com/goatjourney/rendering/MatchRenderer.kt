package com.goatjourney.rendering

import android.graphics.Canvas
import android.graphics.Paint
import com.goatjourney.core.match.*
import com.goatjourney.core.simulation.MatchSimulationEngine
import com.goatjourney.game.GameController
import com.goatjourney.game.GameState
import kotlin.math.*

/** Cámara dinámica: vista general en simulación, zoom a la zona de acción en las oportunidades. */
class Camera {
    var cx = 52.5f; var cy = 34f; var zoom = 10.2f
    var tx = 52.5f; var ty = 34f; var tz = 10.2f
    var shake = 0f
    private var t = 0f
    private var ox = 0f; private var oy = 0f

    fun overview() { tx = 52.5f; ty = 34f; tz = 10.2f }
    fun snapOverview() { overview(); cx = tx; cy = ty; zoom = tz }

    fun update(dt: Float) {
        val f = min(1f, dt * 5f)
        cx += (tx - cx) * f; cy += (ty - cy) * f; zoom += (tz - zoom) * f
        shake = max(0f, shake - dt * 2.2f); t += dt
        ox = sin(t * 61f) * shake * 9f; oy = cos(t * 53f) * shake * 9f
    }

    fun sx(wx: Float) = (wx - cx) * zoom + 640f + ox
    fun sy(wy: Float) = (wy - cy) * zoom + 372f + oy
}

/**
 * Pantalla de partido (MATCH_SIMULATION / MATCH_OPPORTUNITY).
 * Fases: SIM -> INTRO -> WAIT (gesto) -> FLIGHT (balón en movimiento) -> RESULT -> SIM ... -> FULLTIME.
 * Toda la lógica de fútbol vive en MatchSimulationEngine; aquí solo se anima y se dibuja.
 */
class MatchScreen(g: GameController) : BaseScreen(g) {
    private enum class Phase { SIM, INTRO, WAIT, FLIGHT, RESULT, FULLTIME }

    override val background: Int get() = Palette.GRASS_DARK

    private var eng: MatchSimulationEngine? = null
    private var phase = Phase.SIM
    private val cam = Camera()
    private val particles = Particles()

    private var myShirt = 0; private var myShorts = 0; private var oppShirt = 0; private var oppShorts = 0
    private var speed = 1f
    private var pt = 0f          // tiempo dentro de la fase
    private var spin = 0f
    private var finishCalled = false

    // balón/jugadores en simulación
    private var bwx = 52.5f; private var bwy = 34f
    private val FX = floatArrayOf(0.04f, 0.22f, 0.20f, 0.20f, 0.22f, 0.42f, 0.45f, 0.42f, 0.68f, 0.72f, 0.68f)
    private val FY = floatArrayOf(0.5f, 0.88f, 0.62f, 0.38f, 0.12f, 0.3f, 0.5f, 0.7f, 0.85f, 0.5f, 0.15f)

    // escena de oportunidad
    private var op: Opportunity? = null
    private var res: ActionResult? = null
    private var pX = 0f; private var pY = 0f
    private var ballX = 0f; private var ballY = 0f
    private var kX = 103.6f; private var kY = 34f
    private var fx0 = 0f; private var fy0 = 0f; private var fx1 = 0f; private var fy1 = 0f
    private var pX0 = 0f; private var pY0 = 0f; private var pX1 = 0f; private var pY1 = 0f
    private var kY0 = 34f; private var kY1 = 34f
    private var flightDur = 1f
    private var dragging = false
    private var dragX = 0f; private var dragY = 0f
    private var bannerHead = ""; private var bannerDetail = ""; private var bannerColor = Palette.ACCENT
    private var celebrate = false

    // caches de texto
    private var clockSec = -1; private var clockStr = "00:00"
    private var scoreKey = -1; private var scoreStr = ""
    private var evCount = -1; private var evStr = ""
    private var ratingStr = "6.0"

    fun begin(e: MatchSimulationEngine) {
        eng = e
        myShirt = e.myClub.primary; myShorts = e.myClub.secondary
        val o = e.oppClub
        val dr = ((myShirt shr 16 and 255) - (o.primary shr 16 and 255)).let { abs(it) } +
            abs((myShirt shr 8 and 255) - (o.primary shr 8 and 255)) + abs((myShirt and 255) - (o.primary and 255))
        oppShirt = if (dr < 110) o.secondary else o.primary
        oppShorts = darken(oppShirt, 0.6f)
        phase = Phase.SIM; speed = 1f; pt = 0f; finishCalled = false
        cam.snapOverview(); bwx = 52.5f; bwy = 34f
        op = null; res = null; dragging = false; celebrate = false
        clockSec = -1; scoreKey = -1; evCount = -1
        game.setMatchState(GameState.MATCH_SIMULATION)
        game.feedback.whistle()
    }

    override fun onBack(): Boolean = true // no se abandona un partido a medias

    // ------------------------------------------------------------------ update
    override fun update(dt: Float) {
        super.update(dt)
        val e = eng ?: return
        cam.update(dt); particles.update(dt); spin += dt * 9f; pt += dt
        when (phase) {
            Phase.SIM -> {
                e.update(dt * speed)
                val tx = 52.5f + e.momentum * 38f + sin(time * 0.9f) * 6f
                val ty = 34f + sin(time * 1.3f) * 14f
                val f = min(1f, dt * 2.5f)
                bwx += (tx - bwx) * f; bwy += (ty - bwy) * f
                if (e.pending != null) startIntro(e.pending!!)
                else if (e.finished) { phase = Phase.FULLTIME; pt = 0f; game.feedback.whistle() }
            }
            Phase.INTRO -> if (pt >= 0.65f) { phase = Phase.WAIT; pt = 0f }
            Phase.WAIT -> {}
            Phase.FLIGHT -> updateFlight(dt)
            Phase.RESULT -> if (pt >= (if (celebrate) 1.8f else 1.15f)) endResult(e)
            Phase.FULLTIME -> if (pt >= 2.0f && !finishCalled) { finishCalled = true; game.finishMatch(e) }
        }
    }

    private fun startIntro(o: Opportunity) {
        op = o; res = null; phase = Phase.INTRO; pt = 0f; dragging = false; celebrate = false
        pX = o.player.x; pY = o.player.y; ballX = o.ball.x; ballY = o.ball.y
        o.keeper?.let { kX = it.x; kY = it.y }
        game.setMatchState(GameState.MATCH_OPPORTUNITY)
        var x0 = o.ball.x; var x1 = x0; var y0 = o.ball.y; var y1 = y0
        fun add(p: Vec) { x0 = min(x0, p.x); x1 = max(x1, p.x); y0 = min(y0, p.y); y1 = max(y1, p.y) }
        add(o.player)
        for (t in o.teammates) add(t.pos)
        for (d in o.defenders) add(d)
        o.keeper?.let { add(it) }
        o.incomingFrom?.let { add(it) }; o.incomingTo?.let { add(it) }
        if (o.type == OpportunityType.SHOT || o.type == OpportunityType.CROSS) add(Vec(105f, 34f))
        if (o.type == OpportunityType.CLEARANCE) add(Vec(0f, 34f))
        val w = x1 - x0 + 14f; val h = y1 - y0 + 16f
        cam.tx = (x0 + x1) / 2f; cam.ty = (y0 + y1) / 2f
        cam.tz = min(1150f / w, 540f / h).coerceIn(11f, 24f)
    }

    private fun startFlight(o: Opportunity, r: ActionResult) {
        res = r
        val a = r.path[0]; val b = r.path[r.path.size - 1]
        fx0 = a.x; fy0 = a.y; fx1 = b.x; fy1 = b.y
        flightDur = r.flightSeconds.coerceAtLeast(0.3f); pt = 0f; phase = Phase.FLIGHT
        pX0 = o.player.x; pY0 = o.player.y
        val pe = r.playerEnd
        pX1 = pe?.x ?: o.player.x; pY1 = pe?.y ?: o.player.y
        kY0 = kY; kY1 = if (o.type == OpportunityType.SHOT) fy1.coerceIn(30.3f, 37.7f) else kY
    }

    private fun updateFlight(dt: Float) {
        val o = op ?: return; val r = res ?: return
        val p = (pt / flightDur).coerceIn(0f, 1f)
        val e = if (o.type == OpportunityType.SHOT) p else Ease.outQuad(p)
        ballX = fx0 + (fx1 - fx0) * e; ballY = fy0 + (fy1 - fy0) * e
        val pe = Ease.outQuad(p)
        pX = pX0 + (pX1 - pX0) * pe; pY = pY0 + (pY1 - pY0) * pe
        kY = kY0 + (kY1 - kY0) * pe
        if (p >= 1f) {
            phase = Phase.RESULT; pt = 0f
            celebrate = r.goal || r.assist
            bannerHead = if (r.assist) "¡ASISTENCIA!" else r.headline
            bannerDetail = if (r.assist) "Tu compañero marca" else if (r.chanceCreated && !r.goal) "Pero el remate no entra" else r.detail
            bannerColor = if (celebrate) Palette.GOLD else if (r.success) Palette.ACCENT else Palette.RED
            if (celebrate) { particles.burst(640f, 300f); cam.shake = 1f; game.feedback.goal() }
            else if (!r.success) game.feedback.vibrate(25)
        }
    }

    private fun endResult(e: MatchSimulationEngine) {
        e.continueAfterResult()
        res = null
        val pend = e.pending
        if (pend != null) startIntro(pend)
        else if (e.finished) { phase = Phase.FULLTIME; pt = 0f; game.feedback.whistle() }
        else { phase = Phase.SIM; pt = 0f; op = null; cam.overview(); game.setMatchState(GameState.MATCH_SIMULATION) }
    }

    // ------------------------------------------------------------------ input
    private fun anchorX(o: Opportunity) = cam.sx(if (o.type == OpportunityType.INTERCEPTION) o.player.x else o.ball.x)
    private fun anchorY(o: Opportunity) = cam.sy(if (o.type == OpportunityType.INTERCEPTION) o.player.y else o.ball.y)

    override fun onTap(x: Float, y: Float) { if (phase == Phase.SIM) speed = if (speed > 1f) 1f else 3f }

    override fun onDown(x: Float, y: Float) {
        val o = op ?: return
        if (phase == Phase.WAIT && hypot(x - anchorX(o), y - anchorY(o)) < 140f) { dragging = true; dragX = 0f; dragY = 0f }
    }

    override fun onDrag(x: Float, y: Float, startX: Float, startY: Float) {
        if (dragging) { dragX = x - startX; dragY = y - startY }
    }

    override fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) {
        val e = eng ?: return; val o = op ?: return
        if (!dragging) return
        dragging = false
        if (phase != Phase.WAIT || hypot(dragX, dragY) < 26f) return
        // pantalla -> mundo
        val r = e.submit(Gesture(dragX / cam.zoom, dragY / cam.zoom))
        startFlight(o, r)
    }

    // ------------------------------------------------------------------ render
    override fun render(c: Canvas) { draw(c) }

    override fun draw(c: Canvas) {
        val e = eng ?: return
        drawPitch(c)
        val o = op
        if (o != null && phase != Phase.SIM && phase != Phase.FULLTIME) drawScene(c, o, e)
        else drawSim(c, e)
        drawHud(c, e)
        if (o != null && phase != Phase.SIM && phase != Phase.FULLTIME) drawOverlay(c, o)
        particles.draw(c, ui)
        if (phase == Phase.FULLTIME) {
            ui.fillRect(c, 0f, 250f, 1280f, 200f, withAlpha(0xFF000000.toInt(), 170))
            ui.text(c, "FINAL DEL PARTIDO", 640f, 340f, 72f, Palette.GOLD, Paint.Align.CENTER)
            ui.text(c, scoreStr, 640f, 410f, 48f, Palette.WHITE, Paint.Align.CENTER)
        }
    }

    private fun drawPitch(c: Canvas) {
        val l = cam.sx(0f); val r = cam.sx(105f); val t = cam.sy(0f); val b = cam.sy(68f)
        val n = 14; val w = (r - l) / n
        for (i in 0 until n) { ui.fill.color = if (i % 2 == 0) Palette.GRASS1 else Palette.GRASS2; c.drawRect(l + i * w, t, l + (i + 1) * w, b, ui.fill) }
        val z = cam.zoom
        ui.stroke.color = withAlpha(Palette.WHITE, 210); ui.stroke.strokeWidth = max(2f, z * 0.17f)
        c.drawRect(l, t, r, b, ui.stroke)
        val mx = cam.sx(52.5f); c.drawLine(mx, t, mx, b, ui.stroke)
        c.drawCircle(mx, cam.sy(34f), 9.15f * z, ui.stroke)
        ui.fill.color = Palette.WHITE; c.drawCircle(mx, cam.sy(34f), max(2f, z * 0.3f), ui.fill)
        c.drawRect(l, cam.sy(13.84f), cam.sx(16.5f), cam.sy(54.16f), ui.stroke)
        c.drawRect(cam.sx(88.5f), cam.sy(13.84f), r, cam.sy(54.16f), ui.stroke)
        c.drawRect(l, cam.sy(24.84f), cam.sx(5.5f), cam.sy(43.16f), ui.stroke)
        c.drawRect(cam.sx(99.5f), cam.sy(24.84f), r, cam.sy(43.16f), ui.stroke)
        // porterías
        ui.fill.color = withAlpha(Palette.WHITE, 70)
        c.drawRect(cam.sx(-2.4f), cam.sy(30.34f), l, cam.sy(37.66f), ui.fill)
        c.drawRect(r, cam.sy(30.34f), cam.sx(107.4f), cam.sy(37.66f), ui.fill)
        c.drawRect(cam.sx(-2.4f), cam.sy(30.34f), l, cam.sy(37.66f), ui.stroke)
        c.drawRect(r, cam.sy(30.34f), cam.sx(107.4f), cam.sy(37.66f), ui.stroke)
    }

    private fun drawSim(c: Canvas, e: MatchSimulationEngine) {
        val z = cam.zoom
        val shift = (bwx - 52.5f) * 0.35f
        val rad = max(5f, z * 0.85f)
        val idx = when (e.player.position) {
            com.goatjourney.core.player.Position.CENTER_BACK -> 3
            com.goatjourney.core.player.Position.FULL_BACK -> 4
            com.goatjourney.core.player.Position.MIDFIELDER -> 6
            com.goatjourney.core.player.Position.WINGER -> 10
            com.goatjourney.core.player.Position.STRIKER -> 9
        }
        for (i in 0 until 11) {
            val wob = sin(time * 1.7f + i) * 1.1f
            val mxw = FX[i] * 105f + shift * (if (i == 0) 0.2f else 1f)
            val myw = FY[i] * 68f + wob
            ui.circle(c, cam.sx(mxw), cam.sy(myw), rad, myShirt)
            ui.stroke.color = withAlpha(Palette.WHITE, 200); ui.stroke.strokeWidth = 2f
            c.drawCircle(cam.sx(mxw), cam.sy(myw), rad, ui.stroke)
            val oxw = 105f - FX[i] * 105f + shift * (if (i == 0) 0.2f else 1f)
            val oyw = 68f - FY[i] * 68f + wob
            ui.circle(c, cam.sx(oxw), cam.sy(oyw), rad, oppShirt)
            c.drawCircle(cam.sx(oxw), cam.sy(oyw), rad, ui.stroke)
            if (i == idx && e.minute in e.startMinute..e.endMinute) {
                val px = cam.sx(mxw); val py = cam.sy(myw)
                ui.stroke.color = Palette.GOLD; ui.stroke.strokeWidth = 4f
                c.drawCircle(px, py, rad + 6f + sin(time * 5f) * 2f, ui.stroke)
                ui.text(c, "TÚ", px, py - rad - 14f, 22f, Palette.GOLD, Paint.Align.CENTER)
            }
        }
        ui.ball(c, cam.sx(bwx), cam.sy(bwy), max(5f, z * 0.6f), spin)
        if (phase == Phase.SIM) ui.text(c, if (speed > 1f) "VELOCIDAD x3  (toca para normal)" else "Toca la pantalla: velocidad x3", 24f, 700f, 20f, withAlpha(Palette.WHITE, 170))
    }

    private fun figS() = cam.zoom * 2.3f / 83f

    private fun drawScene(c: Canvas, o: Opportunity, e: MatchSimulationEngine) {
        val z = cam.zoom; val s = figS()
        val al = if (phase == Phase.INTRO) (pt / 0.4f).coerceIn(0f, 1f) else 1f
        // trayectoria entrante (intercepción)
        val a = o.incomingFrom; val b = o.incomingTo
        if (a != null && b != null) {
            ui.dash.color = withAlpha(Palette.RED, 200)
            c.drawLine(cam.sx(a.x), cam.sy(a.y), cam.sx(b.x), cam.sy(b.y), ui.dash)
            ui.opponent(c, cam.sx(a.x) + 0f, cam.sy(a.y) + 20f * s, s, oppShirt, oppShorts, -1f, 0f, false)
            ui.opponent(c, cam.sx(b.x), cam.sy(b.y) + 20f * s, s, oppShirt, oppShorts, 1f, 0f, false)
        } else {
            for (i in o.defenders.indices) { val d = o.defenders[i]; ui.opponent(c, cam.sx(d.x), cam.sy(d.y) + 20f * s, s, oppShirt, oppShorts, -1f, time * 6f, false) }
        }
        for (i in o.teammates.indices) {
            val t = o.teammates[i]
            val col = if (t.openness > 0.6f) Palette.ACCENT else if (t.openness > 0.35f) Palette.GOLD else Palette.RED
            ui.stroke.color = withAlpha(col, 200); ui.stroke.strokeWidth = 4f
            c.drawCircle(cam.sx(t.pos.x), cam.sy(t.pos.y), z * 1.7f + sin(time * 5f + i) * 2f, ui.stroke)
            ui.figure(c, cam.sx(t.pos.x), cam.sy(t.pos.y) + 20f * s, s, 0xFFEAB98C.toInt(), 0xFF2A1A10.toInt(), 0, myShirt, myShorts, darken(myShirt, 0.7f), 1f, 0f, false)
        }
        if (o.keeper != null) ui.figure(c, cam.sx(kX), cam.sy(kY) + 20f * s, s, 0xFFD9A77F.toInt(), 0xFF2A1A10.toInt(), 1, 0xFF22AA44.toInt(), 0xFF145A26.toInt(), 0xFF145A26.toInt(), -1f, 0f, false)
        val moving = phase == Phase.FLIGHT && (res?.playerEnd != null)
        val jump = if (phase == Phase.RESULT && celebrate) abs(sin(pt * 9f)) * 16f else 0f
        val px = cam.sx(pX); val py = cam.sy(pY) + 20f * s
        ui.player(c, px, py, s * 1.08f, e.player.appearance, myShirt, myShorts, 1f, time * 14f, moving, jump)
        if (phase == Phase.WAIT || phase == Phase.INTRO) ui.icon(c, ICON_DOWN, px, py - 100f * s - 8f + sin(time * 6f) * 3f, 9f, Palette.GOLD)
        // balón (con arco si es de altura)
        val bx = cam.sx(ballX); val by = cam.sy(ballY)
        var h = 0f
        if (phase == Phase.FLIGHT && res?.lofted == true) h = sin(PI.toFloat() * (pt / flightDur).coerceIn(0f, 1f)) * 70f
        if (phase == Phase.FLIGHT) { // estela
            for (k in 1..4) {
                val q = ((pt / flightDur) - k * 0.05f).coerceAtLeast(0f)
                ui.circle(c, cam.sx(fx0 + (fx1 - fx0) * q), cam.sy(fy0 + (fy1 - fy0) * q) - (if (res?.lofted == true) sin(PI.toFloat() * q) * 70f else 0f), max(3f, z * 0.45f) * (1f - k * 0.18f), withAlpha(Palette.WHITE, 90 - k * 18))
            }
        }
        if (h > 0f) ui.circle(c, bx, by, max(4f, z * 0.4f), 0x55000000)
        ui.ball(c, bx, by - h, max(6f, z * 0.62f), spin)
        if (al < 1f) ui.fillRect(c, 0f, 0f, 1280f, 720f, withAlpha(0xFF000000.toInt(), ((1f - al) * 70).toInt()))
    }

    private fun drawOverlay(c: Canvas, o: Opportunity) {
        val t = o.type
        // banner de oportunidad
        if (phase == Phase.INTRO || phase == Phase.WAIT) {
            val k = Ease.outBack((pt / 0.35f).coerceIn(0f, 1f).let { if (phase == Phase.WAIT) 1f else it })
            c.save(); c.scale(k, k, 640f, 135f)
            ui.panel(c, 340f, 108f, 600f, 70f, withAlpha(0xFF050B14.toInt(), 220), Palette.GOLD, 16f)
            ui.text(c, t.label, 380f, 156f, 40f, Palette.GOLD)
            ui.textFit(c, t.hint, 940f - 20f, 154f, 22f, 380f, Palette.WHITE, Paint.Align.RIGHT)
            c.restore()
        }
        if (phase == Phase.WAIT) {
            val ax = anchorX(o); val ay = anchorY(o)
            if (!dragging) {
                ui.stroke.color = withAlpha(Palette.GOLD, 220); ui.stroke.strokeWidth = 4f
                c.drawCircle(ax, ay, 46f + sin(time * 6f) * 6f, ui.stroke)
            } else drawAim(c, o, ax, ay)
        }
        if (phase == Phase.RESULT) {
            val k = Ease.outBack((pt / 0.3f).coerceIn(0f, 1f))
            c.save(); c.scale(k, k, 640f, 250f)
            ui.text(c, bannerHead, 640f, 260f, if (celebrate) 96f else 70f, bannerColor, Paint.Align.CENTER)
            if (bannerDetail.isNotEmpty()) ui.text(c, bannerDetail, 640f, 308f, 30f, Palette.WHITE, Paint.Align.CENTER)
            c.restore()
        }
    }

    private fun drawAim(c: Canvas, o: Opportunity, ax: Float, ay: Float) {
        val t = o.type
        val wl = hypot(dragX, dragY) / cam.zoom
        val power = (wl / t.maxLen).coerceIn(0f, 1f)
        val dxn = if (wl > 0.001f) dragX / cam.zoom / wl else 1f
        val dyn = if (wl > 0.001f) dragY / cam.zoom / wl else 0f
        val col = if (power < 0.5f) Palette.ACCENT else if (power < 0.85f) Palette.GOLD else Palette.RED
        ui.line(c, ax, ay, ax + dragX, ay + dragY, 8f, withAlpha(col, 230))
        ui.circle(c, ax + dragX, ay + dragY, 14f, col)
        if (t == OpportunityType.SHOT) {
            if (dxn > 0.08f) {
                val tt = (105f - o.ball.x) / dxn
                val ay2 = o.ball.y + dyn * tt
                ui.dash.color = withAlpha(Palette.WHITE, 220)
                c.drawLine(cam.sx(o.ball.x), cam.sy(o.ball.y), cam.sx(105f), cam.sy(ay2), ui.dash)
                val cy = cam.sy(ay2.coerceIn(20f, 48f))
                ui.stroke.color = Palette.RED; ui.stroke.strokeWidth = 4f
                c.drawCircle(cam.sx(105f), cy, 14f, ui.stroke)
            }
        } else {
            val lx = cam.sx((if (t == OpportunityType.INTERCEPTION) o.player.x else o.ball.x) + dxn * power * t.range)
            val ly = cam.sy((if (t == OpportunityType.INTERCEPTION) o.player.y else o.ball.y) + dyn * power * t.range)
            ui.stroke.color = withAlpha(Palette.WHITE, 230); ui.stroke.strokeWidth = 4f
            c.drawCircle(lx, ly, 20f, ui.stroke)
        }
        ui.text(c, "POTENCIA", 640f, 662f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.bar(c, 490f, 672f, 300f, 18f, power, col)
    }

    private fun drawHud(c: Canvas, e: MatchSimulationEngine) {
        val sec = e.clockSeconds.toInt().coerceAtMost(5400)
        if (sec != clockSec) { clockSec = sec; clockStr = "%02d:%02d".format(sec / 60, sec % 60) }
        val key = e.homeGoals * 100 + e.awayGoals
        if (key != scoreKey) {
            scoreKey = key
            scoreStr = "${e.home.abbr}  ${e.homeGoals} - ${e.awayGoals}  ${e.away.abbr}"
            ratingStr = "%.1f".format(e.currentRating())
        }
        ui.panel(c, 400f, 8f, 480f, 92f, withAlpha(0xFF050B14.toInt(), 215), Palette.PANEL_LIGHT, 16f)
        ui.text(c, clockStr, 640f, 44f, 34f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, scoreStr, 640f, 88f, 38f, Palette.WHITE, Paint.Align.CENTER)
        ui.circle(c, 430f, 54f, 14f, e.home.primary); ui.circle(c, 850f, 54f, 14f, e.away.primary)
        ui.panel(c, 1120f, 640f, 140f, 66f, withAlpha(0xFF050B14.toInt(), 200), Palette.PANEL_LIGHT, 14f)
        ui.text(c, ratingStr, 1190f, 690f, 40f, Palette.ACCENT, Paint.Align.CENTER)
        ui.text(c, "RATING", 1190f, 660f, 14f, Palette.TEXT_DIM, Paint.Align.CENTER)
        if (phase == Phase.SIM) {
            if (e.events.size != evCount) {
                evCount = e.events.size
                val ev = e.events[e.events.size - 1]
                evStr = "%02d'  %s".format(ev.minute, ev.text)
            }
            ui.text(c, evStr, 640f, 700f, 26f, Palette.WHITE, Paint.Align.CENTER)
        }
    }
}
