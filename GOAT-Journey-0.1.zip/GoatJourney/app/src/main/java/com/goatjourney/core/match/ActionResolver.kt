package com.goatjourney.core.match

import com.goatjourney.core.player.Attributes
import kotlin.math.*
import kotlin.random.Random

/**
 * Resuelve un gesto sobre una oportunidad. El resultado depende de atributos, presión,
 * calidad de la ocasión y SOBRE TODO de cómo ejecutó el gesto el jugador (dirección y potencia).
 */
class ActionResolver(private val rng: Random) {

    fun resolve(op: Opportunity, g: Gesture, a: Attributes): ActionResult = when (op.type) {
        OpportunityType.PASS -> pass(op, g, a)
        OpportunityType.SHOT -> shot(op, g, a)
        OpportunityType.DRIBBLE -> dribble(op, g, a)
        OpportunityType.CROSS -> cross(op, g, a)
        OpportunityType.INTERCEPTION -> interception(op, g, a)
        OpportunityType.CLEARANCE -> clearance(op, g, a)
    }

    private fun power(op: Opportunity, g: Gesture) = (g.len / op.type.maxLen).coerceIn(0.08f, 1f)
    private fun dirOf(g: Gesture): Vec { val l = g.len; return if (l < 0.001f) Vec(1f, 0f) else Vec(g.dx / l, g.dy / l) }
    private fun noise(): Float = (rng.nextFloat() + rng.nextFloat() + rng.nextFloat() - 1.5f) * 2f // ~N(0,1)

    private fun pass(op: Opportunity, g: Gesture, a: Attributes): ActionResult {
        val t = op.type
        val p = power(op, g); val dir = dirOf(g)
        val intended = op.ball + dir * (p * t.range)
        val skill = (a.passing * 0.5f + a.vision * 0.15f + a.control * 0.1f + a.decisions * 0.25f) / 100f
        val err = 1f + (1f - skill) * 5.5f + op.pressure * 3f + p * 2.5f
        val landing = Vec(intended.x + noise() * err * 0.5f, intended.y + noise() * err * 0.5f)
        var target: Target? = null
        var best = 9f
        for (tg in op.teammates) { val d = tg.pos.dist(intended); if (d < best) { best = d; target = tg } }
        var blocker: Vec? = null
        for (d in op.defenders) if (d.dist(op.ball) > 1f && Geo.distToSegment(d, op.ball, landing) < 2.2f) blocker = d
        val blocked = blocker != null && rng.nextFloat() < 0.5f
        val reached = target != null && !blocked && landing.dist(target.pos) < 3.8f
        val end = if (blocked) blocker!! else landing
        val flight = (op.ball.dist(end) / 22f).coerceIn(0.4f, 1.4f)
        if (!reached) {
            val head = if (blocked) "PASE INTERCEPTADO" else if (target == null) "PASE SIN DESTINO" else "PASE IMPRECISO"
            return ActionResult(t, false, 0.1f, listOf(op.ball, end), flight, head, "Pierdes la posesión", turnover = true)
        }
        val tg = target!!
        val q = ((1f - landing.dist(tg.pos) / 3.8f) * 0.5f + skill * 0.5f).coerceIn(0.1f, 1f)
        val forward = tg.pos.x - op.ball.x > 8f
        val chance = forward && tg.pos.x > 78f && tg.openness > 0.3f && rng.nextFloat() < 0.35f + 0.4f * q
        val head = if (chance) "¡PASE DE GOL!" else if (forward) "PASE AL FRENTE" else "PASE COMPLETADO"
        return ActionResult(t, true, q, listOf(op.ball, landing), flight, head, "", targetReached = true, chanceCreated = chance, receiver = tg.pos)
    }

    private fun shot(op: Opportunity, g: Gesture, a: Attributes): ActionResult {
        val t = op.type
        val p = power(op, g); val dir = dirOf(g); val b = op.ball
        val skill = (a.shooting * 0.35f + a.finishing * 0.35f + a.composure * 0.2f + a.control * 0.1f) / 100f
        if (dir.x < 0.08f) {
            return ActionResult(t, false, 0.1f, listOf(b, b + dir * 14f), 0.6f, "TIRO DESVIADO", "Disparaste lejos de la portería",
                shotOutcome = ShotOutcome.OFF_TARGET)
        }
        val tt = (Pitch.LENGTH - b.x) / dir.x
        val aimY = b.y + dir.y * tt
        val dist = hypot(Pitch.LENGTH - b.x, Pitch.CENTER_Y - b.y)
        val err = (1.6f + (1f - skill) * 6f + op.pressure * 3f + abs(p - 0.75f) * 3.5f + dist * 0.06f) * (1.2f - op.quality * 0.4f)
        val finalY = aimY + noise() * err * 0.5f
        val goalPt = Vec(Pitch.LENGTH, finalY)
        val flight = (dist / (18f + p * 14f)).coerceIn(0.35f, 1.2f)

        var blocker: Vec? = null
        for (d in op.defenders) if (d.x > b.x && Geo.distToSegment(d, b, goalPt) < 1.5f) blocker = d
        if (blocker != null && rng.nextFloat() < 0.6f - skill * 0.2f) {
            return ActionResult(t, false, 0.2f, listOf(b, blocker), 0.35f, "¡TIRO BLOQUEADO!", "Un defensor se interpone",
                shotOutcome = ShotOutcome.BLOCKED)
        }
        val off = abs(finalY - Pitch.CENTER_Y)
        if (off < Pitch.GOAL_HALF) {
            val k = op.keeper
            val kd = if (k != null) (abs(finalY - k.y) / Pitch.GOAL_HALF).coerceIn(0f, 1.5f) else 1f
            val save = (0.85f - kd * 0.5f - (p - 0.4f) * 0.35f - (skill - 0.5f) * 0.25f - (op.quality - 0.5f) * 0.1f).coerceIn(0.05f, 0.92f)
            val q = (0.5f + off / Pitch.GOAL_HALF * 0.3f + skill * 0.2f).coerceIn(0f, 1f)
            return if (rng.nextFloat() < save)
                ActionResult(t, false, q, listOf(b, goalPt), flight, "¡PARADA!", "El portero evita el gol", shotOutcome = ShotOutcome.SAVED)
            else
                ActionResult(t, true, q, listOf(b, goalPt), flight, "¡GOOOL!", "", goal = true, shotOutcome = ShotOutcome.GOAL)
        }
        return if (off < Pitch.GOAL_HALF + 0.4f)
            ActionResult(t, false, 0.4f, listOf(b, goalPt), flight, "¡AL PALO!", "Por centímetros", shotOutcome = ShotOutcome.POST)
        else
            ActionResult(t, false, 0.1f, listOf(b, goalPt), flight, "FUERA", "El balón se va desviado", shotOutcome = ShotOutcome.OFF_TARGET)
    }

    private fun dribble(op: Opportunity, g: Gesture, a: Attributes): ActionResult {
        val t = op.type
        val p = power(op, g); val dir = dirOf(g)
        val def = op.defenders[0]
        val tdx = def.x - op.ball.x; val tdy = def.y - op.ball.y
        val tl = max(0.001f, hypot(tdx, tdy))
        val cosA = ((dir.x * tdx + dir.y * tdy) / tl).coerceIn(-1f, 1f)
        val ang = acos(cosA)
        val side = when { ang < 0.35f -> 0f; ang <= 1.9f -> sin(ang); else -> 0.6f }
        val skill = (a.dribbling * 0.4f + a.control * 0.25f + a.speed * 0.15f + a.acceleration * 0.2f) / 100f
        val speedSkill = (a.speed + a.acceleration) / 200f
        val score = 0.15f + skill * 0.55f + side * 0.35f + (p - 0.5f) * 0.12f * (speedSkill - 0.4f) * 2f - op.pressure * 0.25f + noise() * 0.06f
        val ok = score > 0.52f
        if (ok) {
            val end = op.ball + dir * (p * t.range)
            return ActionResult(t, true, (score - 0.3f).coerceIn(0.2f, 1f), listOf(op.ball, end), 0.7f, "¡REGATE!", "Superas al defensor",
                targetReached = true, playerEnd = end)
        }
        val foul = rng.nextFloat() < 0.18f
        return ActionResult(t, false, 0.1f, listOf(op.ball, def), 0.5f,
            if (foul) "FALTA A TU FAVOR" else "REGATE FALLIDO",
            if (foul) "El defensor te derriba" else "El defensor te quita el balón",
            turnover = !foul, foul = foul, playerEnd = op.ball)
    }

    private fun cross(op: Opportunity, g: Gesture, a: Attributes): ActionResult {
        val t = op.type
        val p = power(op, g); val dir = dirOf(g)
        val intended = op.ball + dir * (p * t.range)
        val skill = (a.crossing * 0.55f + a.control * 0.1f + a.vision * 0.15f + a.decisions * 0.1f + a.passing * 0.1f) / 100f
        val err = 1.5f + (1f - skill) * 6f + op.pressure * 3f
        val landing = Vec(intended.x + noise() * err * 0.5f, intended.y + noise() * err * 0.5f)
        var target: Target? = null
        var best = 7f
        for (tg in op.teammates) { val d = tg.pos.dist(intended); if (d < best) { best = d; target = tg } }
        val flight = (op.ball.dist(landing) / 18f).coerceIn(0.6f, 1.5f)
        val reached = target != null && landing.dist(target.pos) < 4.5f
        if (!reached) {
            return ActionResult(t, false, 0.1f, listOf(op.ball, landing), flight, "CENTRO FALLIDO", "Nadie llega al balón",
                turnover = true, lofted = true)
        }
        val tg = target!!
        val q = (tg.openness * 0.5f + skill * 0.5f).coerceIn(0.1f, 1f)
        return ActionResult(t, true, q, listOf(op.ball, landing), flight, "¡BUEN CENTRO!", "El delantero lo gana",
            targetReached = true, chanceCreated = true, lofted = true, receiver = tg.pos)
    }

    private fun interception(op: Opportunity, g: Gesture, a: Attributes): ActionResult {
        val t = op.type
        val from = op.incomingFrom!!; val to = op.incomingTo!!
        val p = power(op, g); val dir = dirOf(g)
        val reach = op.player + dir * (p * t.range)
        val c = Geo.closest(reach, from, to)
        val d = c.dist(reach)
        val reachR = 2f + (a.positioning + a.decisions) / 200f * 2.5f + a.control / 100f * 0.5f
        val vp = 5.5f + (a.speed + a.acceleration) / 200f * 3.5f
        val tp = op.player.dist(c) / vp
        val tb = c.dist(from) / 17f
        val ok = d < reachR && tp <= tb + 0.25f + noise() * 0.1f
        return if (ok)
            ActionResult(t, true, (1f - d / reachR).coerceIn(0.2f, 1f), listOf(from, c), (tb).coerceIn(0.3f, 1.2f),
                "¡INTERCEPTADO!", "Recuperas la posesión", targetReached = true, newPossession = true, playerEnd = c)
        else
            ActionResult(t, false, 0.1f, listOf(from, to), 0.9f, "NO LLEGAS", "El balón sigue su camino",
                opponentChance = rng.nextFloat() < 0.25f, playerEnd = reach)
    }

    private fun clearance(op: Opportunity, g: Gesture, a: Attributes): ActionResult {
        val t = op.type
        val p = power(op, g); val dir = dirOf(g)
        val end = op.ball + dir * (p * t.range)
        val dirScore = (dir.x * 0.6f + abs(dir.y) * 0.6f).coerceIn(-0.6f, 1f)
        val skill = (a.strength * 0.2f + a.control * 0.2f + a.composure * 0.25f + a.decisions * 0.2f + a.positioning * 0.15f) / 100f
        val score = 0.2f + dirScore * 0.35f + skill * 0.4f + p * 0.1f - op.pressure * 0.25f + noise() * 0.06f
        val ok = score > 0.5f && dir.x > -0.35f
        return if (ok)
            ActionResult(t, true, score.coerceIn(0.2f, 1f), listOf(op.ball, end), 0.9f, "¡DESPEJE!", "Alejas el peligro", targetReached = true, newPossession = true, lofted = true)
        else
            ActionResult(t, false, 0.1f, listOf(op.ball, end), 0.6f, "DESPEJE CORTO", "El balón sigue en la zona",
                opponentChance = rng.nextFloat() < 0.55f, lofted = true)
    }
}

/** Genera un gesto "razonable" para SIMULAR: pasa por el MISMO ActionResolver que un gesto humano. */
object AutoPlayer {
    private fun scaleLen(op: Opportunity, meters: Float) = (meters / op.type.range * op.type.maxLen)

    private fun rot(v: Vec, ang: Float): Vec = Vec(v.x * cos(ang) - v.y * sin(ang), v.x * sin(ang) + v.y * cos(ang))

    private fun toward(op: Opportunity, from: Vec, to: Vec, rng: Random, skill: Float): Gesture {
        val d = from.dist(to)
        val dir = Vec((to.x - from.x) / max(0.01f, d), (to.y - from.y) / max(0.01f, d))
        val jitter = (rng.nextFloat() - 0.5f) * 0.12f * (1f - skill)
        val r = rot(dir, jitter)
        val len = scaleLen(op, d)
        return Gesture(r.x * len, r.y * len)
    }

    fun gesture(op: Opportunity, a: Attributes, rng: Random): Gesture {
        val skill = (a.decisions / 100f).coerceIn(0f, 1f)
        return when (op.type) {
            OpportunityType.PASS, OpportunityType.CROSS -> {
                var best = op.teammates[0]; var bs = -9f
                for (t in op.teammates) {
                    val s = t.openness * 0.8f + (t.pos.x - op.ball.x) / 60f * 0.5f + rng.nextFloat() * (1f - skill) * 0.8f
                    if (s > bs) { bs = s; best = t }
                }
                toward(op, op.ball, best.pos, rng, skill)
            }
            OpportunityType.SHOT -> {
                val k = op.keeper
                val ty = if (k != null && k.y > 34f) 31.4f else 36.6f
                val dir = Vec(105f - op.ball.x, ty - op.ball.y)
                val l = max(0.01f, dir.len())
                val r = rot(Vec(dir.x / l, dir.y / l), (rng.nextFloat() - 0.5f) * 0.1f * (1f - skill))
                val len = 0.7f * op.type.maxLen
                Gesture(r.x * len, r.y * len)
            }
            OpportunityType.DRIBBLE -> {
                val def = op.defenders[0]
                val td = Vec(def.x - op.ball.x, def.y - op.ball.y)
                val l = max(0.01f, td.len())
                val sign = if (def.y > op.ball.y) -1f else 1f
                val r = rot(Vec(td.x / l, td.y / l), sign * (1.2f + rng.nextFloat() * 0.3f))
                val len = 0.7f * op.type.maxLen
                Gesture(r.x * len, r.y * len)
            }
            OpportunityType.INTERCEPTION -> {
                val c = Geo.closest(op.player, op.incomingFrom!!, op.incomingTo!!)
                val d = c.dist(op.player)
                val dir = Vec((c.x - op.player.x) / max(0.01f, d), (c.y - op.player.y) / max(0.01f, d))
                val len = max(1.5f, min(scaleLen(op, d), op.type.maxLen))
                Gesture(dir.x * len, dir.y * len)
            }
            OpportunityType.CLEARANCE -> {
                val sy = if (op.player.y > 34f) 0.8f else -0.8f
                val l = hypot(0.55f, sy)
                val len = 0.8f * op.type.maxLen
                Gesture(0.55f / l * len, sy / l * len)
            }
        }
    }
}
