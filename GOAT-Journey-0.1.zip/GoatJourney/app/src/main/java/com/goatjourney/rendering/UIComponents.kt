package com.goatjourney.rendering

import android.graphics.*
import com.goatjourney.core.player.Appearance
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

object Palette {
    val BG = 0xFF0A1424.toInt()
    val BG2 = 0xFF12233D.toInt()
    val PANEL = 0xE6162B4A.toInt()
    val PANEL_LIGHT = 0xFF2A4A7A.toInt()
    val ACCENT = 0xFF2EE6A6.toInt()
    val GOLD = 0xFFFFC857.toInt()
    val RED = 0xFFFF5470.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val TEXT_DIM = 0xFF8FA6C4.toInt()
    val GRASS_DARK = 0xFF1F6B38.toInt()
    val GRASS1 = 0xFF2E8B4A.toInt()
    val GRASS2 = 0xFF2A7F43.toInt()
}

fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

fun darken(color: Int, f: Float = 0.62f): Int =
    Color.rgb((((color shr 16) and 255) * f).toInt(), (((color shr 8) and 255) * f).toInt(), ((color and 255) * f).toInt())

const val ICON_LEFT = 0
const val ICON_RIGHT = 1
const val ICON_UP = 2
const val ICON_DOWN = 3

class Btn(
    val id: String, val x: Float, val y: Float, val w: Float, val h: Float,
    var label: String, val style: Int = 0, val icon: Int = -1
) {
    var enabled = true
    var visible = true
    fun contains(px: Float, py: Float) = px >= x && px <= x + w && py >= y && py <= y + h
}

/** Sistema visual reutilizable: paneles, botones, texto, barras, jugadores, balón. Todo con Paints preasignados. */
class UI {
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }
    val rect = RectF()
    val path = Path()

    fun fillRect(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int) {
        fill.color = color; c.drawRect(x, y, x + w, y + h, fill)
    }

    fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill.color = color; c.drawCircle(x, y, r, fill)
    }

    fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        stroke.color = color; stroke.strokeWidth = w; c.drawLine(x1, y1, x2, y2, stroke)
    }

    fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Palette.WHITE, align: Paint.Align = Paint.Align.LEFT) {
        txt.textSize = size; txt.color = color; txt.textAlign = align
        c.drawText(s, x, y, txt)
    }

    fun textFit(c: Canvas, s: String, x: Float, y: Float, size: Float, maxW: Float, color: Int, align: Paint.Align) {
        txt.textSize = size
        val w = txt.measureText(s)
        text(c, s, x, y, if (w > maxW) size * maxW / w else size, color, align)
    }

    fun panel(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int = Palette.PANEL, border: Int = Palette.PANEL_LIGHT, r: Float = 18f) {
        rect.set(x, y, x + w, y + h)
        fill.color = color; c.drawRoundRect(rect, r, r, fill)
        stroke.color = border; stroke.strokeWidth = 2f; c.drawRoundRect(rect, r, r, stroke)
    }

    fun button(c: Canvas, b: Btn, pressed: Boolean) {
        val off = if (pressed) 5f else 0f
        var base = when (b.style) { 0 -> Palette.ACCENT; 2 -> Palette.RED; else -> Palette.PANEL_LIGHT }
        if (!b.enabled) base = withAlpha(base, 80)
        rect.set(b.x, b.y + 6f, b.x + b.w, b.y + b.h + 6f)
        fill.color = darken(base); c.drawRoundRect(rect, 16f, 16f, fill)
        rect.set(b.x, b.y + off, b.x + b.w, b.y + b.h + off - 2f)
        fill.color = base; c.drawRoundRect(rect, 16f, 16f, fill)
        val fg = if (!b.enabled) Palette.TEXT_DIM else if (b.style == 0) Palette.BG else Palette.WHITE
        if (b.icon >= 0) icon(c, b.icon, b.x + b.w / 2f, b.y + b.h / 2f + off, b.h * 0.22f, fg)
        else textFit(c, b.label, b.x + b.w / 2f, b.y + b.h * 0.64f + off, b.h * 0.42f, b.w - 24f, fg, Paint.Align.CENTER)
    }

    fun icon(c: Canvas, kind: Int, cx: Float, cy: Float, s: Float, color: Int) {
        fill.color = color; path.reset()
        when (kind) {
            ICON_LEFT -> { path.moveTo(cx + s * 0.6f, cy - s); path.lineTo(cx - s * 0.7f, cy); path.lineTo(cx + s * 0.6f, cy + s) }
            ICON_RIGHT -> { path.moveTo(cx - s * 0.6f, cy - s); path.lineTo(cx + s * 0.7f, cy); path.lineTo(cx - s * 0.6f, cy + s) }
            ICON_UP -> { path.moveTo(cx - s, cy + s * 0.6f); path.lineTo(cx, cy - s * 0.7f); path.lineTo(cx + s, cy + s * 0.6f) }
            else -> { path.moveTo(cx - s, cy - s * 0.6f); path.lineTo(cx, cy + s * 0.7f); path.lineTo(cx + s, cy - s * 0.6f) }
        }
        path.close(); c.drawPath(path, fill)
    }

    fun bar(c: Canvas, x: Float, y: Float, w: Float, h: Float, frac: Float, color: Int) {
        rect.set(x, y, x + w, y + h); fill.color = withAlpha(Palette.WHITE, 30); c.drawRoundRect(rect, h / 2f, h / 2f, fill)
        val fw = (w * frac.coerceIn(0f, 1f)).coerceAtLeast(h)
        rect.set(x, y, x + fw, y + h); fill.color = color; c.drawRoundRect(rect, h / 2f, h / 2f, fill)
    }

    fun header(c: Canvas, title: String, right: String = "") {
        fillRect(c, 0f, 0f, 1280f, 76f, Palette.BG2)
        fillRect(c, 0f, 74f, 1280f, 4f, Palette.ACCENT)
        text(c, title, 40f, 54f, 40f, Palette.WHITE)
        if (right.isNotEmpty()) text(c, right, 1240f, 52f, 30f, Palette.GOLD, Paint.Align.RIGHT)
    }

    fun statRow(c: Canvas, x: Float, y: Float, w: Float, label: String, value: String) {
        text(c, label, x, y, 26f, Palette.TEXT_DIM)
        text(c, value, x + w, y, 28f, Palette.WHITE, Paint.Align.RIGHT)
        fillRect(c, x, y + 10f, w, 2f, withAlpha(Palette.WHITE, 24))
    }

    fun badge(c: Canvas, cx: Float, cy: Float, r: Float, primary: Int, secondary: Int, abbr: String) {
        circle(c, cx, cy, r, secondary)
        circle(c, cx, cy, r * 0.86f, primary)
        val lum = ((primary shr 16 and 255) * 3 + (primary shr 8 and 255) * 6 + (primary and 255)) / 10
        text(c, abbr, cx, cy + r * 0.2f, r * 0.62f, if (lum > 150) 0xFF111111.toInt() else Palette.WHITE, Paint.Align.CENTER)
    }

    fun ball(c: Canvas, x: Float, y: Float, r: Float, spin: Float) {
        circle(c, x, y, r, Palette.WHITE)
        for (k in 0 until 3) {
            val a = spin + k * 2.0944f
            circle(c, x + cos(a) * r * 0.5f, y + sin(a) * r * 0.5f, r * 0.27f, 0xFF222222.toInt())
        }
        stroke.color = 0xFF222222.toInt(); stroke.strokeWidth = max1(r * 0.12f); c.drawCircle(x, y, r, stroke)
    }

    private fun max1(v: Float) = if (v < 1f) 1f else v

    /** Figura de jugador (pies en x,y). s = escala, facing = 1 derecha / -1 izquierda. */
    fun figure(
        c: Canvas, x: Float, y: Float, s: Float, skin: Int, hair: Int, hairStyle: Int,
        shirt: Int, shorts: Int, accent: Int, facing: Float, phase: Float, moving: Boolean, jump: Float = 0f
    ) {
        c.save(); c.translate(x, y - jump); c.scale(s * facing, s)
        fill.color = 0x44000000; rect.set(-16f, -4f + jump / s, 16f, 4f + jump / s); c.drawOval(rect, fill)
        val sw = if (moving) sin(phase) * 6f else 0f
        fill.color = skin
        rect.set(-10f + sw, -24f, -3f + sw, -2f); c.drawRect(rect, fill)
        rect.set(3f - sw, -24f, 10f - sw, -2f); c.drawRect(rect, fill)
        fill.color = accent
        rect.set(-11f + sw, -5f, -2f + sw, 0f); c.drawRoundRect(rect, 2f, 2f, fill)
        rect.set(2f - sw, -5f, 11f - sw, 0f); c.drawRoundRect(rect, 2f, 2f, fill)
        fill.color = shorts; rect.set(-13f, -35f, 13f, -22f); c.drawRoundRect(rect, 4f, 4f, fill)
        fill.color = skin
        val arm = if (moving) sin(phase + 3.14f) * 5f else 0f
        rect.set(-20f, -58f + arm, -14f, -40f + arm); c.drawRect(rect, fill)
        rect.set(14f, -58f - arm, 20f, -40f - arm); c.drawRect(rect, fill)
        fill.color = shirt; rect.set(-15f, -62f, 15f, -33f); c.drawRoundRect(rect, 7f, 7f, fill)
        fill.color = accent
        rect.set(-20f, -62f + arm, -14f, -52f + arm); c.drawRect(rect, fill)
        rect.set(14f, -62f - arm, 20f, -52f - arm); c.drawRect(rect, fill)
        if (hairStyle == 2) { fill.color = hair; c.drawCircle(0f, -71f, 13f, fill) }
        fill.color = skin; c.drawCircle(0f, -71f, 10f, fill)
        fill.color = hair
        when (hairStyle) {
            0 -> { rect.set(-10.5f, -82f, 10.5f, -60f); c.drawArc(rect, 180f, 180f, true, fill) }
            1 -> { rect.set(-10f, -82f, 10f, -74f); c.drawRoundRect(rect, 3f, 3f, fill) }
            2 -> { rect.set(-10.5f, -83f, 10.5f, -65f); c.drawArc(rect, 180f, 180f, true, fill) }
            else -> {}
        }
        fill.color = 0xFF222222.toInt(); c.drawCircle(-3.5f, -70f, 1.4f, fill); c.drawCircle(3.5f, -70f, 1.4f, fill)
        c.restore()
    }

    fun player(c: Canvas, x: Float, y: Float, s: Float, a: Appearance, shirt: Int, shorts: Int, facing: Float, phase: Float, moving: Boolean, jump: Float = 0f) {
        figure(
            c, x, y, s, Appearance.SKINS[a.skin], Appearance.HAIRS[a.hair], a.hairStyle, shirt, shorts,
            Appearance.ACCENTS[a.shirt], facing, phase, moving, jump
        )
    }

    fun opponent(c: Canvas, x: Float, y: Float, s: Float, shirt: Int, shorts: Int, facing: Float, phase: Float, moving: Boolean) {
        figure(c, x, y, s, 0xFFD9A77F.toInt(), 0xFF2A1A10.toInt(), 0, shirt, shorts, darken(shirt, 0.7f), facing, phase, moving)
    }

    fun absf(v: Float) = abs(v)
}
