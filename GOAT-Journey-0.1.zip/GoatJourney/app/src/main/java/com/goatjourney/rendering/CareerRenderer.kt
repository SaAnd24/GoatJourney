package com.goatjourney.rendering

import android.graphics.Canvas
import android.graphics.Paint
import com.goatjourney.core.career.*
import com.goatjourney.core.match.MatchImportance
import com.goatjourney.core.player.Attributes
import com.goatjourney.core.simulation.MatchMode
import com.goatjourney.core.simulation.RatingLabel
import com.goatjourney.game.GameController
import com.goatjourney.game.GameState

private fun GameController.shirt(): Int = career!!.club().primary
private fun GameController.shorts(): Int = career!!.club().secondary

/** MAIN CAREER SCREEN */
class CareerScreen(g: GameController) : BaseScreen(g) {
    private val bMain = btn("main", 880f, 236f, 330f, 66f, "JUGAR PARTIDO")
    private val bPlayer = btn("player", 40f, 590f, 220f, 80f, "JUGADOR", 1)
    private val bCal = btn("cal", 285f, 590f, 220f, 80f, "CALENDARIO", 1)
    private val bTable = btn("table", 530f, 590f, 220f, 80f, "TABLA", 1)
    private val bSave = btn("save", 775f, 590f, 220f, 80f, "GUARDAR", 1)
    private val bSet = btn("set", 1020f, 590f, 220f, 80f, "AJUSTES", 1)

    private var info = ""; private var sub = ""; private var date = ""; private var mainLabel = ""
    private var l1 = ""; private var l2 = ""; private var l3 = ""; private var l4 = ""; private var l5 = ""
    private var who = ""; private var meta = ""; private var clubName = ""; private var ovr = ""
    private var savedFlash = 0f

    override fun onEnter() { super.onEnter(); refresh() }

    private fun refresh() {
        val s = game.career ?: return
        val p = s.player
        who = p.fullName(); meta = "${p.age} años  ·  ${p.position.label}  ·  #${p.shirtNumber}"
        clubName = s.club().name; ovr = p.overall.toString()
        date = CareerDate.format(s.currentDay) + "  ·  Temporada ${s.season}"
        val e = s.nextEntry()
        if (e == null) { info = "TEMPORADA COMPLETADA"; sub = "Posición final: ${s.tablePosition()}º"; mainLabel = "NUEVA TEMPORADA" }
        else if (e.type == EntryType.TRAINING) { info = "ENTRENAMIENTO"; sub = CareerDate.format(e.day); mainLabel = "ENTRENAR" }
        else {
            val f = s.fixtureOf(e)!!
            val home = f.homeId == p.clubId
            val opp = s.clubById(if (home) f.awayId else f.homeId)
            info = "J${f.matchday + 1}  vs  ${opp.name}"
            sub = CareerDate.format(e.day) + "  ·  " + (if (home) "LOCAL" else "VISITANTE") + (if (f.importance == MatchImportance.IMPORTANT) "  ·  IMPORTANTE" else "")
            mainLabel = "JUGAR PARTIDO"
        }
        bMain.label = mainLabel
        val st = s.seasonStats
        l1 = "${st.matches}"; l2 = "${st.goals}"; l3 = "${st.assists}"
        l4 = if (st.matchRatings.isEmpty()) "-" else "%.1f".format(st.averageRating()); l5 = "${s.tablePosition()}º"
    }

    override fun draw(c: Canvas) {
        game.career ?: return
        ui.fillRect(c, 0f, 0f, 1280f, 720f, Palette.BG)
        ui.header(c, "CARRERA", date)
        ui.panel(c, 40f, 100f, 400f, 460f)
        val s = game.career!!
        ui.player(c, 240f, 400f, 3.1f, s.player.appearance, game.shirt(), game.shorts(), 1f, time * 3f, false)
        ui.text(c, who, 240f, 440f, 34f, Palette.WHITE, Paint.Align.CENTER)
        ui.text(c, meta, 240f, 474f, 22f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, clubName, 240f, 512f, 28f, Palette.GOLD, Paint.Align.CENTER)
        ui.circle(c, 370f, 160f, 44f, Palette.ACCENT)
        ui.text(c, ovr, 370f, 176f, 52f, Palette.BG, Paint.Align.CENTER)
        ui.text(c, "OVR", 370f, 224f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.panel(c, 470f, 100f, 770f, 220f)
        ui.text(c, "PRÓXIMO", 496f, 142f, 24f, Palette.ACCENT)
        ui.textFit(c, info, 496f, 200f, 44f, 740f, Palette.WHITE, Paint.Align.LEFT)
        ui.text(c, sub, 496f, 240f, 24f, Palette.TEXT_DIM)
        ui.panel(c, 470f, 340f, 770f, 220f)
        ui.text(c, "TEMPORADA", 496f, 382f, 24f, Palette.ACCENT)
        val labs = arrayOf("PJ", "GOLES", "ASIST.", "RATING", "TABLA")
        val vals = arrayOf(l1, l2, l3, l4, l5)
        for (i in 0 until 5) {
            val cx = 560f + i * 150f
            ui.text(c, vals[i], cx, 480f, 56f, Palette.WHITE, Paint.Align.CENTER)
            ui.text(c, labs[i], cx, 520f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        }
        drawButtons(c)
        if (savedFlash > 0f) ui.text(c, "PARTIDA GUARDADA", 640f, 700f, 24f, withAlpha(Palette.ACCENT, (savedFlash.coerceAtMost(1f) * 255).toInt()), Paint.Align.CENTER)
    }

    override fun update(dt: Float) { super.update(dt); if (savedFlash > 0f) savedFlash -= dt }

    override fun onButton(id: String) {
        val s = game.career ?: return
        when (id) {
            "main" -> {
                val e = s.nextEntry()
                when {
                    e == null -> { game.newSeason(); refresh() }
                    e.type == EntryType.TRAINING -> { game.advanceTraining(); refresh() }
                    else -> game.go(GameState.MATCH_PREVIEW)
                }
            }
            "player" -> game.go(GameState.PLAYER)
            "cal" -> game.go(GameState.CALENDAR)
            "table" -> game.go(GameState.TABLE)
            "save" -> { game.saveNow(); savedFlash = 2f }
            "set" -> game.go(GameState.SETTINGS)
        }
    }

    override fun onBack(): Boolean { game.saveNow(); game.go(GameState.TITLE); return true }
}

/** PLAYER SCREEN */
class PlayerScreen(g: GameController) : BaseScreen(g) {
    private val bBack = btn("back", 40f, 620f, 260f, 70f, "VOLVER", 1)
    private var vals = IntArray(14)
    private var ovr = ""; private var who = ""; private var meta = ""

    override fun onEnter() {
        super.onEnter()
        val p = game.career!!.player
        vals = p.attributes.toArray(); ovr = p.overall.toString(); who = p.fullName()
        meta = "${p.age} años · ${p.position.label} · Pie ${p.preferredFoot.label.lowercase()} · ${p.nationality}"
    }

    private fun group(c: Canvas, title: String, x: Float, y: Float, from: Int, to: Int) {
        ui.text(c, title, x, y, 26f, Palette.ACCENT)
        for (i in from..to) {
            val ry = y + 40f + (i - from) * 46f
            ui.text(c, Attributes.NAMES[i], x, ry, 24f, Palette.WHITE)
            ui.bar(c, x + 190f, ry - 18f, 120f, 14f, vals[i] / 100f, if (vals[i] >= 60) Palette.ACCENT else Palette.GOLD)
            ui.text(c, vals[i].toString(), x + 400f, ry, 26f, Palette.WHITE, Paint.Align.RIGHT)
        }
    }

    override fun draw(c: Canvas) {
        val s = game.career ?: return
        ui.fillRect(c, 0f, 0f, 1280f, 720f, Palette.BG)
        ui.header(c, "JUGADOR")
        ui.panel(c, 40f, 100f, 360f, 500f)
        ui.player(c, 220f, 340f, 2.8f, s.player.appearance, game.shirt(), game.shorts(), 1f, 0f, false)
        ui.text(c, who, 220f, 400f, 30f, Palette.WHITE, Paint.Align.CENTER)
        ui.textFit(c, meta, 220f, 432f, 20f, 330f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.circle(c, 220f, 510f, 48f, Palette.ACCENT)
        ui.text(c, ovr, 220f, 528f, 56f, Palette.BG, Paint.Align.CENTER)
        ui.text(c, "OVR", 220f, 578f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.panel(c, 430f, 100f, 810f, 590f)
        group(c, "TÉCNICOS", 460f, 145f, 0, 5)
        group(c, "FÍSICOS", 870f, 145f, 6, 9)
        group(c, "MENTALES", 870f, 370f, 10, 13)
        drawButtons(c)
    }

    override fun onButton(id: String) { game.go(GameState.CAREER) }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** CALENDAR */
class CalendarScreen(g: GameController) : BaseScreen(g) {
    private val bUp = btn("up", 800f, 100f, 60f, 50f, "", 1, ICON_UP)
    private val bDown = btn("down", 800f, 640f, 60f, 50f, "", 1, ICON_DOWN)
    private val bPlay = btn("play", 890f, 360f, 350f, 80f, "JUGAR")
    private val bSim = btn("sim", 890f, 460f, 350f, 70f, "SIMULAR", 1)
    private val bTrain = btn("train", 890f, 360f, 350f, 80f, "ENTRENAR")
    private val bBack = btn("back", 890f, 620f, 350f, 66f, "VOLVER", 1)
    private val rows = 9
    private var start = 0
    private var dates = emptyArray<String>(); private var descs = emptyArray<String>(); private var res = emptyArray<String>()
    private var types = emptyArray<EntryType>()
    private var idx = 0; private var total = 0
    private var nTitle = ""; private var nSub = ""; private var isMatch = false; private var over = false

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!
        total = s.calendar.size; idx = s.calendarIndex; over = s.seasonOver()
        dates = Array(total) { CareerDate.format(s.calendar[it].day) }
        types = Array(total) { s.calendar[it].type }
        descs = Array(total) { i ->
            val e = s.calendar[i]
            if (e.type == EntryType.TRAINING) "Entrenamiento" else {
                val f = s.fixtureOf(e)!!; val home = f.homeId == s.player.clubId
                "J${f.matchday + 1}  vs  " + s.clubById(if (home) f.awayId else f.homeId).name + (if (home) "  (L)" else "  (V)")
            }
        }
        res = Array(total) { i ->
            val e = s.calendar[i]; val f = s.fixtureOf(e)
            if (f != null && f.status == MatchStatus.PLAYED) "${f.homeGoals} - ${f.awayGoals}" else ""
        }
        start = (idx - 1).coerceIn(0, (total - rows).coerceAtLeast(0))
        isMatch = !over && types[idx] == EntryType.MATCH
        nTitle = if (over) "TEMPORADA COMPLETADA" else if (isMatch) descs[idx] else "ENTRENAMIENTO"
        nSub = if (over) "" else dates[idx]
        bPlay.visible = isMatch; bSim.visible = isMatch; bTrain.visible = !over && !isMatch
    }

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, 1280f, 720f, Palette.BG)
        ui.header(c, "CALENDARIO")
        ui.panel(c, 40f, 100f, 750f, 590f)
        for (i in 0 until rows) {
            val k = start + i
            if (k >= total) break
            val y = 112f + i * 64f
            if (k == idx) ui.panel(c, 50f, y, 730f, 58f, withAlpha(Palette.ACCENT, 40), Palette.ACCENT, 12f)
            val col = if (k < idx) Palette.TEXT_DIM else Palette.WHITE
            ui.text(c, dates[k], 70f, y + 38f, 26f, Palette.GOLD)
            ui.textFit(c, descs[k], 190f, y + 38f, 28f, 420f, col, Paint.Align.LEFT)
            ui.text(c, res[k], 760f, y + 38f, 28f, col, Paint.Align.RIGHT)
        }
        ui.panel(c, 880f, 100f, 360f, 240f)
        ui.text(c, "PRÓXIMO", 900f, 142f, 22f, Palette.ACCENT)
        ui.textFit(c, nTitle, 900f, 200f, 32f, 320f, Palette.WHITE, Paint.Align.LEFT)
        ui.text(c, nSub, 900f, 240f, 26f, Palette.TEXT_DIM)
        drawButtons(c)
    }

    override fun onButton(id: String) {
        when (id) {
            "up" -> start = (start - 1).coerceAtLeast(0)
            "down" -> start = (start + 1).coerceAtMost((total - rows).coerceAtLeast(0))
            "play" -> game.startMatch(MatchMode.PLAY)
            "sim" -> game.startMatch(MatchMode.SIMULATE)
            "train" -> { game.advanceTraining(); onEnter() }
            "back" -> game.go(GameState.CAREER)
        }
    }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** MATCH PREVIEW */
class MatchPreviewScreen(g: GameController) : BaseScreen(g) {
    private val bPlay = btn("play", 330f, 590f, 300f, 84f, "JUGAR")
    private val bSim = btn("sim", 650f, 590f, 300f, 84f, "SIMULAR", 1)
    private val bBack = btn("back", 40f, 600f, 220f, 64f, "VOLVER", 1)
    private var my: Club? = null; private var opp: Club? = null
    private var venue = ""; private var comp = ""; private var posTxt = ""; private var ovrTxt = ""; private var imp = false
    private var rivalTxt = ""; private var dateTxt = ""

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!
        val e = s.nextEntry(); val f = s.fixtureOf(e!!)!!
        val home = f.homeId == s.player.clubId
        my = s.club(); opp = s.clubById(if (home) f.awayId else f.homeId)
        venue = if (home) "LOCAL" else "VISITANTE"
        comp = "${s.competition}  ·  Jornada ${f.matchday + 1}"
        dateTxt = CareerDate.format(e.day)
        imp = f.importance == MatchImportance.IMPORTANT
        posTxt = s.player.position.label; ovrTxt = "OVR ${s.player.overall}"
        rivalTxt = "Fuerza rival ${opp!!.strength}  ·  Tu club ${my!!.strength}"
    }

    override fun draw(c: Canvas) {
        val a = my ?: return; val b = opp ?: return
        ui.fillRect(c, 0f, 0f, 1280f, 720f, Palette.BG)
        ui.header(c, "PREVIA DEL PARTIDO", dateTxt)
        ui.panel(c, 40f, 100f, 1200f, 330f)
        ui.badge(c, 300f, 250f, 90f, a.primary, a.secondary, a.abbr)
        ui.badge(c, 980f, 250f, 90f, b.primary, b.secondary, b.abbr)
        ui.text(c, "VS", 640f, 270f, 90f, Palette.GOLD, Paint.Align.CENTER)
        ui.textFit(c, a.name, 300f, 385f, 34f, 380f, Palette.WHITE, Paint.Align.CENTER)
        ui.textFit(c, b.name, 980f, 385f, 34f, 380f, Palette.WHITE, Paint.Align.CENTER)
        ui.text(c, venue, 640f, 330f, 30f, Palette.ACCENT, Paint.Align.CENTER)
        ui.panel(c, 40f, 450f, 1200f, 120f)
        ui.text(c, comp, 70f, 495f, 28f, Palette.WHITE)
        ui.text(c, rivalTxt, 70f, 535f, 24f, Palette.TEXT_DIM)
        ui.text(c, "$posTxt  ·  $ovrTxt", 1210f, 495f, 28f, Palette.GOLD, Paint.Align.RIGHT)
        if (imp) ui.text(c, "PARTIDO IMPORTANTE", 1210f, 535f, 24f, Palette.RED, Paint.Align.RIGHT)
        drawButtons(c)
    }

    override fun onButton(id: String) {
        when (id) {
            "play" -> game.startMatch(MatchMode.PLAY)
            "sim" -> game.startMatch(MatchMode.SIMULATE)
            "back" -> game.go(GameState.CAREER)
        }
    }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** FULL TIME */
class MatchResultScreen(g: GameController) : BaseScreen(g) {
    private val bCont = btn("cont", 340f, 620f, 280f, 76f, "CONTINUAR")
    private val bTable = btn("table", 660f, 620f, 280f, 76f, "TABLA", 1)
    private var hName = ""; private var aName = ""; private var hs = ""; private var aGoals = ""
    private var lines = emptyArray<String>(); private var rating = 0f; private var label = ""
    private var goals = emptyArray<String>()
    private var hc: Club? = null; private var ac: Club? = null

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!; val r = game.lastResult
        hc = s.clubById(r.homeId); ac = s.clubById(r.awayId)
        hName = hc!!.name; aName = ac!!.name; hs = r.homeGoals.toString(); aGoals = r.awayGoals.toString()
        val st = r.stats
        lines = arrayOf(
            "${r.playerMinutes} minutos", "${st.passesCompleted}/${st.passesAttempted} pases",
            "${st.dribblesCompleted}/${st.dribblesAttempted} regates", "${st.shots} tiros",
            "${st.goals} gol(es)", "${st.assists} asistencia(s)"
        )
        if (st.interceptions + st.clearances + st.crosses > 0)
            lines = lines + "${st.interceptions} interc. · ${st.clearances} despejes · ${st.crosses} centros"
        rating = r.rating; label = RatingLabel.of(r.rating)
        goals = r.events.filter { it.important && it.text.contains("GOL", true) || it.text.contains("marca", true) }.takeLast(5)
            .map { "${it.minute}'  ${it.text}" }.toTypedArray()
    }

    override fun draw(c: Canvas) {
        val h = hc ?: return; val a = ac ?: return
        ui.fillRect(c, 0f, 0f, 1280f, 720f, Palette.BG)
        ui.fillRect(c, 0f, 0f, 1280f, 90f, Palette.BG2)
        ui.fillRect(c, 0f, 88f, 1280f, 4f, Palette.GOLD)
        ui.text(c, "FULL TIME", 640f, 64f, 52f, Palette.GOLD, Paint.Align.CENTER)
        ui.panel(c, 40f, 110f, 560f, 250f)
        ui.badge(c, 100f, 170f, 30f, h.primary, h.secondary, h.abbr); ui.badge(c, 100f, 250f, 30f, a.primary, a.secondary, a.abbr)
        ui.textFit(c, hName, 150f, 182f, 34f, 330f, Palette.WHITE, Paint.Align.LEFT)
        ui.textFit(c, aName, 150f, 262f, 34f, 330f, Palette.WHITE, Paint.Align.LEFT)
        ui.text(c, hs, 560f, 184f, 56f, Palette.GOLD, Paint.Align.RIGHT)
        ui.text(c, aGoals, 560f, 264f, 56f, Palette.GOLD, Paint.Align.RIGHT)
        ui.panel(c, 40f, 380f, 560f, 220f)
        ui.text(c, "RESUMEN", 64f, 416f, 22f, Palette.ACCENT)
        for (i in goals.indices) ui.textFit(c, goals[i], 64f, 450f + i * 28f, 22f, 510f, Palette.WHITE, Paint.Align.LEFT)
        ui.panel(c, 630f, 110f, 610f, 340f)
        ui.text(c, "TU ACTUACIÓN", 660f, 150f, 26f, Palette.ACCENT)
        for (i in lines.indices) ui.text(c, lines[i], 660f, 196f + i * 36f, 28f, Palette.WHITE)
        ui.panel(c, 630f, 470f, 610f, 130f)
        val shown = rating * Ease.outCubic((time / 1.1f).coerceIn(0f, 1f))
        ui.text(c, "%.1f".format(shown), 800f, 570f, 96f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, "RATING", 1010f, 520f, 22f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, label, 1010f, 566f, 38f, Palette.WHITE, Paint.Align.CENTER)
        drawButtons(c)
    }

    override fun onButton(id: String) { game.go(if (id == "cont") GameState.CAREER else GameState.TABLE) }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** TABLE */
class TableScreen(g: GameController) : BaseScreen(g) {
    private val bBack = btn("back", 40f, 640f, 240f, 56f, "VOLVER", 1)
    private var rows = emptyArray<TableRow>(); private var names = emptyArray<String>(); private var mine = -1
    private var cells = emptyArray<Array<String>>()

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!
        rows = s.table.toTypedArray()
        names = Array(rows.size) { s.clubById(rows[it].clubId).name }
        mine = rows.indexOfFirst { it.clubId == s.player.clubId }
        cells = Array(rows.size) { i -> val r = rows[i]; arrayOf("${i + 1}", "${r.played}", "${r.won}", "${r.drawn}", "${r.lost}", "${r.gf}", "${r.ga}", "${r.points}") }
    }

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, 1280f, 720f, Palette.BG)
        ui.header(c, "CLASIFICACIÓN")
        ui.panel(c, 40f, 94f, 1200f, 530f)
        val heads = arrayOf("#", "PJ", "G", "E", "P", "GF", "GC", "PTS")
        val xs = floatArrayOf(80f, 700f, 780f, 860f, 940f, 1020f, 1100f, 1200f)
        for (j in heads.indices) ui.text(c, heads[j], xs[j], 126f, 22f, Palette.TEXT_DIM, if (j == 0) Paint.Align.LEFT else Paint.Align.CENTER)
        ui.text(c, "CLUB", 140f, 126f, 22f, Palette.TEXT_DIM)
        for (i in rows.indices) {
            val y = 140f + i * 48f
            if (i == mine) ui.panel(c, 50f, y, 1180f, 44f, withAlpha(Palette.ACCENT, 45), Palette.ACCENT, 10f)
            val col = if (i == mine) Palette.WHITE else 0xFFC9D6E8.toInt()
            ui.text(c, cells[i][0], xs[0], y + 32f, 26f, Palette.GOLD)
            ui.textFit(c, names[i], 140f, y + 32f, 28f, 480f, col, Paint.Align.LEFT)
            for (j in 1 until 8) ui.text(c, cells[i][j], xs[j], y + 32f, 26f, if (j == 7) Palette.GOLD else col, Paint.Align.CENTER)
        }
        drawButtons(c)
    }

    override fun onButton(id: String) { game.go(GameState.CAREER) }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}
