package com.goatjourney.core.match

import com.goatjourney.core.player.Position
import com.goatjourney.core.match.OpportunityType.*
import kotlin.math.*
import kotlin.random.Random

object Pitch {
    const val LENGTH = 105f
    const val WIDTH = 68f
    const val CENTER_Y = 34f
    const val GOAL_HALF = 3.66f
}

data class Vec(val x: Float, val y: Float) {
    operator fun plus(o: Vec) = Vec(x + o.x, y + o.y)
    operator fun minus(o: Vec) = Vec(x - o.x, y - o.y)
    operator fun times(k: Float) = Vec(x * k, y * k)
    fun len() = hypot(x, y)
    fun dist(o: Vec) = hypot(x - o.x, y - o.y)
}

object Geo {
    fun closest(p: Vec, a: Vec, b: Vec): Vec {
        val abx = b.x - a.x; val aby = b.y - a.y
        val l2 = abx * abx + aby * aby
        if (l2 < 1e-4f) return a
        val t = (((p.x - a.x) * abx + (p.y - a.y) * aby) / l2).coerceIn(0f, 1f)
        return Vec(a.x + abx * t, a.y + aby * t)
    }
    fun distToSegment(p: Vec, a: Vec, b: Vec): Float = p.dist(closest(p, a, b))
}

enum class MatchImportance { NORMAL, IMPORTANT }

/** maxLen = metros de arrastre para potencia 100%; range = metros que recorre la acción a potencia 100%. */
enum class OpportunityType(val label: String, val maxLen: Float, val range: Float, val hint: String) {
    PASS("PASE", 30f, 45f, "Arrastra desde el balón hacia un compañero"),
    SHOT("TIRO", 20f, 40f, "Arrastra hacia la portería"),
    DRIBBLE("REGATE", 8f, 10f, "Arrastra para superar al defensor"),
    CROSS("CENTRO", 25f, 40f, "Arrastra hacia el área"),
    INTERCEPTION("INTERCEPCIÓN", 8f, 12f, "Arrastra hacia la trayectoria del balón"),
    CLEARANCE("DESPEJE", 20f, 40f, "Arrastra para despejar lejos de tu portería")
}

class Target(val pos: Vec, val openness: Float)

/** Escena de una oportunidad en coordenadas de mundo (105x68 m, tu equipo ataca hacia x=105). */
class Opportunity(
    val type: OpportunityType,
    val minute: Int,
    val player: Vec,
    val ball: Vec,
    val teammates: List<Target>,
    val defenders: List<Vec>,
    val keeper: Vec?,
    val incomingFrom: Vec?,
    val incomingTo: Vec?,
    val pressure: Float,
    val quality: Float
)

/** Gesto traducido a metros de mundo (delta desde el punto de inicio). */
class Gesture(val dx: Float, val dy: Float) {
    val len: Float get() = hypot(dx, dy)
}

enum class ShotOutcome { NONE, GOAL, SAVED, BLOCKED, OFF_TARGET, POST }

class ActionResult(
    val type: OpportunityType,
    val success: Boolean,
    val quality: Float,
    val path: List<Vec>,
    val flightSeconds: Float,
    val headline: String,
    val detail: String = "",
    val targetReached: Boolean = false,
    val newPossession: Boolean = false,
    val chanceCreated: Boolean = false,
    val goal: Boolean = false,
    val turnover: Boolean = false,
    val foul: Boolean = false,
    val shotOutcome: ShotOutcome = ShotOutcome.NONE,
    val opponentChance: Boolean = false,
    val lofted: Boolean = false,
    val playerEnd: Vec? = null,
    val receiver: Vec? = null
) {
    var assist: Boolean = false
}

/** Decide cuándo el jugador participa y qué oportunidad aparece según su posición (nunca se bloquea ninguna). */
class OpportunitySystem(private val rng: Random) {
    private fun rf(a: Float, b: Float) = a + rng.nextFloat() * (b - a)

    fun involvementChance(p: Position): Float = when (p) {
        Position.CENTER_BACK -> 0.10f
        Position.FULL_BACK -> 0.12f
        Position.MIDFIELDER -> 0.15f
        Position.WINGER -> 0.13f
        Position.STRIKER -> 0.11f
    }

    fun attackShare(p: Position): Float = when (p) {
        Position.CENTER_BACK -> 0.35f
        Position.FULL_BACK -> 0.50f
        Position.MIDFIELDER -> 0.55f
        Position.WINGER -> 0.70f
        Position.STRIKER -> 0.85f
    }

    private val attackW: Map<Position, Map<OpportunityType, Int>> = mapOf(
        Position.CENTER_BACK to mapOf(PASS to 80, DRIBBLE to 8, CROSS to 4, SHOT to 8),
        Position.FULL_BACK to mapOf(PASS to 40, DRIBBLE to 20, CROSS to 30, SHOT to 10),
        Position.MIDFIELDER to mapOf(PASS to 40, DRIBBLE to 20, CROSS to 15, SHOT to 25),
        Position.WINGER to mapOf(PASS to 15, DRIBBLE to 35, CROSS to 25, SHOT to 25),
        Position.STRIKER to mapOf(PASS to 15, DRIBBLE to 15, CROSS to 3, SHOT to 67)
    )
    private val defendW: Map<Position, Map<OpportunityType, Int>> = mapOf(
        Position.CENTER_BACK to mapOf(INTERCEPTION to 40, CLEARANCE to 60),
        Position.FULL_BACK to mapOf(INTERCEPTION to 65, CLEARANCE to 35),
        Position.MIDFIELDER to mapOf(INTERCEPTION to 80, CLEARANCE to 20),
        Position.WINGER to mapOf(INTERCEPTION to 85, CLEARANCE to 15),
        Position.STRIKER to mapOf(INTERCEPTION to 90, CLEARANCE to 10)
    )

    fun pickType(pos: Position, attacking: Boolean): OpportunityType {
        val w = (if (attacking) attackW else defendW).getValue(pos)
        var r = rng.nextInt(w.values.sum())
        for ((k, v) in w) { if (r < v) return k; r -= v }
        return PASS
    }

    fun build(type: OpportunityType, minute: Int, pressure: Float): Opportunity = when (type) {
        PASS -> buildPass(minute, pressure)
        SHOT -> buildShot(minute, pressure, null)
        DRIBBLE -> buildDribble(minute, pressure)
        CROSS -> buildCross(minute, pressure)
        INTERCEPTION -> buildInterception(minute, pressure)
        CLEARANCE -> buildClearance(minute, pressure)
    }

    private fun openness(p: Vec, defs: List<Vec>): Float {
        var m = 99f
        for (d in defs) m = min(m, p.dist(d))
        return (m / 9f).coerceIn(0.05f, 1f)
    }

    private fun around(p: Vec, dMin: Float, dMax: Float): Vec {
        val a = rng.nextFloat() * 6.2832f
        val d = rf(dMin, dMax)
        return Vec(p.x + cos(a) * d, p.y + sin(a) * d)
    }

    private fun buildPass(minute: Int, pressure: Float): Opportunity {
        val b = Vec(rf(28f, 76f), rf(12f, 56f))
        val sign = if (b.y > 34f) -1f else 1f
        val t1 = Vec((b.x + rf(14f, 24f)).coerceAtMost(99f), (b.y + rf(-14f, 14f)).coerceIn(5f, 63f))
        val t2 = Vec((b.x + rf(4f, 13f)).coerceAtMost(99f), (b.y + sign * rf(14f, 22f)).coerceIn(5f, 63f))
        val t3 = Vec(b.x - rf(8f, 16f), (b.y + rf(-12f, 12f)).coerceIn(5f, 63f))
        val defs = ArrayList<Vec>()
        defs.add(Vec(b.x + rf(2.5f, 5f), b.y + rf(-4f, 4f)))
        defs.add(around(t1, 2f, 9f))
        defs.add(around(t2, 2f, 9f))
        val ts = listOf(t1, t2, t3).map { Target(it, openness(it, defs)) }
        return Opportunity(PASS, minute, b, b, ts, defs, null, null, null, pressure, 0.5f)
    }

    fun buildShotAt(pos: Vec, minute: Int, pressure: Float) = buildShot(minute, pressure, pos)

    private fun buildShot(minute: Int, pressure: Float, at: Vec?): Opportunity {
        val b = if (at != null) Vec(at.x.coerceIn(78f, 98f), at.y.coerceIn(16f, 52f)) else Vec(rf(80f, 96f), rf(18f, 50f))
        val dist = hypot(105f - b.x, 34f - b.y)
        val ang = abs(atan2(b.y - 34f, 105f - b.x))
        val quality = ((1f - (dist - 8f) / 26f).coerceIn(0.15f, 1f) * (1f - ang / 1.5708f * 0.5f)).coerceIn(0.1f, 1f)
        val defs = ArrayList<Vec>()
        defs.add(Vec(b.x + rf(2.5f, 6f), b.y + (34f - b.y) * 0.3f + rf(-3f, 3f)))
        if (rng.nextFloat() < 0.4f) defs.add(Vec(b.x + rf(4f, 8f), b.y + rf(-8f, 8f)))
        val keeper = Vec(103.6f, 34f + (b.y - 34f) * 0.12f)
        return Opportunity(SHOT, minute, b, b, emptyList(), defs, keeper, null, null, pressure, quality)
    }

    private fun buildDribble(minute: Int, pressure: Float): Opportunity {
        val b = Vec(rf(30f, 85f), rf(10f, 58f))
        val defs = ArrayList<Vec>()
        defs.add(Vec(b.x + rf(5f, 8f), b.y + rf(-2f, 2f)))
        if (rng.nextFloat() < 0.4f) defs.add(Vec(b.x + rf(9f, 13f), b.y + rf(-8f, 8f)))
        return Opportunity(DRIBBLE, minute, b, b, emptyList(), defs, null, null, null, pressure, 0.5f)
    }

    private fun buildCross(minute: Int, pressure: Float): Opportunity {
        val top = rng.nextBoolean()
        val b = Vec(rf(70f, 92f), if (top) rf(4f, 10f) else rf(58f, 64f))
        val pts = listOf(Vec(rf(93f, 100f), rf(27f, 41f)), Vec(rf(86f, 92f), rf(20f, 48f)), Vec(rf(97f, 102f), rf(30f, 38f)))
        val defs = ArrayList<Vec>()
        for (p in pts) defs.add(around(p, 1.5f, 8f))
        defs.add(Vec(b.x + rf(2.5f, 5f), b.y + if (top) 3f else -3f))
        val ts = pts.map { Target(it, openness(it, defs)) }
        return Opportunity(CROSS, minute, b, b, ts, defs, null, null, null, pressure, 0.5f)
    }

    private fun buildInterception(minute: Int, pressure: Float): Opportunity {
        val player = Vec(rf(25f, 75f), rf(14f, 54f))
        val m = Vec(player.x + rf(-2f, 2f), player.y + rf(-8f, 8f))
        val ang = PI.toFloat() + rf(-0.6f, 0.6f)
        val d = Vec(cos(ang), sin(ang))
        val a = m - d * 14f
        val b = m + d * 14f
        return Opportunity(INTERCEPTION, minute, player, a, emptyList(), listOf(a, b), null, a, b, pressure, 0.5f)
    }

    private fun buildClearance(minute: Int, pressure: Float): Opportunity {
        val p = Vec(rf(6f, 22f), rf(22f, 46f))
        val defs = listOf(Vec(p.x + rf(2f, 5f), p.y + rf(-5f, 5f)), Vec(p.x + rf(3f, 8f), p.y + rf(-9f, 9f)))
        return Opportunity(CLEARANCE, minute, p, p, emptyList(), defs, null, null, null, pressure, 0.5f)
    }
}
