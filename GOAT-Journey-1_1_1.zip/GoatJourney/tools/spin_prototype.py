import math
G=9.8; AIR=0.10; ROLL=0.55; BOUNCE=0.55; DT=1/30
R=0.11; K=0.5*1.2*0.038/0.43
CL_MAX=0.30; S0=0.30; SPIN_DECAY=0.35; EFF=0.30; WMAX=100.0

def cross(a,b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def add(*vs): return tuple(sum(c) for c in zip(*vs))
def mul(a,k): return tuple(x*k for x in a)

def spin_for(nx, ny, dirw, elev, speed, scale=1.0):
    """dirw = world dir (x toward goal, y width). returns omega in P-frame (Px=world y, Py=world x, Pz=up)"""
    ny_eff = ny*0.45
    d = math.sqrt(max(0,1-nx*nx-ny*ny))
    r = (nx,-d,ny_eff)
    F = (0,1,0)
    tq = cross(r,F)                 # (-ny, 0, nx)
    k = 1.5*EFF*speed/R*scale
    wl = mul(tq,k)
    n = math.hypot(*dirw); hx,hy = dirw[1]/n, dirw[0]/n   # P horizontal fwd
    ce,se = math.cos(elev), math.sin(elev)
    f3 = (ce*hx, ce*hy, se)
    u3 = (hy,-hx,0)
    w3 = cross(u3,f3)
    w = add(mul(u3,wl[0]), mul(f3,wl[1]), mul(w3,wl[2]))
    m = math.sqrt(sum(c*c for c in w))
    if m>WMAX: w = mul(w,WMAX/m)
    return w

def simulate(x,y,z,dirw,speed,elev,spin,maxT=4.0):
    n=math.hypot(*dirw); dx,dy=dirw[0]/n,dirw[1]/n
    hs=speed*math.cos(elev)
    vx,vy,vz=dx*hs,dy*hs,speed*math.sin(elev)
    wx,wy,wz=spin
    t=0; out=[(0,x,y,z)]; bounces=0
    roll=math.exp(-ROLL*DT)
    while t<maxT:
        t+=DT
        air = z>0.03 or vz>0.5
        v2=vx*vx+vy*vy+vz*vz
        w=math.sqrt(wx*wx+wy*wy+wz*wz)
        if air and w>0.5 and v2>1:
            v=math.sqrt(v2)
            vP=(vy,vx,vz)
            c=cross((wx,wy,wz),vP)
            S=w*R/v
            cl=CL_MAX*(1-math.exp(-S/S0))
            f=K*cl*v2/(w*v)
            aPx,aPy,aPz=c[0]*f,c[1]*f,c[2]*f
            vy+=aPx*DT; vx+=aPy*DT; vz+=aPz*DT
            dec=math.exp(-SPIN_DECAY*DT); wx*=dec;wy*=dec;wz*=dec
        if air:
            vz-=G*DT; f=1-AIR*DT; vx*=f;vy*=f; z+=vz*DT
            if z<=0:
                z=0
                if abs(vz)>1.5:
                    # ground interaction with spin
                    ux=vy-wy*R; uy=vx+wx*R   # P-frame slip (Px=vy, Py=vx)
                    k=0.25
                    dvx=-k*ux; dvy=-k*uy       # in P
                    vy+=dvx; vx+=dvy
                    wx+=1.5/R*dvy; wy+=-1.5/R*dvx
                    wx*=0.6;wy*=0.6;wz*=0.6
                    vz=-vz*BOUNCE; vx*=0.85; vy*=0.85; bounces+=1
                else: vz=0
        else:
            vx*=roll; vy*=roll; z=0; vz=0
            dec=math.exp(-3*DT); wx*=dec;wy*=dec;wz*=dec
        x+=vx*DT;y+=vy*DT
        out.append((t,x,y,z))
        if x>105 or x<0 or y<0 or y>68: break
        if not(z>0.03 or vz>0.5) and math.hypot(vx,vy)<0.6: break
    return out

def run(angle_deg,nx,ny,speed=26,elev=0.05,**kw):
    a=math.radians(angle_deg)
    dirw=(math.cos(a),math.sin(a))      # angle from world +x toward +y
    sp=spin_for(nx,ny,dirw,elev,speed)
    tr=simulate(30,34,0.15,dirw,speed,elev,sp)
    return tr,dirw

def lateral_dev(tr,dirw):
    # signed distance from straight line; positive = to the RIGHT of travel (right = (-dy? ) world: right=(-dirw[1], dirw[0]))
    x0,y0=tr[0][1],tr[0][2]
    right=(-dirw[1],dirw[0])
    out=[]
    for t,x,y,z in tr:
        out.append(((x-x0)*right[0]+(y-y0)*right[1], (x-x0)*dirw[0]+(y-y0)*dirw[1], z, t))
    return out

if __name__=="__main__":
    print("== lateral deviation (m, +right of travel) at t=1.0 s, shot speed 26, elev .05")
    for ang in (0,30,-40,90):
        for nx in (-0.8,-0.4,0,0.4,0.8):
            tr,dirw=run(ang,nx,0)
            ld=lateral_dev(tr,dirw)
            p=[q for q in ld if q[3]>=1.0]
            q=p[0] if p else ld[-1]
            print(f"dir {ang:4d}deg nx {nx:+.1f} -> lateral {q[0]:+6.2f} m  forward {q[1]:6.2f} m  (t={q[3]:.2f})")
        print()
    print("== vertical contact (dir 0, nx 0)")
    for ny in (-1,-0.6,-0.3,0,0.3,0.6,1):
        el=0.05+ (0.55*(-ny) if ny<0 else ny*(-0.9)*0.1)
        el=max(0,min(0.9,el))
        sp=spin_for(0,ny,(1,0),el,26)
        tr=simulate(30,34,0.15,(1,0),26*(1+0.1*max(0,ny)),el,sp)
        zmax=max(q[3] for q in tr); xl=tr[-1][1]
        t_land=[q for q in tr if q[3]<=0.01 and q[0]>0.05]
        print(f"ny {ny:+.1f} elev {el:.2f} zmax {zmax:5.2f} m  range-first-ground {t_land[0][1]-30 if t_land else None}")
    print("== pass speed 14 nx .7")
    tr,dirw=run(0,0.7,0,speed=14,elev=0.0)
    ld=lateral_dev(tr,dirw); print([ (round(a,2),round(b,1)) for a,b,c,d in ld[::6]])
