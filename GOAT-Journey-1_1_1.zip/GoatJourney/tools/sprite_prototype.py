import math
from PIL import Image

def rgb(c): return ((c>>16)&255,(c>>8)&255,c&255)
def pack(r,g,b): return 0xFF000000|(int(max(0,min(255,r)))<<16)|(int(max(0,min(255,g)))<<8)|int(max(0,min(255,b)))
def shade(c,f):
    r,g,b=rgb(c); return pack(r*f,g*f,b*f)
def mixc(a,b,t):
    ra,ga,ba=rgb(a); rb,gb,bb=rgb(b); return pack(ra+(rb-ra)*t,ga+(gb-ga)*t,ba+(bb-ba)*t)
def tones(c):  # highlight, base, shadow, deep
    return (mixc(c,0xFFFFFFFF,0.20), c, mixc(shade(c,0.72),0xFF1A1030,0.10), mixc(shade(c,0.50),0xFF140C28,0.20))

OUT_C=0xFF120E1C

class Buf:
    def __init__(s,W,H):
        s.W=W;s.H=H;s.c=[0]*(W*H);s.g=[0]*(W*H)
    def get(s,x,y):
        if 0<=x<s.W and 0<=y<s.H: return s.c[y*s.W+x]
        return 0
    def put(s,x,y,col,grp=0):
        if 0<=x<s.W and 0<=y<s.H:
            s.c[y*s.W+x]=col; s.g[y*s.W+x]=grp
    def grp(s,x,y):
        if 0<=x<s.W and 0<=y<s.H: return s.g[y*s.W+x]
        return -1

def capsule(b,ax,ay,bx,by,ra,rb,col,grp,lit=True,sep=True):
    """thick tapered line; 3-tone shading, light from upper-left; sep = dark separation line over other groups"""
    T=tones(col)
    x0=int(math.floor(min(ax,bx)-max(ra,rb)-2)); x1=int(math.ceil(max(ax,bx)+max(ra,rb)+2))
    y0=int(math.floor(min(ay,by)-max(ra,rb)-2)); y1=int(math.ceil(max(ay,by)+max(ra,rb)+2))
    dx=bx-ax; dy=by-ay; L2=dx*dx+dy*dy
    cells=[]
    for y in range(y0,y1+1):
        for x in range(x0,x1+1):
            px=x+0.5; py=y+0.5
            t=0 if L2<1e-6 else max(0,min(1,((px-ax)*dx+(py-ay)*dy)/L2))
            qx=ax+dx*t; qy=ay+dy*t
            r=ra+(rb-ra)*t
            d=math.hypot(px-qx,py-qy)
            cells.append((x,y,d,r,px-qx,py-qy))
    for x,y,d,r,ox,oy in cells:
        if d<=r:
            s=(ox*-0.7+oy*-0.7)/max(r,0.5)
            if not lit: c=T[1]
            elif s>0.38: c=T[0]
            elif s<-0.30: c=T[2]
            else: c=T[1]
            b.put(x,y,c,grp)
    if sep:
        for x,y,d,r,ox,oy in cells:
            if r<d<=r+0.95:
                g=b.grp(x,y)
                if b.get(x,y)!=0 and g!=grp and g!=-1:
                    b.put(x,y,shade(b.get(x,y),0.55),g)

def poly(b,pts,col,grp,shader=None):
    T=tones(col)
    xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
    for y in range(int(math.floor(min(ys))),int(math.ceil(max(ys)))+1):
        for x in range(int(math.floor(min(xs))),int(math.ceil(max(xs)))+1):
            px=x+0.5;py=y+0.5
            inside=False; n=len(pts); j=n-1
            for i in range(n):
                xi,yi=pts[i];xj,yj=pts[j]
                if ((yi>py)!=(yj>py)) and (px<(xj-xi)*(py-yi)/(yj-yi+1e-9)+xi): inside=not inside
                j=i
            if inside:
                c=T[1] if shader is None else shader(x,y,T)
                b.put(x,y,c,grp)

def ellipse(b,cx,cy,rx,ry,col,grp,lit=True):
    T=tones(col)
    for y in range(int(cy-ry-2),int(cy+ry+3)):
        for x in range(int(cx-rx-2),int(cx+rx+3)):
            px=x+0.5-cx;py=y+0.5-cy
            d=(px/rx)**2+(py/ry)**2
            if d<=1:
                s=(px/rx*-0.7+py/ry*-0.7)
                c=T[1]
                if lit:
                    if s>0.55: c=T[0]
                    elif s<-0.45: c=T[2]
                b.put(x,y,c,grp)

# ------------------------------------------------------------------ POSE
class Pose:
    def __init__(s,**k):
        s.lean=0.0      # torso lean forward (rad)
        s.twist=0.0
        s.thL=0.0; s.thR=0.0     # thigh swing fwd (rad)
        s.flL=0.0; s.flR=0.0     # knee flex (rad)
        s.abL=0.0; s.abR=0.0     # leg abduction
        s.arL=0.0; s.arR=0.0     # upper arm swing fwd
        s.abaL=0.15; s.abaR=0.15 # arm abduction
        s.elL=0.3; s.elR=0.3     # elbow flex fwd
        s.crouch=0.0; s.lift=0.0 # whole body drop / jump
        s.headTilt=0.0; s.mouth=0
        s.pitch=0.0              # whole-body pitch (horizontal poses)
        s.__dict__.update(k)

def run_pose(p,amp=0.75,arm=0.7,lean=0.12,flex=1.0):
    a=2*math.pi*p
    thL=amp*math.sin(a); thR=amp*math.sin(a+math.pi)
    def fl(th_phase): # knee flex bigger when leg is swinging forward from behind
        return 0.25+flex*max(0,math.cos(th_phase))*0.9
    return Pose(lean=lean,thL=thL,thR=thR,flL=fl(a),flR=fl(a+math.pi),
                arL=-arm*math.sin(a),arR=-arm*math.sin(a+math.pi),elL=0.9,elR=0.9,abaL=0.12,abaR=0.12,
                lift=0.012*abs(math.sin(a*2)))

POSES={}
POSES['idle']=Pose(thL=0.03,thR=-0.03,arL=0.05,arR=-0.05,flL=0.04,flR=0.04)
POSES['idle2']=Pose(thL=0.03,thR=-0.03,arL=0.05,arR=-0.05,flL=0.04,flR=0.04,crouch=0.006,abaL=0.2,abaR=0.2)
POSES['kick_wind']=Pose(lean=-0.10,thL=0.1,thR=-0.85,flL=0.12,flR=1.35,arL=0.7,arR=-0.5,elL=0.5,elR=0.5,abaL=0.6,abaR=0.35)
POSES['kick_strike']=Pose(lean=0.05,thL=-0.1,thR=0.75,flL=0.30,flR=0.12,arL=-0.6,arR=0.55,elL=0.4,elR=0.5,abaL=0.5,abaR=0.4,crouch=0.015)
POSES['kick_follow']=Pose(lean=-0.10,thL=-0.05,thR=1.20,flL=0.20,flR=0.35,arL=-0.7,arR=0.8,elL=0.5,elR=0.5,abaL=0.7,abaR=0.5,lift=0.02)
POSES['celebrate']=Pose(lean=-0.05,thL=0.15,thR=-0.12,flL=0.5,flR=0.5,arL=2.9,arR=2.9,elL=0.15,elR=0.15,abaL=0.35,abaR=0.35,lift=0.06,mouth=2)
POSES['celebrate2']=Pose(lean=-0.03,thL=0.05,thR=-0.05,flL=0.2,flR=0.2,arL=2.7,arR=2.7,elL=0.3,elR=0.3,abaL=0.55,abaR=0.55,lift=0.0,mouth=2)
POSES['slump']=Pose(lean=0.22,thL=0.05,thR=-0.05,flL=0.08,flR=0.08,arL=1.9,arR=1.9,elL=2.0,elR=2.0,abaL=0.2,abaR=0.2,headTilt=0.25)
POSES['protest']=Pose(lean=0.0,thL=0.04,thR=-0.04,flL=0.05,flR=0.05,arL=0.6,arR=0.6,elL=1.1,elR=1.1,abaL=0.9,abaR=0.9,mouth=2)
POSES['header']=Pose(lean=0.30,thL=0.7,thR=-0.2,flL=1.0,flR=0.7,arL=0.9,arR=-0.6,elL=0.5,elR=0.5,abaL=0.8,abaR=0.8,lift=0.09)
POSES['keeper']=Pose(lean=0.12,thL=0.35,thR=0.35,flL=0.7,flR=0.7,arL=0.5,arR=0.5,elL=0.7,elR=0.7,abaL=0.9,abaR=0.9,crouch=0.03,abL=0.18,abR=0.18)
POSES['dive']=Pose(lean=1.2,thL=-0.4,thR=-0.7,flL=0.2,flR=0.3,arL=2.8,arR=2.6,elL=0.1,elR=0.2,abaL=0.2,abaR=0.2,lift=0.1,pitch=0.0)

# ------------------------------------------------------------------ LOOK
class Look:
    def __init__(s,**k):
        s.skin=0xFFEAB98C; s.hair=0xFF1A1208; s.hairStyle=0; s.beard=0; s.brow=1
        s.build=1; s.heightF=1.0; s.jaw=1; s.age=0
        s.shirt=0xFF1E88E5; s.shirt2=0xFFFFFFFF; s.pattern=0; s.shorts=0xFFFFFFFF; s.shorts2=0xFF1E88E5
        s.socks=0xFF1E88E5; s.socks2=0xFFFFFFFF; s.boots=0xFF15151C; s.number=9; s.keeper=False; s.glove=0xFFFFD24A
        s.sleeves=0  # 0 short 1 long
        s.__dict__.update(k)

# 3x5 digits
DIG={'0':["111","101","101","101","111"],'1':["010","110","010","010","111"],'2':["111","001","111","100","111"],
 '3':["111","001","111","001","111"],'4':["101","101","111","001","001"],'5':["111","100","111","001","111"],
 '6':["111","100","111","101","111"],'7':["111","001","010","010","010"],'8':["111","101","111","101","111"],'9':["111","101","111","001","111"]}

def render(look,view,pose,H):
    """view: 'F','B','S' (S faces right). returns (W,H,list of ARGB)"""
    W=int(round(H*0.86))//2*2+2
    b=Buf(W,H)
    cx=W/2.0
    S=H*0.94 *look.heightF    # body units -> px (head top at 0.985*S)
    ground=H-1.5
    bw={0:0.90,1:1.0,2:1.12,3:1.14}[look.build]
    sw=0.118*bw; hw=0.062*(0.95+0.05*bw); 
    Lthigh=0.245; Lshin=0.235; Lft=0.085; Lua=0.150; Lfa=0.140; Ltorso=0.295
    hipY=0.515-pose.crouch
    # ---------- 3D skeleton (x right-of-character, y up, z forward)
    def rot_fwd(vx,vy,vz,ang):  # rotate around x axis (forward lean): y->z
        return (vx, vy*math.cos(ang)-vz*math.sin(ang)*0, vy*math.sin(ang)+vz*math.cos(ang)) 
    P0=(0.0,hipY+pose.lift,0.0)
    pl=pose.pitch
    lean=pose.lean
    # torso top
    S3=(0.0,P0[1]+Ltorso*math.cos(lean),P0[2]+Ltorso*math.sin(lean))
    def leg(side,th,fl,ab):
        hx=side*hw*1.05
        hip=(hx,P0[1],P0[2])
        k=(hx+side*math.sin(ab)*Lthigh, hip[1]-Lthigh*math.cos(th)*math.cos(ab), hip[2]+Lthigh*math.sin(th))
        th2=th-fl
        a=(k[0]+side*math.sin(ab*0.6)*Lshin, k[1]-Lshin*math.cos(th2), k[2]+Lshin*math.sin(th2))
        return hip,k,a,th2
    legs={}
    for side,th,fl,ab,nm in ((1,pose.thR,pose.flR,pose.abR,'R'),(-1,pose.thL,pose.flL,pose.abL,'L')):
        legs[nm]=leg(side,th,fl,ab)
    # ground contact: lowest ankle at ankle height
    low=min(legs['R'][2][1],legs['L'][2][1])
    shift=0.035-low if pose.lift<0.001 else 0.0
    if pose.lift>=0.001: shift=0.035-low if low<0.035 else 0.0
    def sh(p): return (p[0],p[1]+shift,p[2])
    P0=sh(P0); S3=sh(S3)
    arms={}
    for side,ar,el,ab,nm in ((1,pose.arR,pose.elR,pose.abaR,'R'),(-1,pose.arL,pose.elL,pose.abaL,'L')):
        shp=(side*sw,S3[1]-0.025*math.cos(lean),S3[2]-0.025*math.sin(lean)*0)
        e=(shp[0]+side*math.sin(ab)*Lua, shp[1]-Lua*math.cos(ar), shp[2]+Lua*math.sin(ar))
        ar2=ar+el
        h=(e[0]+side*math.sin(ab*0.5)*Lfa, e[1]-Lfa*math.cos(ar2), e[2]+Lfa*math.sin(ar2))
        arms[nm]=(shp,e,h)
    headC=(0.0,S3[1]+0.014+0.066, S3[2]+0.012*math.sin(lean)+0.02*math.sin(lean))
    # ---------- projection
    def proj(p):
        x,y,z=p
        if view=='F':
            sx=cx-x*S; sy=ground-(y)*S+z*S*0.18
        elif view=='B':
            sx=cx+x*S; sy=ground-(y)*S-z*S*0.18
        else:
            sx=cx+z*S; sy=ground-(y)*S
        return (sx,sy)
    def depth(p):
        if view=='F': return p[2]
        if view=='B': return -p[2]
        return p[0]
    # ---------- collect primitives with depth keys then draw
    prims=[]
    skin=look.skin
    shirt=look.shirt; sh2=look.shirt2
    kcol=look.shirt if not look.keeper else look.shirt
    rLeg=0.052*bw; rKnee=0.040; rAnk=0.028
    def add(key,fn): prims.append((key,fn))
    # legs
    for nm in ('L','R'):
        hip,k,a,th2=legs[nm]
        hip=sh(hip);k=sh(k);a=sh(a)
        side=1 if nm=='R' else -1
        # foot
        fl_ang= -0.15 + 0.5*max(0,th2*0.0)
        toe=(a[0],a[1]-0.020,a[2]+Lft*math.cos(0.1))
        def mk(hip=hip,k=k,a=a,toe=toe,nm=nm):
            def f():
                ph=proj(hip);pk=proj(k);pa=proj(a);pt=proj(toe)
                # thigh (skin) then shorts overlay
                capsule(b,ph[0],ph[1],pk[0],pk[1],rLeg*S,rKnee*S,skin,10 if nm=='L' else 11)
                # shorts thigh part (to 62% length)
                qx=ph[0]+(pk[0]-ph[0])*0.60; qy=ph[1]+(pk[1]-ph[1])*0.60
                capsule(b,ph[0],ph[1]-0.01*S,qx,qy,rLeg*S*1.12,rLeg*S*0.98,look.shorts,12 if nm=='L' else 13,sep=False)
                # sock shin
                capsule(b,pk[0],pk[1],pa[0],pa[1],rKnee*S*0.98,rAnk*S*1.1,look.socks,14 if nm=='L' else 15)
                # sock band
                bx=pk[0]+(pa[0]-pk[0])*0.30; by=pk[1]+(pa[1]-pk[1])*0.30
                capsule(b,pk[0],pk[1]+0.5,bx,by,rKnee*S*1.0,rKnee*S*0.98,look.socks2,14,lit=False,sep=False)
                # boot
                capsule(b,pa[0],pa[1]-0.01*S,pt[0],pt[1],0.032*S,0.026*S,look.boots,16 if nm=='L' else 17)
            return f
        add(depth(((a[0]+k[0])/2,0,(a[2]+k[2])/2)) if view!='S' else (side*0.5), mk())
    # arms
    for nm in ('L','R'):
        shp,e,h=arms[nm]
        shp=sh(shp);e=sh(e);h=sh(h)
        side=1 if nm=='R' else -1
        def mk(shp=shp,e=e,h=h,nm=nm):
            def f():
                ps=proj(shp);pe=proj(e);ph=proj(h)
                longs=look.sleeves==1 or look.keeper
                capsule(b,pe[0],pe[1],ph[0],ph[1],0.030*S*bw**0.5,0.026*S,(shirt if longs else skin),20 if nm=='L' else 21)
                capsule(b,ps[0],ps[1],pe[0],pe[1],0.034*S*bw**0.6,0.030*S*bw**0.5,shirt,22 if nm=='L' else 23)
                # cuff
                qx=ps[0]+(pe[0]-ps[0])*0.90; qy=ps[1]+(pe[1]-ps[1])*0.90
                capsule(b,qx,qy,pe[0],pe[1],0.030*S,0.029*S,sh2,22 if nm=='L' else 23,lit=False,sep=False)
                # hand
                gc=look.glove if look.keeper else skin
                capsule(b,ph[0],ph[1],ph[0]+(ph[0]-pe[0])*0.25,ph[1]+(ph[1]-pe[1])*0.25+0.5,0.026*S,0.022*S,gc,24 if nm=='L' else 25)
            return f
        add(depth(((shp[0]),0,(h[2]))) if view!='S' else (side*0.9), mk())
    # torso
    def torso():
        ps=proj(S3); p0=proj(P0)
        shL=proj((-sw,S3[1]-0.02,S3[2])); shR=proj((sw,S3[1]-0.02,S3[2]))
        wL=proj((-0.082*bw,P0[1]+0.05,P0[2]+0.05*math.sin(lean))); wR=proj((0.082*bw,P0[1]+0.05,P0[2]+0.05*math.sin(lean)))
        if view=='S':
            tw=0.075*bw
            shL=(ps[0]-tw*S,ps[1]+0.02*S); shR=(ps[0]+tw*S,ps[1]+0.02*S)
            wL=(p0[0]-0.062*bw*S,p0[1]-0.04*S); wR=(p0[0]+0.062*bw*S,p0[1]-0.04*S)
        nkw=0.046*S
        pts=[(shL[0]-0.5,shL[1]+0.012*S),(ps[0]-nkw,shL[1]-1.8),(ps[0]+nkw,shL[1]-1.8),(shR[0]+0.5,shR[1]+0.012*S),(wR[0]+0.4,wR[1]+0.5),(wL[0]-0.4,wL[1]+0.5)]
        tl=min(p[0] for p in pts); tr=max(p[0] for p in pts); tt=min(p[1] for p in pts); tb=max(p[1] for p in pts)
        def shader(x,y,T):
            u=(x+0.5-tl)/max(1,tr-tl); v=(y+0.5-tt)/max(1,tb-tt)
            c=T[1]
            base=shirt
            pat=look.pattern
            alt=False
            if pat==1: alt=int(v*(tb-tt)/ (max(2,S*0.04)))%2==1
            elif pat==2: alt=int(u*(tr-tl)/(max(2,S*0.05)))%2==1
            elif pat==3: alt=u>0.5
            elif pat==4: alt=abs((u-0.5)*1.0-(v-0.5)*0.9)<0.14
            elif pat==5: alt=0.30<v<0.46
            col=sh2 if alt else base
            TT=tones(col)
            if view=='S':
                if u>0.78: return TT[2]
                if u<0.2: return TT[0]
            else:
                if u<0.2: return TT[0]
                if u>0.8: return TT[2]
            if v>0.88: return TT[2]
            return TT[1]
        poly(b,pts,shirt,30,shader)
        # side / trunk smoothing: belt line & neck
        # collar
        nk=proj((0,S3[1]+0.012,S3[2]))
        if view=='F':
            for dx in (-2,-1,0,1,2):
                b.put(int(nk[0]+dx),int(shL[1]+0),sh2 if not look.keeper else sh2,30)
            b.put(int(nk[0]),int(shL[1]+1),sh2,30)
        # shorts hip block
        hb=proj((0,P0[1]+0.015,P0[2]))
        hwid=0.080*bw*S
        poly(b,[(hb[0]-hwid,hb[1]-0.05*S),(hb[0]+hwid,hb[1]-0.05*S),(hb[0]+hwid*1.06,hb[1]+0.045*S),(hb[0]-hwid*1.06,hb[1]+0.045*S)],look.shorts,31)
        # shorts side stripe
        if view!='S':
            for yy in range(int(hb[1]-0.04*S),int(hb[1]+0.04*S)):
                b.put(int(hb[0]-hwid*1.0),yy,look.shorts2,31); b.put(int(hb[0]+hwid*1.0-1),yy,look.shorts2,31)
        # chest details
        if view=='F' and H>=36:
            cxp=int(cx-0.5+ (shR[0]-shL[0])*0.0)
            c_x=int((shL[0]+shR[0])/2 - (shR[0]-shL[0])*0.22); c_y=int(shL[1]+S*0.07)
            b.put(c_x,c_y,sh2,30); b.put(c_x+1,c_y,sh2,30); b.put(c_x,c_y+1,sh2,30); b.put(c_x+1,c_y+1,mixc(sh2,shirt,0.3),30)  # crest
            # sponsor band
            if H>=40:
                sy=int(shL[1]+S*0.13)
                for xx in range(int((shL[0]+shR[0])/2-S*0.07),int((shL[0]+shR[0])/2+S*0.07)):
                    b.put(xx,sy,0xFFF2F2F2 if sh2!=0xFFF2F2F2 else 0xFF222222,30)
        if view=='B' and H>=40:
            s=str(look.number)
            ox=int((shL[0]+shR[0])/2 - (len(s)*4-1)/2)
            oy=int(shL[1]+S*0.07)
            ncol=sh2 if abs(sum(rgb(sh2))-sum(rgb(shirt)))>150 else (0xFFFFFFFF if sum(rgb(shirt))<380 else 0xFF111111)
            for i,chh in enumerate(s):
                for ry,row in enumerate(DIG[chh]):
                    for rx,v in enumerate(row):
                        if v=='1': b.put(ox+i*4+rx,oy+ry,ncol,30)
    add(0.0 if view!='S' else 0.0, torso)
    # neck + head
    def head():
        pn=proj((0,S3[1]+0.01,S3[2]+0.004))
        capsule(b,pn[0],pn[1]+0.01*S,pn[0],pn[1]-0.03*S,0.030*S*bw**0.5,0.028*S,skin,40,sep=False)
        hc=proj(headC)
        hcx=hc[0]+pose.headTilt*S*0.03*(1 if view!='B' else 1); hcy=hc[1]+pose.headTilt*S*0.03
        hh=0.134*S; hwd=(0.064+0.004*look.jaw)*S
        if view=='S': hwd=0.066*S
        ellipse(b,hcx,hcy,hwd,hh*0.52,skin,41)
        draw_face(b,look,view,hcx,hcy,hwd,hh*0.52,H,S,pose)
    add(0.2 if view!='S' else 0.05, head)
    prims.sort(key=lambda t:t[0])
    for k,f in prims: f()
    # outline
    out=Buf(W,H)
    for i in range(W*H): out.c[i]=b.c[i]; out.g[i]=b.g[i]
    for y in range(H):
        for x in range(W):
            if b.get(x,y)==0:
                for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    n=b.get(x+dx,y+dy)
                    if n!=0:
                        out.c[y*W+x]=OUT_C; break
    # ground shadow handled by caller
    img=out.c
    if view=='S':
        pass
    return W,H,img

# ------------------------------------------------------------------ FACE / HAIR
def draw_face(b,look,view,cx,cy,rx,ry,H,S,pose):
    skin=look.skin; hair=look.hair
    ST=tones(skin); HT=tones(hair)
    def pxr(u,v,col,grp=42):
        # u,v in head-normalised coordinates (-1..1)
        b.put(int(math.floor(cx+u*rx)),int(math.floor(cy+v*ry)),col,grp)
    def inhead(u,v): return u*u+v*v<=1.0
    style=look.hairStyle
    x0=int(cx-rx*1.6);x1=int(cx+rx*1.6);y0=int(cy-ry*1.9);y1=int(cy+ry*2.0)
    def hair_at(x,y):
        u=(x+0.5-cx)/rx; v=(y+0.5-cy)/ry
        if view=='S': 
            u2=u  # facing right: +u = front
        else: u2=u
        r=math.hypot(u,v)
        if style==0:   # corto
            if view=='F': return (r<1.12 and v<-0.46+0.30*u*u) or (r<1.12 and v<0.20 and abs(u)>0.90)
            if view=='B': return r<1.12 and v<0.35
            return r<1.12 and (v<-0.25 or (u<0.1 and v<0.30))
        if style==1:   # plano (flat top)
            if view=='F': return (abs(u)<1.02 and -1.28<v<-0.38) or (r<1.1 and v<-0.3) or (r<1.1 and v<0.25 and abs(u)>0.9)
            if view=='B': return (abs(u)<1.02 and -1.28<v<0.1) or (r<1.1 and v<0.35)
            return (-1.0<u<1.0 and -1.28<v<-0.3) or (u<0.15 and r<1.1 and v<0.3)
        if style==2:   # largo
            if view=='F': return (r<1.14 and v<-0.28) or (0.78<abs(u)<1.28 and -0.6<v<1.9) 
            if view=='B': return (abs(u)<1.28 and -1.1<v<1.9 and (r<1.15 or v>0.0))
            return (r<1.14 and v<-0.2) or (-1.35<u<0.35 and -0.6<v<1.8)
        if style==3:   # rapado
            return False
        if style==4:   # rizado
            return r<1.42 and (v<0.0 or abs(u)>1.0) and not (view=='F' and r<0.95 and v>-0.38)
        if style==5:   # trenzas
            if view=='F': return (r<1.12 and v<-0.35) or (abs(u)>0.55 and v<1.1 and r<1.35 and int((u+2)*3)%2==0)
            return (r<1.12 and v<0.2) or (v<1.5 and abs(u)<1.2 and int((u+2)*3)%2==0 and v>-0.3)
        if style==6:   # moño
            if r<1.10 and v<-0.28: return True
            if math.hypot(u-(0 if view!='S' else -0.35),v+1.18)<0.52: return True
            return view=='B' and r<1.1 and v<0.3
        if style==7:   # calvo con laterales
            return (r<1.08 and v>-0.1 and v<0.4 and abs(u)>0.80) or (view=='B' and r<1.08 and 0.0<v<0.5)
        if style==8:   # mohicano / fade
            if abs(u)<0.30 and -1.35<v<0.3: return True
            return False
        if style==9:   # peinado atrás
            if view=='F': return r<1.12 and v<-0.42
            if view=='B': return r<1.12 and v<0.45
            return (r<1.14 and v<-0.3) or (-1.3<u<0.1 and v<0.55)
        return False
    # stubble / buzz: slightly darker skin on scalp
    for y in range(y0,y1+1):
        for x in range(x0,x1+1):
            if hair_at(x,y):
                u=(x+0.5-cx)/rx; v=(y+0.5-cy)/ry
                c=HT[1]
                if (v<-0.6 and u<0.1) : c=HT[0]
                elif u>0.55 or v>0.2: c=HT[2]
                # texture
                if (x*7+y*13)%11==0: c=HT[3] if c!=HT[3] else c
                b.put(x,y,c,43)
    if style==3:
        for y in range(y0,y1+1):
            for x in range(x0,x1+1):
                u=(x+0.5-cx)/rx; v=(y+0.5-cy)/ry
                if u*u+v*v<=1 and v<-0.15 and b.get(x,y)!=0:
                    b.put(x,y,mixc(b.get(x,y),hair,0.55),42)
    # ears
    if view=='F' and H>=30:
        for sgn in (-1,1):
            ex=int(cx+sgn*rx*1.0-(0 if sgn>0 else 1)); ey=int(cy+ry*0.05)
            b.put(ex,ey,ST[2],42); 
            if H>=40: b.put(ex,ey+1,ST[2],42)
    if view=='S':
        b.put(int(cx-rx*0.15),int(cy+ry*0.05),ST[3],42)
        if H>=40: b.put(int(cx-rx*0.15),int(cy+ry*0.05)+1,ST[2],42)
    # face features
    if view=='F':
        ey=int(cy+ry*0.10)
        ew=max(1,int(rx*0.38))
        for sgn in (-1,1):
            ex=int(cx+sgn*rx*0.42-(0 if sgn>0 else 0))
            if H>=40:
                b.put(ex,ey,0xFFF4F4F4,44); b.put(ex+(1 if sgn<0 else -1),ey,0xFF16121C,44)   # white + pupil
            else:
                b.put(ex,ey,0xFF16121C,44)
            # brows
            if H>=36 and look.brow>0:
                bc=HT[3] if look.hair!=0xFFE8E8E8 else 0xFF8A8A8A
                b.put(ex,ey-1,mixc(bc,0xFF000000,0.2),44)
                if look.brow>1: b.put(ex+(1 if sgn<0 else -1),ey-1,bc,44)
        # nose
        if H>=36: b.put(int(cx-0.5+0.5),int(cy+ry*0.40),ST[2],44)
        # mouth
        my=int(cy+ry*0.66)
        mc=mixc(skin,0xFF7A2C34,0.55)
        if pose.mouth==2 and H>=36:
            b.put(int(cx-1),my,0xFF3A1018,44); b.put(int(cx),my,0xFF3A1018,44); b.put(int(cx-1),my+1,0xFF3A1018,44)
        elif H>=36:
            b.put(int(cx-1),my,mc,44); b.put(int(cx),my,mc,44)
        # jaw shade
        for y in range(int(cy+ry*0.8),int(cy+ry*1.05)):
            for x in range(int(cx-rx),int(cx+rx)):
                if b.get(x,y)!=0 and b.grp(x,y)==41:
                    pass
    if view=='S' and H>=36:
        ey=int(cy+ry*0.10); ex=int(cx+rx*0.45)
        b.put(ex,ey,0xFF16121C,44)
        if look.brow>0: b.put(ex,ey-1,HT[3],44)
        b.put(int(cx+rx*0.98),int(cy+ry*0.28),ST[2],44)   # nose tip
        b.put(int(cx+rx*0.55),int(cy+ry*0.66),mixc(skin,0xFF7A2C34,0.55),44)
    # beard
    if look.beard>0 and view!='B':
        bt=look.beard
        for y in range(int(cy),int(cy+ry*1.3)):
            for x in range(int(cx-rx*1.1),int(cx+rx*1.1)):
                if b.get(x,y)==0 or b.grp(x,y) not in (41,): continue
                u=(x+0.5-cx)/rx; v=(y+0.5-cy)/ry
                if view=='S': 
                    if u<-0.15: continue
                if bt==1 and v>0.45 and abs(u)<0.95 and u*u+v*v>0.35: b.put(x,y,mixc(skin,hair,0.45),45)
                elif bt==2 and v>0.38: b.put(x,y,HT[1] if (x+y)%5 else HT[2],45)
                elif bt==3 and ((v>0.42 and abs(u)<0.35) or (0.50<v<0.60 and abs(u)<0.7)): b.put(x,y,HT[1],45)
    if look.beard>0 and view=='F' and H>=36:
        my=int(cy+ry*0.66)
        # keep mouth visible
        b.put(int(cx-1),my,mixc(skin,0xFF7A2C34,0.55) if look.beard<2 else shade(0xFF7A2C34,0.7),46)

def to_image(W,H,img,scale=1,bg=(60,120,70,255)):
    im=Image.new('RGBA',(W,H),(0,0,0,0))
    for y in range(H):
        for x in range(W):
            c=img[y*W+x]
            if c: im.putpixel((x,y),(rgb(c)[0],rgb(c)[1],rgb(c)[2],255))
    if scale>1: im=im.resize((W*scale,H*scale),Image.NEAREST)
    return im

if __name__=="__main__":
    import sys
    H=int(sys.argv[1]) if len(sys.argv)>1 else 42
    looks=[
      Look(skin=0xFFEAB98C,hair=0xFF1A1208,hairStyle=0,beard=0,build=1,shirt=0xFF1E88E5,shirt2=0xFFFFFFFF,pattern=0,shorts=0xFFFFFFFF,socks=0xFF1E88E5,number=10),
      Look(skin=0xFFA46A3F,hair=0xFF1A1208,hairStyle=4,beard=1,build=2,shirt=0xFFD32F2F,shirt2=0xFF111111,pattern=1,shorts=0xFF111111,socks=0xFFD32F2F,shorts2=0xFFD32F2F,number=7),
      Look(skin=0xFFFBD5B5,hair=0xFFD9B35B,hairStyle=2,beard=0,build=0,shirt=0xFF2E7D32,shirt2=0xFFFFFFFF,pattern=2,shorts=0xFF2E7D32,socks=0xFFFFFFFF,number=17),
      Look(skin=0xFF7A4A28,hair=0xFF1A1208,hairStyle=3,beard=2,build=3,shirt=0xFFFFC857,shirt2=0xFF1B2A6B,pattern=3,shorts=0xFF1B2A6B,socks=0xFFFFC857,number=5),
      Look(skin=0xFFC98E5F,hair=0xFF4A2C12,hairStyle=6,beard=3,build=1,shirt=0xFF6A1B9A,shirt2=0xFFFFFFFF,pattern=4,shorts=0xFF6A1B9A,socks=0xFF6A1B9A,number=23),
      Look(skin=0xFFEAB98C,hair=0xFFB5381E,hairStyle=1,beard=0,build=1,shirt=0xFF22AA44,shirt2=0xFF145A26,shorts=0xFF145A26,socks=0xFF22AA44,keeper=True,sleeves=1,number=1),
    ]
    poses=['idle','run0','run2','run4','kick_wind','kick_strike','kick_follow','celebrate','slump','header','keeper']
    def getpose(n):
        if n.startswith('run'): return run_pose(int(n[3:])/6.0)
        return POSES[n]
    sc=3 if H<60 else 2
    for view in ('F','B','S'):
        rows=[]
        for lk in looks:
            ims=[]
            for pn in poses:
                W,Hh,img=render(lk,view,getpose(pn),H)
                ims.append(to_image(W,Hh,img,sc))
            rows.append(ims)
        wcell=ims[0].width; hcell=ims[0].height
        sheet=Image.new('RGBA',(wcell*len(poses),hcell*len(looks)),(52,110,64,255))
        for r,ims in enumerate(rows):
            for c,im in enumerate(ims):
                sheet.alpha_composite(im,(c*wcell,r*hcell))
        sheet.save(f'sheet_{view}_{H}.png')
    print("ok")
