package com.goatjourney.rendering

import android.graphics.Canvas
import android.graphics.Paint
import com.goatjourney.core.match.*
import com.goatjourney.core.player.Position
import com.goatjourney.core.simulation.MatchSimulationEngine
import com.goatjourney.game.GameController
import com.goatjourney.game.GameState
import com.goatjourney.rendering.pixel.*
import kotlin.math.*

/**
 * Cámara VERTICAL: el campo se dibuja girado; tu equipo ataca hacia ARRIBA.
 * sx recibe la coordenada y del mundo (ancho), sy recibe la x del mundo (largo).
 */
class Camera {
    var cx = 52.5f; var cy = 34f; var zoom = 10.4f
    var tx = 52.5f; var ty = 34f; var tz = 10.4f
    var shake = 0f
    private var t = 0f
    private var ox = 0f; private var oy = 0f
    private val anchorY = 650f

    fun overview() { tx = 52.5f; ty = 34f; tz = 10.4f }
    fun snapOverview() { overview(); cx = tx; cy = ty; zoom = tz }
    fun snap() { cx = tx; cy = ty; zoom = tz }

    fun update(dt: Float) {
        val f = min(1f, dt * 5f)
        cx += (tx - cx) * f; cy += (ty - cy) * f; zoom += (tz - zoom) * f
        shake = max(0f, shake - dt * 2.2f); t += dt
        ox = sin(t * 61f) * shake * 9f; oy = cos(t * 53f) * shake * 9f
    }

    fun sx(wy: Float) = (wy - cy) * zoom + 360f + ox
    fun sy(wx: Float) = (cx - wx) * zoom + anchorY + oy
}

/**
 * Pantalla de partido (MATCH_SIMULATION / MATCH_OPPORTUNITY), VERTICAL.
 * Fases: SIM -> INTRO -> MOMENT (posicionar / apuntar / contacto) -> FLIGHT (tramos del balón) -> SIM ...
 * Toda la lógica de fútbol vive en core (MomentSession, ActionResolver, BallPhysics); aquí solo se anima y se dibuja.
 */
class MatchScreen(g: GameController) : BaseScreen(g) {
    private enum class Phase { SIM, INTRO, MOMENT, FLIGHT, FULLTIME }
    private enum class Touch { NONE, MOVE, AIM_START, AIM, CONTACT }

    override val background: Int get() = Palette.GRASS_DARK

    private var eng: MatchSimulationEngine? = null
    private var phase = Phase.SIM
    private val cam = Camera()
    private val particles = Particles()

    private var myShirt = 0; private var myShorts = 0; private var oppShirt = 0; private var oppShorts = 0
    private var speed = 1f
    private var pt = 0f
    private var spin = 0f
    private var finishCalled = false

    // simulación abstracta
    private var bwx = 52.5f; private var bwy = 34f
    private val FX = floatArrayOf(0.04f, 0.22f, 0.20f, 0.20f, 0.22f, 0.42f, 0.45f, 0.42f, 0.68f, 0.72f, 0.68f)
    private val FY = floatArrayOf(0.5f, 0.88f, 0.62f, 0.38f, 0.12f, 0.3f, 0.5f, 0.7f, 0.85f, 0.5f, 0.15f)

    // escena del momento
    private var sess: MomentSession? = null
    private var result: ActionResult? = null
    private var curP = Vec(0f, 0f)
    private var curM = ArrayList<Vec>()
    private var curR = ArrayList<Vec>()
    private var curK: Vec? = null
    private var ballPos = Vec(0f, 0f)
    private var ballZ = 0f

    // tramos (beats)
    private var beatIdx = 0
    private var beatT = 0f
    private var beatDur = 1f
    private var beatScale = 1f
    private var holding = false
    private var holdT = 0f
    private var fromP = Vec(0f, 0f); private var toP = Vec(0f, 0f)
    private var fromM = ArrayList<Vec>(); private var toM = ArrayList<Vec>()
    private var fromR = ArrayList<Vec>(); private var toR = ArrayList<Vec>()
    private var fromK: Vec? = null; private var toK: Vec? = null
    private var trailSamples: List<BallSample> = emptyList()
    private var bannerHead = ""; private var bannerDetail = ""; private var bannerColor = Palette.ACCENT
    private var bannerOn = false; private var celebrate = false; private var bannerT = 0f

    // input
    private var touch = Touch.NONE
    private var dragX = 0f; private var dragY = 0f
    private var fingerX = 0f; private var fingerY = 0f
    private var anchorX = 0f; private var anchorY = 0f
    private var cNx = 0f; private var cNy = 0f
    private var preview: AimPreview? = null
    private var downX = 0f; private var downY = 0f
    private val GRAB_R = 120f                                   // zona de agarre del balón (generosa)
    private val CB_X = 360f; private val CB_Y = 790f
    private val CB_CELL = PX.LP * 9f                            // lado de una celda de la cuadrícula lógica 32x32 (px de ref)
    private val CB_R = CB_CELL * ContactGrid.N / 2f
    private var rawNx = 0f; private var rawNy = 0f              // toque normalizado respecto al centro del balón
    private var curContact = Contact(0f, 0f)
    private var contactTraj: Trajectory? = null

    // identidad visual
    private val stadium = Stadium()
    private var playerLook: Look? = null
    private val mateLooks = ArrayList<Look>(); private val rivalLooks = ArrayList<Look>()
    private var keeperLook: Look? = null
    private var myClubId = 0; private var oppClubId = 0; private var myShirt2 = 0; private var oppShirt2 = 0
    private var myPattern = 0; private var oppPattern = 0
    private var kickView = 0; private var lastTone = Tone.NEUTRAL

    // caches de texto
    private var clockSec = -1; private var clockStr = "00:00"
    private var scoreKey = -1; private var scoreStr = ""
    private var evCount = -1; private var evStr = ""
    private var ratingStr = "6.0"

    private fun wx(v: Vec) = cam.sx(v.y)
    private fun wy(v: Vec) = cam.sy(v.x)
    private fun worldDir(dx: Float, dy: Float) = Vec(-dy, dx).norm()

    fun begin(e: MatchSimulationEngine) {
        eng = e
        myShirt = e.myClub.primary; myShorts = e.myClub.secondary
        val o = e.oppClub
        val dr = abs((myShirt shr 16 and 255) - (o.primary shr 16 and 255)) +
            abs((myShirt shr 8 and 255) - (o.primary shr 8 and 255)) + abs((myShirt and 255) - (o.primary and 255))
        oppShirt = if (dr < 110) o.secondary else o.primary
        oppShorts = darken(oppShirt, 0.6f)
        myClubId = e.myClub.id; oppClubId = o.id
        myShirt2 = e.myClub.secondary; oppShirt2 = if (oppShirt == o.primary) o.secondary else o.primary
        val pat = { id: Int -> when (Math.floorMod(id * 7 + 3, 8)) { 0, 1, 2 -> 0; 3 -> 1; 4 -> 2; 5 -> 3; 6 -> 4; else -> 5 } }
        myPattern = pat(myClubId); oppPattern = pat(oppClubId)
        val pl = e.player
        val build = when (pl.position) { Position.CENTER_BACK, Position.STRIKER -> 2; Position.WINGER -> 0; else -> 1 }
        playerLook = Looks.protagonist(pl.appearance, pl.name + pl.surname, myShirt, myShirt2, myShorts, myShirt, myPattern, pl.shirtNumber, build)
        mateLooks.clear(); rivalLooks.clear()
        keeperLook = Looks.npc(oppClubId * 131 + 9, 0xFFFFC857.toInt(), 0xFF222222.toInt(), 0xFF222222.toInt(), 0xFF222222.toInt(), 0, 1, keeper = true)
        phase = Phase.SIM; speed = 1f; pt = 0f; finishCalled = false
        cam.snapOverview(); bwx = 52.5f; bwy = 34f
        sess = null; result = null; touch = Touch.NONE; bannerOn = false
        clockSec = -1; scoreKey = -1; evCount = -1
        game.setMatchState(GameState.MATCH_SIMULATION)
        game.feedback.whistle()
    }

    override fun onBack(): Boolean = true // no se abandona un partido a medias

    // ------------------------------------------------------------------ update
    override fun update(dt: Float) {
        super.update(dt)
        val e = eng ?: return
        cam.update(dt); particles.update(dt); spin += dt * 9f; pt += dt
        if (bannerOn) bannerT += dt
        when (phase) {
            Phase.SIM -> {
                e.update(dt * speed)
                val tx = 52.5f + e.momentum * 38f + sin(time * 0.9f) * 6f
                val ty = 34f + sin(time * 1.3f) * 14f
                val f = min(1f, dt * 2.5f)
                bwx += (tx - bwx) * f; bwy += (ty - bwy) * f
                val p = e.pending
                if (p != null) startMoment(p)
                else if (e.finished) { phase = Phase.FULLTIME; pt = 0f; game.feedback.whistle() }
            }
            Phase.INTRO -> if (pt >= 0.8f) { phase = Phase.MOMENT; pt = 0f }
            Phase.MOMENT -> updateMoment(dt)
            Phase.FLIGHT -> updateFlight(dt)
            Phase.FULLTIME -> if (pt >= 2.0f && !finishCalled) { finishCalled = true; game.finishMatch(e) }
        }
    }

    private fun startMoment(m: KeyMoment) {
        val e = eng ?: return
        val s = e.beginMoment()
        sess = s; result = null
        phase = Phase.INTRO; pt = 0f; touch = Touch.NONE; bannerOn = false; preview = null
        sync(s)
        game.setMatchState(GameState.MATCH_OPPORTUNITY)
        // encuadre: todos los actores + trayectoria entrante + portería si hay ocasión
        var x0 = 999f; var x1 = -999f; var y0 = 999f; var y1 = -999f
        fun add(v: Vec) { x0 = min(x0, v.x); x1 = max(x1, v.x); y0 = min(y0, v.y); y1 = max(y1, v.y) }
        add(s.world.player)
        for (mt in s.world.mates) { add(mt.pos); add(mt.run) }
        for (r in s.world.rivals) add(r.pos)
        s.world.keeper?.let { add(it.pos) }
        m.incoming?.let { inc -> add(Vec(inc.samples[0].x, inc.samples[0].y)); add(inc.endPos) }
        if (IntentKind.SHOT in m.actions || m.type == KeyMomentType.CROSS_MOMENT) add(Vec(Pitch.LENGTH, Pitch.CENTER_Y))
        if (m.type == KeyMomentType.CLEARANCE_MOMENT) add(Vec(0f, Pitch.CENTER_Y))
        // margen para el movimiento posible
        if (m.mode == MomentMode.POSITIONING) { add(Vec(s.world.player.x + s.maxMove * 0.7f, s.world.player.y)); add(Vec(s.world.player.x - s.maxMove * 0.4f, s.world.player.y)) }
        fitTo(x0, x1, y0, y1)
    }

    private fun fitTo(x0: Float, x1: Float, y0: Float, y1: Float) {
        val w = max(34f, (y1 - y0)) + 10f
        val h = max(34f, (x1 - x0)) + 14f
        cam.tz = min(660f / w, 860f / h).coerceIn(10.4f, 24f)
        cam.tx = (x0 + x1) / 2f; cam.ty = (y0 + y1) / 2f
    }

    private fun sync(s: MomentSession) {
        curP = s.world.player
        curM = ArrayList(s.world.mates.map { it.pos })
        curR = ArrayList(s.world.rivals.map { it.pos })
        curK = s.world.keeper?.pos
        ballPos = s.ball; ballZ = s.ballZ
    }

    private fun updateMoment(dt: Float) {
        val s = sess ?: return
        s.update(dt)
        sync(s)
        if (touch == Touch.AIM && s.phase == MomentSession.Phase.AIM) {
            val len = hypot(dragX, dragY)
            preview = if (len >= AimPhase.MIN_DRAG) s.preview(worldDir(dragX, dragY), len) else null
        } else preview = null
        contactTraj = if (s.phase == MomentSession.Phase.CONTACT) s.previewContactTrajectory(curContact) else null
        if (s.expired && s.phase == MomentSession.Phase.AIM) startFlight(s.timeoutResolve())
    }

    // ------------------------------------------------------------------ vuelo (tramos)
    private fun startFlight(r: ActionResult) {
        val s = sess ?: return
        result = r
        val b0 = r.beats.firstOrNull()
        if (b0 != null && b0.samples.size > 1) {
            val a = b0.samples[0]; val z = b0.samples[b0.samples.size - 1]
            kickView = Humans.viewFor(z.y - a.y, -(z.x - a.x))
        } else kickView = 0
        touch = Touch.NONE; preview = null; contactTraj = null
        phase = Phase.FLIGHT; pt = 0f
        sync(s)
        var x0 = 999f; var x1 = -999f; var y0 = 999f; var y1 = -999f
        fun add(x: Float, y: Float) { x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y) }
        add(curP.x, curP.y)
        for (v in curM) add(v.x, v.y)
        for (v in curR) add(v.x, v.y)
        for (b in r.beats) for (smp in b.samples) add(smp.x, smp.y)
        fitTo(x0, x1, y0, y1)
        startBeat(0)
    }

    private fun startBeat(i: Int) {
        val r = result ?: return
        if (i >= r.beats.size) { endFlight(); return }
        val b = r.beats[i]
        beatIdx = i; beatT = 0f; holding = false; holdT = 0f; bannerOn = false
        val last = if (b.samples.isEmpty()) 0f else b.samples[b.samples.size - 1].t
        beatScale = max(1f, last / 2.4f)
        beatDur = max(0.05f, last / beatScale)
        fromP = curP; fromM = ArrayList(curM); fromR = ArrayList(curR); fromK = curK
        toP = curP; toM = ArrayList(curM); toR = ArrayList(curR); toK = curK
        for (mv in b.moves) when (mv.kind) {
            ActorKind.PLAYER -> toP = mv.to
            ActorKind.MATE -> if (mv.index in toM.indices) toM[mv.index] = mv.to
            ActorKind.RIVAL -> if (mv.index in toR.indices) toR[mv.index] = mv.to
            ActorKind.KEEPER -> toK = mv.to
        }
        trailSamples = b.samples
    }

    private fun sampleAt(list: List<BallSample>, t: Float): BallSample {
        if (list.isEmpty()) return BallSample(0f, ballPos.x, ballPos.y, 0f)
        if (t <= list[0].t) return list[0]
        val last = list[list.size - 1]
        if (t >= last.t) return last
        var i = 1
        while (i < list.size && list[i].t < t) i++
        val a = list[i - 1]; val b = list[i]
        val u = (t - a.t) / max(1e-4f, b.t - a.t)
        return BallSample(t, mix(a.x, b.x, u), mix(a.y, b.y, u), mix(a.z, b.z, u))
    }

    private fun updateFlight(dt: Float) {
        val r = result ?: return
        val b = r.beats.getOrNull(beatIdx)
        if (b == null) { endFlight(); return }
        if (!holding) {
            beatT += dt
            val prog = (beatT / beatDur).coerceIn(0f, 1f)
            val ease = Ease.outQuad(prog)
            curP = fromP.lerp(toP, ease)
            for (i in curM.indices) curM[i] = fromM[i].lerp(toM[i], ease)
            for (i in curR.indices) curR[i] = fromR[i].lerp(toR[i], ease)
            val fk = fromK; val tk = toK
            if (fk != null && tk != null) curK = fk.lerp(tk, ease)
            val smp = sampleAt(b.samples, beatT * beatScale)
            ballPos = Vec(smp.x, smp.y); ballZ = smp.z
            if (beatT >= beatDur) { holding = true; holdT = 0f; onLanded(b) }
        } else {
            holdT += dt
            if (holdT >= b.hold) startBeat(beatIdx + 1)
        }
    }

    private fun onLanded(b: Beat) {
        if (b.headline.isNotEmpty()) {
            bannerOn = true; bannerT = 0f
            bannerHead = b.headline; bannerDetail = b.detail
            bannerColor = when (b.tone) { Tone.GOAL -> Palette.GOLD; Tone.GOOD -> Palette.ACCENT; Tone.BAD -> Palette.RED; Tone.NEUTRAL -> Palette.WHITE }
        }
        celebrate = b.celebrate; lastTone = b.tone
        if (b.celebrate) { particles.burst(360f, 420f); cam.shake = 1f; game.feedback.goal() }
        else if (b.tone == Tone.BAD) game.feedback.vibrate(25)
    }

    private fun endFlight() {
        val e = eng ?: return
        val r = result
        if (r != null) { e.finishMoment(r); e.continueAfterResult() }
        sess = null; result = null; bannerOn = false; celebrate = false
        val nxt = e.pending
        if (nxt != null) startMoment(nxt)
        else if (e.finished) { phase = Phase.FULLTIME; pt = 0f; game.feedback.whistle() }
        else { phase = Phase.SIM; pt = 0f; cam.overview(); game.setMatchState(GameState.MATCH_SIMULATION) }
    }

    // ------------------------------------------------------------------ input
    override fun onTap(x: Float, y: Float) { if (phase == Phase.SIM) speed = if (speed > 1f) 1f else 3f }

    private fun updateMove(x: Float, y: Float) {
        val s = sess ?: return
        fingerX = x; fingerY = y
        val dx = x - wx(curP); val dy = y - wy(curP)
        val d = hypot(dx, dy)
        if (d < 12f) s.setMove(null, 0f) else s.setMove(worldDir(dx, dy), (d / 150f).coerceIn(0.35f, 1f))
    }

    /** Toque -> coordenadas normalizadas respecto al centro del balón -> celda de la cuadrícula lógica -> contacto. */
    private fun setContact(x: Float, y: Float) {
        var nx = (x - CB_X) / CB_R; var ny = -(y - CB_Y) / CB_R
        val l = hypot(nx, ny)
        if (l > 1f) { nx /= l; ny /= l }          // fuera del balón: se proyecta al borde (zona táctil generosa)
        rawNx = nx; rawNy = ny
        curContact = ContactPhase.fromTouch(nx, ny)
    }

    override fun onDown(x: Float, y: Float) {
        if (phase == Phase.INTRO) { phase = Phase.MOMENT; pt = 0f }      // el gesto no se pierde durante la intro
        if (phase != Phase.MOMENT) return
        val s = sess ?: return
        downX = x; downY = y; dragX = 0f; dragY = 0f; fingerX = x; fingerY = y
        when (s.phase) {
            MomentSession.Phase.POSITIONING -> {
                val bx = wx(ballPos); val by = wy(ballPos)
                if (!s.canMove() || hypot(x - bx, y - by) < GRAB_R) {
                    touch = Touch.AIM; anchorX = bx; anchorY = by; s.beginAim()      // apunta desde el primer píxel
                    game.feedback.vibrate(8)
                } else { touch = Touch.MOVE; updateMove(x, y) }
            }
            MomentSession.Phase.AIM -> { touch = Touch.AIM; anchorX = x; anchorY = y }
            MomentSession.Phase.CONTACT -> { touch = Touch.CONTACT; setContact(x, y) }
            else -> {}
        }
    }

    /** Cada movimiento del dedo (sin umbral): el trazo sigue al dedo sin retraso. */
    override fun onMove(x: Float, y: Float) {
        if (phase != Phase.MOMENT) return
        fingerX = x; fingerY = y
        when (touch) {
            Touch.MOVE -> updateMove(x, y)
            Touch.AIM -> { dragX = x - downX; dragY = y - downY }
            Touch.CONTACT -> setContact(x, y)
            else -> {}
        }
    }

    override fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) {
        val s = sess
        if (s == null || phase != Phase.MOMENT) { touch = Touch.NONE; return }
        when (touch) {
            Touch.MOVE -> s.setMove(null, 0f)
            Touch.AIM -> {
                dragX = x - downX; dragY = y - downY
                val len = hypot(dragX, dragY)
                if (len >= AimPhase.MIN_DRAG) {
                    if (s.releaseAim(worldDir(dragX, dragY), len)) {
                        val done = s.result
                        if (s.phase == MomentSession.Phase.DONE && done != null) startFlight(done)
                        else { rawNx = 0f; rawNy = 0f; curContact = Contact(0f, 0f) }
                    }
                } else s.cancelAim()
            }
            Touch.CONTACT -> {
                setContact(x, y)
                startFlight(s.commitContact(rawNx, rawNy))
            }
            else -> {}
        }
        touch = Touch.NONE; dragX = 0f; dragY = 0f
    }

    /** El sistema interrumpió el gesto: no se ejecuta nada. */
    override fun onCancel() {
        val s = sess
        if (s != null && phase == Phase.MOMENT) {
            if (touch == Touch.MOVE) s.setMove(null, 0f)
            if (touch == Touch.AIM) s.cancelAim()
        }
        touch = Touch.NONE; dragX = 0f; dragY = 0f
    }

    // ------------------------------------------------------------------ render
    override fun render(c: Canvas) { draw(c) }

    override fun draw(c: Canvas) {
        val e = eng ?: return
        drawPitch(c)
        if (phase == Phase.SIM || phase == Phase.FULLTIME) drawSim(c, e) else drawScene(c, e)
        drawHud(c, e)
        if (phase == Phase.INTRO || phase == Phase.MOMENT) drawMomentUi(c)
        if (phase == Phase.FLIGHT && bannerOn) drawBanner(c)
        particles.draw(c, ui)
        if (phase == Phase.FULLTIME) {
            ui.fillRect(c, 0f, 520f, Ref.W, 200f, withAlpha(0xFF000000.toInt(), 170))
            ui.text(c, "FINAL DEL PARTIDO", 360f, 610f, 62f, Palette.GOLD, Paint.Align.CENTER)
            ui.text(c, scoreStr, 360f, 676f, 44f, Palette.WHITE, Paint.Align.CENTER)
        }
    }

    private fun drawPitch(c: Canvas) {
        val l = cam.sx(0f); val r = cam.sx(68f); val top = cam.sy(105f); val bot = cam.sy(0f)
        val z = cam.zoom
        stadium.drawSurround(c, l, r, top, bot, z, myShirt, myShirt2, time)
        stadium.drawTurf(c, l, r, top, bot, Palette.GRASS1, Palette.GRASS2)
        ui.stroke.color = withAlpha(Palette.WHITE, 220); ui.stroke.strokeWidth = max(PX.LP * 1.5f, PX.snap(z * 0.17f))
        c.drawRect(l, top, r, bot, ui.stroke)
        val my = cam.sy(52.5f); c.drawLine(l, my, r, my, ui.stroke)
        val cx = cam.sx(34f)
        c.drawCircle(cx, my, 9.15f * z, ui.stroke)
        ui.fill.color = Palette.WHITE; c.drawRect(cx - max(PX.LP, z * 0.25f), my - max(PX.LP, z * 0.25f), cx + max(PX.LP, z * 0.25f), my + max(PX.LP, z * 0.25f), ui.fill)
        c.drawRect(cam.sx(13.84f), top, cam.sx(54.16f), cam.sy(88.5f), ui.stroke)
        c.drawRect(cam.sx(13.84f), cam.sy(16.5f), cam.sx(54.16f), bot, ui.stroke)
        c.drawRect(cam.sx(24.84f), top, cam.sx(43.16f), cam.sy(99.5f), ui.stroke)
        c.drawRect(cam.sx(24.84f), cam.sy(5.5f), cam.sx(43.16f), bot, ui.stroke)
        stadium.drawGoal(c, cam.sx(30.34f), cam.sx(37.66f), top, 2.4f * z, -1, z)
        stadium.drawGoal(c, cam.sx(30.34f), cam.sx(37.66f), bot, 2.4f * z, 1, z)
        stadium.drawCornerFlag(c, l, top, true, myShirt, z); stadium.drawCornerFlag(c, r, top, true, myShirt, z)
        stadium.drawCornerFlag(c, l, bot, false, oppShirt, z); stadium.drawCornerFlag(c, r, bot, false, oppShirt, z)
    }

    private fun mateLook(i: Int): Look {
        while (mateLooks.size <= i) {
            val k = mateLooks.size
            mateLooks.add(Looks.npc(myClubId * 1000 + k * 37 + 5, myShirt, myShirt2, myShorts, myShirt, myPattern, 2 + (k * 3) % 18))
        }
        return mateLooks[i]
    }

    private fun rivalLook(i: Int): Look {
        while (rivalLooks.size <= i) {
            val k = rivalLooks.size
            rivalLooks.add(Looks.npc(oppClubId * 1000 + k * 41 + 11, oppShirt, oppShirt2, oppShorts, oppShirt, oppPattern, 2 + (k * 5) % 18))
        }
        return rivalLooks[i]
    }

    private fun drawSim(c: Canvas, e: MatchSimulationEngine) {
        val z = cam.zoom
        val shift = (bwx - 52.5f) * 0.35f
        val rad = max(5f, z * 0.85f)
        val idx = when (e.player.position) {
            Position.CENTER_BACK -> 3
            Position.FULL_BACK -> 4
            Position.MIDFIELDER -> 6
            Position.WINGER -> 10
            Position.STRIKER -> 9
        }
        val tier = Humans.T_SMALL
        for (i in 0 until 11) {
            val wob = sin(time * 1.7f + i) * 1.1f
            val mxw = FX[i] * 105f + shift * (if (i == 0) 0.2f else 1f)
            val myw = FY[i] * 68f + wob
            val px = cam.sx(myw); val py = cam.sy(mxw)
            val oxw = 105f - FX[i] * 105f + shift * (if (i == 0) 0.2f else 1f)
            val oyw = 68f - FY[i] * 68f + wob
            val ox = cam.sx(oyw); val oy = cam.sy(oxw)
            // pintado de atrás hacia delante según y de pantalla
            val look = if (i == idx && playerLook != null) playerLook!! else mateLook(i)
            if (oy < py) {
                Humans.draw(c, rivalLook(i), 1, Poses.runFrame(time * 9f + i * 1.9f), ox, oy + 4f, tier)
                Humans.draw(c, look, 0, Poses.runFrame(time * 9f + i * 1.3f), px, py + 4f, tier)
            } else {
                Humans.draw(c, look, 0, Poses.runFrame(time * 9f + i * 1.3f), px, py + 4f, tier)
                Humans.draw(c, rivalLook(i), 1, Poses.runFrame(time * 9f + i * 1.9f), ox, oy + 4f, tier)
            }
            if (i == idx && e.minute in e.startMinute..e.endMinute) {
                ui.stroke.color = Palette.GOLD; ui.stroke.strokeWidth = PX.LP * 2f
                c.drawRect(px - rad, py - tier * PX.LP - 6f + sin(time * 5f) * 2f, px + rad, py - tier * PX.LP - 6f + PX.LP * 2f + sin(time * 5f) * 2f, ui.fill.apply { color = Palette.GOLD })
                ui.text(c, "TÚ", px, py - tier * PX.LP - 18f, 22f, Palette.GOLD, Paint.Align.CENTER)
            }
        }
        ui.ball(c, cam.sx(bwy), cam.sy(bwx), max(5f, z * 0.6f), spin)
        if (phase == Phase.SIM) ui.text(c, if (speed > 1f) "VELOCIDAD x3  (toca para normal)" else "Toca la pantalla: velocidad x3", 360f, 1252f, 20f, withAlpha(Palette.WHITE, 170), Paint.Align.CENTER)
    }

    private fun moving(from: Vec?, to: Vec?): Boolean = phase == Phase.FLIGHT && !holding && from != null && to != null && from.dist(to) > 0.4f
    private fun dirX(from: Vec, to: Vec) = to.y - from.y
    private fun dirY(from: Vec, to: Vec) = -(to.x - from.x)
    private fun idlePose() = if (((time * 1.6f).toInt() and 1) == 0) Poses.IDLE else Poses.IDLE2

    private fun drawScene(c: Canvas, e: MatchSimulationEngine) {
        val s = sess
        val z = cam.zoom
        val tier = Humans.tierForZoom(z)
        val th = tier * PX.LP
        val m = s?.moment
        // trayectoria entrante (reacción) y punto de contacto
        if (m != null && phase != Phase.FLIGHT) {
            val inc = m.incoming
            if (inc != null) {
                var i = 1
                while (i < inc.samples.size) {
                    val b = inc.samples[i]
                    ui.fillRect(c, cam.sx(b.y) - 2f, cam.sy(b.x) - b.z * z * 0.5f - 2f, 4f, 4f, withAlpha(Palette.WHITE, 140))
                    i += 2
                }
            }
            val cp = m.contact
            if (cp != null && s != null && m.mode != MomentMode.POSITIONING) {
                val u = (s.elapsed / s.window).coerceIn(0f, 1f)
                val rr = 14f + 70f * (1f - u)
                ui.stroke.color = withAlpha(if (m.mode == MomentMode.ACROBATIC) Palette.RED else Palette.GOLD, 230); ui.stroke.strokeWidth = PX.LP * 3f
                c.drawCircle(cam.sx(cp.pos.y), cam.sy(cp.pos.x) - cp.z * z * 0.5f, rr, ui.stroke)
            }
        }
        // compañeros: pistas de Vision (más sutiles cuanto peor es la lectura de juego)
        val rq = m?.readQuality ?: 0f
        val showHints = phase != Phase.FLIGHT && s != null
        for (i in curM.indices) {
            val t = curM[i]
            if (showHints && s != null && i < s.world.mates.size) {
                val mt = s.world.mates[i]
                val open = TeammateAI.openness(mt, s.world.rivals)
                val al = (40 + 160 * rq).toInt()
                val col = if (open > 0.55f) Palette.ACCENT else if (open > 0.3f && rq > 0.4f) Palette.GOLD else if (rq > 0.6f) Palette.RED else 0
                if (col != 0) {
                    ui.stroke.color = withAlpha(col, al); ui.stroke.strokeWidth = PX.LP * 2f
                    c.drawCircle(wx(t), wy(t), z * 1.5f + sin(time * 5f + i) * 1.5f, ui.stroke)
                }
                if (rq > 0.35f) ui.line(c, wx(t), wy(t), cam.sx(mt.run.y), cam.sy(mt.run.x), PX.LP, withAlpha(Palette.WHITE, 70))
            }
        }
        if (m != null && showHints && rq >= 0.55f && m.mode == MomentMode.POSITIONING) {
            for (h in m.spaceHints) {
                val q = 5f + sin(time * 4f) * 1.5f
                ui.fillRect(c, wx(h) - q, wy(h) - q, q * 2f, q * 2f, withAlpha(Palette.GOLD, (60 + 120 * rq).toInt()))
            }
        }
        // actores ordenados por profundidad (y de pantalla): 0 rival, 1 portero, 2 compañero, 3 protagonista
        val n = curR.size + curM.size + 2
        val keys = FloatArray(n); val codes = IntArray(n)
        var k = 0
        for (i in curR.indices) { keys[k] = wy(curR[i]); codes[k] = i; k++ }
        curK?.let { keys[k] = wy(it); codes[k] = 1000; k++ }
        for (i in curM.indices) { keys[k] = wy(curM[i]); codes[k] = 2000 + i; k++ }
        keys[k] = wy(curP); codes[k] = 3000; k++
        for (a in 1 until k) {            // inserción: pocos elementos
            val kk = keys[a]; val cc = codes[a]; var b = a - 1
            while (b >= 0 && keys[b] > kk) { keys[b + 1] = keys[b]; codes[b + 1] = codes[b]; b-- }
            keys[b + 1] = kk; codes[b + 1] = cc
        }
        val flightMove = phase == Phase.FLIGHT && !holding
        for (a in 0 until k) {
            val code = codes[a]
            when {
                code < 1000 -> {
                    val v = curR[code]
                    val mv = flightMove && code < fromR.size && moving(fromR[code], toR[code])
                    val view = if (mv) Humans.viewFor(dirX(fromR[code], toR[code]), dirY(fromR[code], toR[code])) else 1
                    Humans.draw(c, rivalLook(code), view, if (mv) Poses.runFrame(time * 12f + code * 1.7f) else idlePose(), wx(v), wy(v) + 4f, tier)
                }
                code == 1000 -> {
                    val v = curK ?: continue
                    val mv = flightMove && moving(fromK, toK)
                    val fk = fromK; val tk = toK
                    val view = if (mv && fk != null && tk != null) Humans.viewFor(dirX(fk, tk), dirY(fk, tk)) else 1
                    Humans.draw(c, keeperLook ?: continue, view, if (mv) Poses.runFrame(time * 12f) else Poses.KEEPER, wx(v), wy(v) + 4f, tier)
                }
                code < 3000 -> {
                    val i = code - 2000
                    val v = curM[i]
                    val mv = flightMove && i < fromM.size && moving(fromM[i], toM[i])
                    val view = if (mv) Humans.viewFor(dirX(fromM[i], toM[i]), dirY(fromM[i], toM[i])) else 0
                    Humans.draw(c, mateLook(i), view, if (mv) Poses.runFrame(time * 12f + i * 1.3f) else idlePose(), wx(v), wy(v) + 4f, tier)
                }
                else -> drawProtagonist(c, tier, th)
            }
        }
        // balón (con altura, sombra y estela)
        val bx = wx(ballPos); val by = wy(ballPos)
        val h = ballZ * z * 0.5f
        if (phase == Phase.FLIGHT) {
            val tNow = beatT * beatScale
            for (kk in 1..4) {
                val q = sampleAt(trailSamples, max(0f, tNow - kk * 0.05f))
                val q2 = max(2f, z * 0.3f) * (1f - kk * 0.18f)
                ui.fillRect(c, cam.sx(q.y) - q2, cam.sy(q.x) - q.z * z * 0.5f - q2, q2 * 2f, q2 * 2f, withAlpha(Palette.WHITE, 90 - kk * 18))
            }
        }
        if (h > 1f) {
            val sr = max(4f, z * 0.4f)
            ui.fillRect(c, bx - sr, by - sr * 0.5f, sr * 2f, sr, 0x55000000)
        }
        ui.ball(c, bx, by - h, max(6f, z * 0.62f), spin)
    }

    private fun drawProtagonist(c: Canvas, tier: Int, th: Float) {
        val look = playerLook ?: return
        val px = wx(curP); val py = wy(curP) + 4f
        var pose = idlePose(); var view = 0; var jump = 0f
        if (phase == Phase.FLIGHT) {
            val mv = !holding && curP.dist(toP) > 0.2f
            if (celebrate && holding) {
                pose = if (((holdT * 4f).toInt() and 1) == 0) Poses.CELEBRATE else Poses.CELEBRATE2
                view = 1; jump = abs(sin(holdT * 9f)) * 16f
            } else if (beatIdx == 0 && !holding && beatT < 0.6f) {
                pose = if (beatT < 0.12f) Poses.KICK_WIND else if (beatT < 0.26f) Poses.KICK_STRIKE else Poses.KICK_FOLLOW
                view = kickView
            } else if (holding && lastTone == Tone.BAD) { pose = Poses.SLUMP; view = 1 }
            else if (mv) { pose = Poses.runFrame(time * 14f); view = Humans.viewFor(dirX(fromP, toP), dirY(fromP, toP)) }
        } else if (phase == Phase.MOMENT) {
            if (touch == Touch.MOVE) { pose = Poses.runFrame(time * 14f); view = Humans.viewFor(fingerX - px, fingerY - py) }
            else if (touch == Touch.AIM && hypot(dragX, dragY) > AimPhase.MIN_DRAG) { pose = Poses.KICK_WIND; view = Humans.viewFor(dragX, dragY) }
            else if (sess?.phase == MomentSession.Phase.CONTACT) pose = Poses.KICK_WIND
        }
        Humans.draw(c, look, view, pose, px, py, tier, 1, jump)
        if (phase != Phase.FLIGHT) {
            val ix = px; val iy = py - th - 10f + sin(time * 6f) * 3f
            ui.icon(c, ICON_DOWN, ix, iy, 9f, Palette.GOLD)
        }
    }

    // ------------------------------------------------------------------ interfaz del momento
    private fun intentLabel(k: IntentKind) = when (k) {
        IntentKind.PASS -> "PASE"; IntentKind.SPACE_PASS -> "AL ESPACIO"; IntentKind.SHOT -> "TIRO"
        IntentKind.CROSS -> "CENTRO"; IntentKind.HEADER -> "CABEZAZO"; IntentKind.CLEARANCE -> "DESPEJE"
        IntentKind.CONTROL -> "PRIMER TOQUE"; IntentKind.INTERCEPT -> "INTERCEPTAR"; IntentKind.VOLLEY -> "REMATE"
        IntentKind.CHILENA -> "CHILENA"; IntentKind.BLOCK -> "BLOQUEO"
    }

    private fun drawMomentUi(c: Canvas) {
        val s = sess ?: return
        val m = s.moment
        // banner del momento
        val k = Ease.outBack((pt / 0.35f).coerceIn(0f, 1f).let { if (phase == Phase.MOMENT) 1f else it })
        if (s.phase != MomentSession.Phase.CONTACT) {
            c.save(); c.scale(k, k, 360f, 150f)
            ui.panel(c, 60f, 108f, 600f, 86f, withAlpha(0xFF050B14.toInt(), 220), if (m.mode == MomentMode.POSITIONING) Palette.GOLD else Palette.RED, 16f)
            ui.text(c, m.type.label, 84f, 158f, 40f, Palette.GOLD)
            val tag = when (m.mode) { MomentMode.POSITIONING -> "POSICIÓNATE"; MomentMode.REACTION -> "¡REACCIONA!"; MomentMode.ACROBATIC -> "¡ACROBACIA!" }
            ui.text(c, tag, 636f, 150f, 22f, if (m.mode == MomentMode.POSITIONING) Palette.ACCENT else Palette.RED, Paint.Align.RIGHT)
            ui.textFit(c, m.context, 636f, 180f, 20f, 360f, Palette.WHITE, Paint.Align.RIGHT)
            c.restore()
        }
        if (phase != Phase.MOMENT) return
        when (s.phase) {
            MomentSession.Phase.POSITIONING -> {
                val px = wx(curP); val py = wy(curP)
                if (s.timeLeft > 0f) {
                    ui.rect.set(px - 46f, py - 46f, px + 46f, py + 46f)
                    ui.stroke.color = withAlpha(Palette.ACCENT, 230); ui.stroke.strokeWidth = 5f
                    c.drawArc(ui.rect, -90f, 360f * (s.timeLeft / s.window), false, ui.stroke)
                    if (touch == Touch.MOVE) ui.line(c, px, py, fingerX, fingerY, PX.LP * 3f, withAlpha(Palette.WHITE, 150))
                    // zona de agarre del balón (generosa)
                    ui.dash.color = withAlpha(Palette.GOLD, 90 + (sin(time * 5f) * 30f).toInt()); ui.dash.strokeWidth = PX.LP * 2f
                    c.drawCircle(wx(ballPos), wy(ballPos), GRAB_R, ui.dash)
                    ui.text(c, "ARRASTRA PARA MOVERTE", 360f, 1196f, 24f, withAlpha(Palette.WHITE, 220 - (sin(time * 4f) * 40f).toInt()), Paint.Align.CENTER)
                    ui.text(c, "DESDE EL BALÓN: ARRASTRA = DIRECCIÓN + FUERZA", 360f, 1228f, 20f, withAlpha(Palette.GOLD, 220), Paint.Align.CENTER)
                } else {
                    ui.text(c, "ARRASTRA DESDE EL BALÓN", 360f, 1210f, 26f, withAlpha(Palette.GOLD, 230), Paint.Align.CENTER)
                }
            }
            MomentSession.Phase.AIM -> {
                if (s.isReaction) {
                    val u = (s.elapsed / s.window).coerceIn(0f, 1f)
                    ui.bar(c, 110f, 212f, 500f, 14f, 1f - u, if (u < 0.7f) Palette.ACCENT else Palette.RED)
                    if (touch != Touch.AIM) ui.text(c, "¡ARRASTRA YA!", 360f, 1210f, 34f, withAlpha(Palette.RED, 230 - (sin(time * 8f) * 50f).toInt()), Paint.Align.CENTER)
                }
                if (touch == Touch.AIM) drawAim(c, s)
            }
            MomentSession.Phase.CONTACT -> drawContact(c, s)
            else -> {}
        }
    }

    private fun drawAim(c: Canvas, s: MomentSession) {
        val len = hypot(dragX, dragY)
        val power = AimPhase.power(len)
        val col = if (power < 0.5f) Palette.ACCENT else if (power < 0.85f) Palette.GOLD else Palette.RED
        val ex = anchorX + dragX; val ey = anchorY + dragY
        val pv = preview
        if (pv != null) {
            val smp = pv.samples
            if (smp != null) {
                val cnt = (smp.size * 0.7f).toInt()
                var i = 0
                while (i < cnt) {
                    val q = smp[i]
                    val lofted = q.z > 0.4f
                    val r = if (lofted) 4.5f else 3.5f
                    ui.fillRect(c, cam.sx(q.y) - r, cam.sy(q.x) - q.z * cam.zoom * 0.5f - r, r * 2f, r * 2f, withAlpha(if (lofted) Palette.WHITE else Palette.GOLD, 200))
                    i += 2
                }
            }
            ui.text(c, intentLabel(pv.intent.kind), ex, ey - 26f, 26f, Palette.WHITE, Paint.Align.CENTER)
        }
        ui.line(c, anchorX, anchorY, ex, ey, PX.LP * 5f, withAlpha(col, 230))
        ui.fillRect(c, ex - 12f, ey - 12f, 24f, 24f, col)
        ui.text(c, "FUERZA", 360f, 1210f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.bar(c, 160f, 1224f, 400f, 20f, power, col)
    }

    /** Fase de contacto: balón de pixel art (cuadrícula lógica 32x32). El toque elige una celda; la celda decide spin y lift. */
    private fun drawContact(c: Canvas, s: MomentSession) {
        ui.fillRect(c, 0f, 0f, Ref.W, 560f, withAlpha(0xFF050B14.toInt(), 110))
        ui.fillRect(c, 0f, 560f, Ref.W, Ref.H - 560f, withAlpha(0xFF050B14.toInt(), 235))
        ui.fillRect(c, 0f, 556f, Ref.W, PX.LP * 2f, withAlpha(Palette.GOLD, 200))
        val it = s.intent; val a = s.aim
        if (it != null && a != null)
            ui.text(c, intentLabel(it.kind) + "  ·  FUERZA ${(a.power * 100).toInt()}%", 360f, 150f, 34f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, "ELIGE DÓNDE GOLPEAS EL BALÓN", 360f, 196f, 24f, Palette.WHITE, Paint.Align.CENTER)
        // trayectoria prevista con el contacto actual: recta al principio y curva después
        val tr = contactTraj
        if (tr != null) {
            val smp = tr.samples
            var i = 0
            while (i < smp.size) {
                val q = smp[i]
                val x = cam.sx(q.y); val y = cam.sy(q.x) - q.z * cam.zoom * 0.5f
                val prog = i.toFloat() / max(1, smp.size - 1)
                val r = if (q.z > 0.4f) 4.5f else 3.5f
                ui.fillRect(c, x - r, y - r, r * 2f, r * 2f, withAlpha(mixColor(Palette.WHITE, Palette.GOLD, prog), 235))
                i += 2
            }
            val e2 = smp[smp.size - 1]
            ui.fillRect(c, cam.sx(e2.y) - 7f, cam.sy(e2.x) - 7f, 14f, 14f, Palette.RED)
        }
        // balón grande
        PixelBall.draw(c, CB_X, CB_Y, CB_R * 2f, ContactGrid.N, 0)
        // cuadrícula: ejes y celda elegida
        val gx0 = CB_X - CB_R; val gy0 = CB_Y - CB_R
        ui.fillRect(c, CB_X - PX.LP * 0.5f, gy0, PX.LP, CB_R * 2f, withAlpha(0xFF14101C.toInt(), 70))
        ui.fillRect(c, gx0, CB_Y - PX.LP * 0.5f, CB_R * 2f, PX.LP, withAlpha(0xFF14101C.toInt(), 70))
        val col = curContact.cellX; val row = curContact.cellY
        val cx0 = gx0 + col * CB_CELL; val cy0 = gy0 + row * CB_CELL
        val hot = if (curContact.offset < 0.02f) Palette.WHITE else Palette.GOLD
        ui.fillRect(c, cx0, cy0, CB_CELL, CB_CELL, withAlpha(hot, 150))
        val t2 = PX.LP * 1.5f
        ui.fillRect(c, cx0 - t2, cy0 - t2, CB_CELL + t2 * 2f, t2, hot); ui.fillRect(c, cx0 - t2, cy0 + CB_CELL, CB_CELL + t2 * 2f, t2, hot)
        ui.fillRect(c, cx0 - t2, cy0, t2, CB_CELL, hot); ui.fillRect(c, cx0 + CB_CELL, cy0, t2, CB_CELL, hot)
        // flechas de spin resultantes (relativas al recorrido): sentido de giro lateral y altura
        val sideAmt = abs(curContact.ix); val vertAmt = abs(curContact.iy)
        ui.text(c, "RASANTE", CB_X, CB_Y - CB_R - 14f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, "ELEVADO", CB_X, CB_Y + CB_R + 34f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, "IZQ: CURVA →", CB_X - CB_R, CB_Y - CB_R - 44f, 18f, Palette.TEXT_DIM, Paint.Align.LEFT)
        ui.text(c, "DER: ← CURVA", CB_X + CB_R, CB_Y - CB_R - 44f, 18f, Palette.TEXT_DIM, Paint.Align.RIGHT)
        // lectura del resultado
        ui.text(c, SpinModel.describe(curContact.ix, curContact.iy).uppercase(), 360f, 1062f, 28f, Palette.WHITE, Paint.Align.CENTER)
        ui.text(c, "EFECTO", 150f, 1112f, 18f, Palette.TEXT_DIM, Paint.Align.LEFT)
        ui.bar(c, 150f, 1124f, 190f, 16f, sideAmt, Palette.ACCENT)
        ui.text(c, "ALTURA", 380f, 1112f, 18f, Palette.TEXT_DIM, Paint.Align.LEFT)
        ui.bar(c, 380f, 1124f, 190f, 16f, vertAmt, Palette.GOLD)
        ui.text(c, "SUELTA PARA GOLPEAR", 360f, 1196f, 24f, Palette.ACCENT, Paint.Align.CENTER)
    }

    private fun mixColor(a: Int, b: Int, t: Float): Int = PC.mix(a, b, t.coerceIn(0f, 1f))

    private fun drawBanner(c: Canvas) {
        val k = Ease.outBack((bannerT / 0.3f).coerceIn(0f, 1f))
        c.save(); c.scale(k, k, 360f, 250f)
        ui.text(c, bannerHead, 360f, 260f, if (celebrate) 84f else 58f, bannerColor, Paint.Align.CENTER)
        if (bannerDetail.isNotEmpty()) ui.textFit(c, bannerDetail, 360f, 306f, 28f, 660f, Palette.WHITE, Paint.Align.CENTER)
        c.restore()
    }

    private fun drawHud(c: Canvas, e: MatchSimulationEngine) {
        val sec = e.clockSeconds.toInt().coerceAtMost(5400)
        if (sec != clockSec) { clockSec = sec; clockStr = "%02d:%02d".format(sec / 60, sec % 60) }
        val key = e.homeGoals * 100 + e.awayGoals
        if (key != scoreKey) {
            scoreKey = key
            scoreStr = "${e.home.abbr}  ${e.homeGoals} - ${e.awayGoals}  ${e.away.abbr}"
            ratingStr = "%.1f".format(e.currentRating())
        }
        ui.panel(c, 130f, 8f, 380f, 88f, withAlpha(0xFF050B14.toInt(), 215), Palette.PANEL_LIGHT, 16f)
        ui.text(c, clockStr, 320f, 40f, 28f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, scoreStr, 320f, 82f, 34f, Palette.WHITE, Paint.Align.CENTER)
        ui.circle(c, 156f, 52f, 12f, e.home.primary); ui.circle(c, 484f, 52f, 12f, e.away.primary)
        ui.panel(c, 560f, 8f, 144f, 88f, withAlpha(0xFF050B14.toInt(), 200), Palette.PANEL_LIGHT, 14f)
        ui.text(c, ratingStr, 632f, 70f, 44f, Palette.ACCENT, Paint.Align.CENTER)
        ui.text(c, "RATING", 632f, 32f, 14f, Palette.TEXT_DIM, Paint.Align.CENTER)
        if (phase == Phase.SIM) {
            if (e.events.size != evCount) {
                evCount = e.events.size
                val ev = e.events[e.events.size - 1]
                evStr = "%02d'  %s".format(ev.minute, ev.text)
            }
            ui.textFit(c, evStr, 360f, 1208f, 26f, 680f, Palette.WHITE, Paint.Align.CENTER)
        }
    }
}
