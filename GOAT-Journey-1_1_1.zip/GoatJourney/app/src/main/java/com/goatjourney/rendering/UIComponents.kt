package com.goatjourney.rendering

import android.graphics.*
import com.goatjourney.core.player.Appearance
import com.goatjourney.rendering.pixel.*
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

object Palette {
    val BG = 0xFF0A1424.toInt()
    val BG2 = 0xFF12233D.toInt()
    val PANEL = 0xE6162B4A.toInt()
    val PANEL_LIGHT = 0xFF2A4A7A.toInt()
    val ACCENT = 0xFF2EE6A6.toInt()
    val GOLD = 0xFFFFC857.toInt()
    val RED = 0xFFFF5470.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val TEXT_DIM = 0xFF8FA6C4.toInt()
    val GRASS_DARK = 0xFF1F6B38.toInt()
    val GRASS1 = 0xFF2E8B4A.toInt()
    val GRASS2 = 0xFF2A7F43.toInt()
}

fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

fun darken(color: Int, f: Float = 0.62f): Int =
    Color.rgb((((color shr 16) and 255) * f).toInt(), (((color shr 8) and 255) * f).toInt(), ((color and 255) * f).toInt())

const val ICON_LEFT = 0
const val ICON_RIGHT = 1
const val ICON_UP = 2
const val ICON_DOWN = 3

class Btn(
    val id: String, val x: Float, val y: Float, val w: Float, val h: Float,
    var label: String, val style: Int = 0, val icon: Int = -1
) {
    var enabled = true
    var visible = true
    fun contains(px: Float, py: Float) = px >= x && px <= x + w && py >= y && py <= y + h
}

/** Sistema visual reutilizable: paneles, botones, texto, barras, jugadores, balón. Todo en pixel art: sin antialias, rejilla de píxeles lógicos. */
class UI {
    val fill = Paint()
    val stroke = Paint().apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.SQUARE }
    val dash = Paint().apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val fontPaint = Paint()
    val rect = RectF()
    val path = Path()
    private val lp = PX.LP

    fun fillRect(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int) {
        fill.color = color; c.drawRect(x, y, x + w, y + h, fill)
    }

    fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill.color = color; c.drawCircle(x, y, r, fill)
    }

    fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        stroke.color = color; stroke.strokeWidth = w; c.drawLine(x1, y1, x2, y2, stroke)
    }

    private fun drawPix(c: Canvas, s: String, x: Float, y: Float, k: Int, w: Float, color: Int, align: Paint.Align) {
        val x0 = when (align) { Paint.Align.LEFT -> x; Paint.Align.RIGHT -> x - w; else -> x - w / 2f }
        val a = (color ushr 24) and 255
        if (PC.luma(color) > 70 && a > 40) {
            fontPaint.color = (((a * 0.65f).toInt()) shl 24) or 0x0A0814
            PixelFont.draw(c, fontPaint, s, x0 + lp, y + lp, k)
        }
        fontPaint.color = color
        PixelFont.draw(c, fontPaint, s, x0, y, k)
    }

    /** Texto con fuente de píxeles. [size] se interpreta como el tamaño de fuente clásico (px de referencia); nunca se sale de la pantalla. */
    fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Palette.WHITE, align: Paint.Align = Paint.Align.LEFT) {
        var k = PixelFont.scaleFor(size)
        var w = PixelFont.width(s, k)
        val maxW = when (align) { Paint.Align.LEFT -> Ref.W - x - 6f; Paint.Align.RIGHT -> x - 6f; else -> 2f * minOf(x, Ref.W - x) - 12f }
        while (k > 1 && w > maxW) { k--; w = PixelFont.width(s, k) }
        drawPix(c, s, x, y, k, w, color, align)
    }

    fun textFit(c: Canvas, s: String, x: Float, y: Float, size: Float, maxW: Float, color: Int, align: Paint.Align) {
        var k = PixelFont.scaleFor(size)
        var w = PixelFont.width(s, k)
        while (k > 1 && w > maxW) { k--; w = PixelFont.width(s, k) }
        drawPix(c, s, x, y, k, w, color, align)
    }

    /** Caja pixelada: borde de 2 px lógicos con esquinas cortadas, luz arriba y sombra abajo. */
    fun pbox(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int, border: Int) {
        val sx = PX.snap(x); val sy = PX.snap(y); val sw = PX.snap(w); val sh = PX.snap(h)
        val n = lp * 2f
        fill.color = border
        c.drawRect(sx + n, sy, sx + sw - n, sy + sh, fill)
        c.drawRect(sx, sy + n, sx + sw, sy + sh - n, fill)
        fill.color = color
        c.drawRect(sx + n, sy + n, sx + sw - n, sy + sh - n, fill)
        c.drawRect(sx + lp, sy + n, sx + n, sy + sh - n, fill)
        c.drawRect(sx + sw - n, sy + n, sx + sw - lp, sy + sh - n, fill)
        fill.color = withAlpha(Palette.WHITE, 30)
        c.drawRect(sx + n, sy + n, sx + sw - n, sy + n + lp, fill)
        fill.color = withAlpha(0xFF000000.toInt(), 55)
        c.drawRect(sx + n, sy + sh - n - lp, sx + sw - n, sy + sh - n, fill)
    }

    fun panel(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int = Palette.PANEL, border: Int = Palette.PANEL_LIGHT, r: Float = 18f) {
        pbox(c, x, y, w, h, color, border)
    }

    fun button(c: Canvas, b: Btn, pressed: Boolean) {
        val off = if (pressed) lp * 3f else 0f
        var base = when (b.style) { 0 -> Palette.ACCENT; 2 -> Palette.RED; else -> Palette.PANEL_LIGHT }
        if (!b.enabled) base = withAlpha(base, 80)
        pbox(c, b.x, b.y + lp * 4f, b.w, b.h, darken(base, 0.55f), 0xFF0A0814.toInt())
        pbox(c, b.x, b.y + off, b.w, b.h - lp * 2f, base, darken(base, 0.45f))
        val fg = if (!b.enabled) Palette.TEXT_DIM else if (b.style == 0) Palette.BG else Palette.WHITE
        if (b.icon >= 0) icon(c, b.icon, b.x + b.w / 2f, b.y + b.h / 2f + off, b.h * 0.22f, fg)
        else textFit(c, b.label, b.x + b.w / 2f, b.y + b.h * 0.64f + off, b.h * 0.42f, b.w - 24f, fg, Paint.Align.CENTER)
    }

    fun icon(c: Canvas, kind: Int, cx: Float, cy: Float, s: Float, color: Int) {
        fill.color = color; path.reset()
        when (kind) {
            ICON_LEFT -> { path.moveTo(cx + s * 0.6f, cy - s); path.lineTo(cx - s * 0.7f, cy); path.lineTo(cx + s * 0.6f, cy + s) }
            ICON_RIGHT -> { path.moveTo(cx - s * 0.6f, cy - s); path.lineTo(cx + s * 0.7f, cy); path.lineTo(cx - s * 0.6f, cy + s) }
            ICON_UP -> { path.moveTo(cx - s, cy + s * 0.6f); path.lineTo(cx, cy - s * 0.7f); path.lineTo(cx + s, cy + s * 0.6f) }
            else -> { path.moveTo(cx - s, cy - s * 0.6f); path.lineTo(cx, cy + s * 0.7f); path.lineTo(cx + s, cy - s * 0.6f) }
        }
        path.close(); c.drawPath(path, fill)
    }

    /** Barra segmentada estilo videojuego. */
    fun bar(c: Canvas, x: Float, y: Float, w: Float, h: Float, frac: Float, color: Int) {
        val sx = PX.snap(x); val sy = PX.snap(y); val sw = PX.snap(w); val sh = maxOf(lp * 3f, PX.snap(h))
        fillRect(c, sx, sy, sw, sh, 0xFF0A0814.toInt())
        fillRect(c, sx + lp, sy + lp, sw - lp * 2f, sh - lp * 2f, withAlpha(Palette.WHITE, 26))
        val fw = PX.snap((sw - lp * 2f) * frac.coerceIn(0f, 1f))
        if (fw > 0f) {
            fillRect(c, sx + lp, sy + lp, fw, sh - lp * 2f, color)
            fillRect(c, sx + lp, sy + lp, fw, lp, withAlpha(Palette.WHITE, 90))
            fillRect(c, sx + lp, sy + sh - lp * 2f, fw, lp, withAlpha(0xFF000000.toInt(), 60))
        }
        var t = 1
        while (t < 10) { fillRect(c, sx + sw * t / 10f, sy + lp, lp * 0.75f, sh - lp * 2f, withAlpha(0xFF000000.toInt(), 70)); t++ }
    }

    fun header(c: Canvas, title: String, right: String = "") {
        fillRect(c, 0f, 0f, Ref.W, 76f, Palette.BG2)
        fillRect(c, 0f, 72f, Ref.W, lp * 3f, Palette.ACCENT)
        fillRect(c, 0f, 72f + lp * 3f, Ref.W, lp, withAlpha(0xFF000000.toInt(), 90))
        text(c, title, 24f, 54f, 38f, Palette.WHITE)
        if (right.isNotEmpty()) textFit(c, right, Ref.W - 24f, 50f, 26f, 300f, Palette.GOLD, Paint.Align.RIGHT)
    }

    fun statRow(c: Canvas, x: Float, y: Float, w: Float, label: String, value: String) {
        text(c, label, x, y, 26f, Palette.TEXT_DIM)
        text(c, value, x + w, y, 28f, Palette.WHITE, Paint.Align.RIGHT)
        fillRect(c, x, y + 10f, w, lp, withAlpha(Palette.WHITE, 28))
    }

    fun badge(c: Canvas, cx: Float, cy: Float, r: Float, primary: Int, secondary: Int, abbr: String) {
        // escudo pixelado: cuadrado con esquinas cortadas, borde y franja
        val u = lp * 2f
        val sx = PX.snap(cx - r); val sy = PX.snap(cy - r); val d = PX.snap(r * 2f)
        pbox(c, sx, sy, d, d, primary, secondary)
        fillRect(c, sx + u, sy + d * 0.62f, d - u * 2f, lp * 2f, withAlpha(secondary, 200))
        text(c, abbr, cx, cy + r * 0.2f, r * 0.62f, if (PC.luma(primary) > 150) 0xFF111111.toInt() else Palette.WHITE, Paint.Align.CENTER)
    }

    fun ball(c: Canvas, x: Float, y: Float, r: Float, spin: Float) {
        val n = if (r < 14f) 12 else if (r < 30f) 16 else 32
        val rot = Math.floorMod((spin / 6.2832f * PixelBall.ROT_STEPS).toInt(), PixelBall.ROT_STEPS)
        PixelBall.draw(c, PX.snap(x), PX.snap(y), r * 2f, n, rot)
    }

    private val lookCache = HashMap<Long, Look>()

    /** Figura de persona (pies en x,y). s = escala clásica (83 unidades de alto x s), facing = 1 derecha / -1 izquierda. */
    fun figure(
        c: Canvas, x: Float, y: Float, s: Float, skin: Int, hair: Int, hairStyle: Int,
        shirt: Int, shorts: Int, accent: Int, facing: Float, phase: Float, moving: Boolean, jump: Float = 0f
    ) {
        var kk = 17L
        for (v in intArrayOf(skin, hair, hairStyle, shirt, shorts, accent)) kk = kk * 1000003L + v
        val look = lookCache.getOrPut(kk) { Looks.menu(skin, hair, hairStyle, shirt, shorts, accent) }
        val targetLogical = 83f * s * 0.75f
        val pose = if (moving) Poses.runFrame(phase) else if (jump > 1f) Poses.CELEBRATE else Poses.IDLE
        if (targetLogical >= 62f) {
            val mul = maxOf(1, Math.round(targetLogical / Humans.T_PORTRAIT))
            Humans.draw(c, look, 1, pose, x, y, Humans.T_PORTRAIT, mul, jump * s)
        } else {
            val tier = if (targetLogical < 34f) Humans.T_SMALL else if (targetLogical < 43f) Humans.T_MID else Humans.T_BIG
            Humans.draw(c, look, if (facing >= 0f) 2 else 3, pose, x, y, tier, 1, jump * s)
        }
    }

    fun player(c: Canvas, x: Float, y: Float, s: Float, a: Appearance, shirt: Int, shorts: Int, facing: Float, phase: Float, moving: Boolean, jump: Float = 0f) {
        figure(
            c, x, y, s, Appearance.SKINS[a.skin], Appearance.HAIRS[a.hair], a.hairStyle, shirt, shorts,
            Appearance.ACCENTS[a.shirt], facing, phase, moving, jump
        )
    }

    fun opponent(c: Canvas, x: Float, y: Float, s: Float, shirt: Int, shorts: Int, facing: Float, phase: Float, moving: Boolean) {
        figure(c, x, y, s, 0xFFD9A77F.toInt(), 0xFF2A1A10.toInt(), 0, shirt, shorts, darken(shirt, 0.7f), facing, phase, moving)
    }

    fun absf(v: Float) = abs(v)
}
