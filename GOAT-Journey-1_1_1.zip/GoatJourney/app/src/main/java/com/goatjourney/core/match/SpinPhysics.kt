package com.goatjourney.core.match

import kotlin.math.*

/** Vector 3D mínimo (solo lo necesario para torque y Magnus). */
class Vec3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun times(k: Float) = Vec3(x * k, y * k, z * k)
    fun cross(o: Vec3) = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun len() = sqrt(x * x + y * y + z * z)
}

/**
 * Velocidad angular del balón (rad/s) en el MARCO DE CAMPO P (diestro):
 *   x = ancho del mundo (derecha en pantalla), y = largo del mundo (hacia la portería rival), z = arriba.
 * Relación con las coordenadas del juego: P(x, y, z) = (world.y, world.x, altura).
 * El spin es inercial (pertenece al balón): no depende de la pantalla ni de la dirección en que se mire.
 */
class Spin(val wx: Float, val wy: Float, val wz: Float) {
    fun mag() = sqrt(wx * wx + wy * wy + wz * wz)
    fun scaled(k: Float) = Spin(wx * k, wy * k, wz * k)
    companion object { val ZERO = Spin(0f, 0f, 0f) }
}

/**
 * Modelo de contacto -> spin -> curvatura.
 *
 *   punto de contacto (nx, ny) en el balón  ->  r  (centro -> punto, en el marco local del golpeo)
 *   dirección + potencia                    ->  F  (a lo largo de la dirección del golpeo)
 *   torque = r x F                          ->  spin (velocidad angular inicial)
 *   Magnus: a = ½ρA/m · CL(S) · v² · (ω x v)/(|ω||v|)   con S = ωR/|v|   (∝ spin x velocidad para S pequeño)
 *
 * Marco local del golpeo (derecho, ortonormal): u = derecha del recorrido, f = dirección del golpeo (con su elevación), w = u x f.
 * La pantalla NO decide hacia dónde curva: lo decide el spin respecto a la velocidad.
 */
object SpinModel {
    const val BALL_R = 0.11f          // radio del balón (m)
    const val STRIKE_EFF = 0.30f      // fracción del torque ideal que llega a ser spin (el pie resbala)
    const val W_MAX = 100f            // spin máximo físico (rad/s)
    const val VERT_FACTOR = 0.30f     // el contacto vertical genera menos spin que el lateral (el empeine "levanta" más de lo que "gira")
    const val MAG_K = 0.0530f         // ½·ρ·A/m  (1/m)
    const val CL_MAX = 0.30f          // saturación del coeficiente de sustentación
    const val S0 = 0.30f              // escala del parámetro de spin
    const val SPIN_DECAY = 0.35f      // el spin se pierde progresivamente en vuelo (1/s)

    /**
     * Spin inicial. [dir] = dirección horizontal del golpeo (mundo), [elev] = elevación (rad), [speed] = velocidad de salida,
     * [scale] = calidad técnica (atributos) que modula el spin máximo alcanzable.
     */
    fun spinFor(nx: Float, ny: Float, dir: Vec, elev: Float, speed: Float, scale: Float): Spin {
        if (abs(nx) < 1e-4f && abs(ny) < 1e-4f) return Spin.ZERO
        // el pie golpea la cara trasera del balón: la profundidad sale de la esfera unidad
        val depth = sqrt(max(0f, 1f - nx * nx - ny * ny))
        val r = Vec3(nx, -depth, ny * VERT_FACTOR)
        val f = Vec3(0f, 1f, 0f)                       // fuerza unitaria a lo largo del golpeo
        val torque = r.cross(f)                        // r x F
        val k = 1.5f * STRIKE_EFF * speed / BALL_R * scale   // esfera hueca: ω = 1.5·η·v·offset/R
        // base local expresada en el marco de campo P
        val n = dir.norm()
        val hx = n.y; val hy = n.x                     // dirección horizontal en P
        val ce = cos(elev); val se = sin(elev)
        val f3 = Vec3(ce * hx, ce * hy, se)
        val u3 = Vec3(hy, -hx, 0f)                     // derecha del recorrido
        val w3 = u3.cross(f3)
        var w = u3 * (torque.x * k) + f3 * (torque.y * k) + w3 * (torque.z * k)
        val m = w.len()
        if (m > W_MAX) w = w * (W_MAX / m)
        return Spin(w.x, w.y, w.z)
    }

    /** Elevación continua según el contacto vertical: abajo = lift, centro = natural, arriba = rasante. ny > 0 = parte superior. */
    fun elevation(base: Float, liftRange: Float, minE: Float, maxE: Float, ny: Float): Float {
        val lift = -ny
        val e = base + (if (lift >= 0f) liftRange * lift else lift * max(base, 0.10f) * 0.9f)
        return e.coerceIn(minE, maxE)
    }

    /** Aceleración de Magnus (marco P) para spin [w] y velocidad P [v]. */
    fun magnus(wx: Float, wy: Float, wz: Float, pvx: Float, pvy: Float, pvz: Float): Vec3 {
        val w = sqrt(wx * wx + wy * wy + wz * wz)
        val v2 = pvx * pvx + pvy * pvy + pvz * pvz
        if (w < 0.5f || v2 < 1f) return Vec3(0f, 0f, 0f)
        val v = sqrt(v2)
        val cx = wy * pvz - wz * pvy
        val cy = wz * pvx - wx * pvz
        val cz = wx * pvy - wy * pvx
        val s = w * BALL_R / v
        val cl = CL_MAX * (1f - exp(-s / S0))
        val f = MAG_K * cl * v2 / (w * v)
        return Vec3(cx * f, cy * f, cz * f)
    }

    /** Descripción para la interfaz: lo que hará el balón con este contacto (relativo al recorrido). */
    fun describe(nx: Float, ny: Float): String {
        val side = when {
            abs(nx) < 0.10f -> ""
            nx > 0f -> "curva a la izquierda"
            else -> "curva a la derecha"
        }
        val vert = when {
            ny < -0.10f -> "elevado"
            ny > 0.10f -> "rasante"
            else -> ""
        }
        return when {
            side.isEmpty() && vert.isEmpty() -> "golpe limpio, recto"
            side.isEmpty() -> vert
            vert.isEmpty() -> side
            else -> "$vert y $side"
        }
    }
}
