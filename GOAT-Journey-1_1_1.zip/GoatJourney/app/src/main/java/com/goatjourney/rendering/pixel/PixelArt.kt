package com.goatjourney.rendering.pixel

import kotlin.math.*

/**
 * Base del pixel art de GOAT Journey.
 *
 * Resolución lógica: 540x960 píxeles lógicos sobre el espacio de referencia 720x1280 => 1 píxel lógico = 4/3 px de referencia.
 * Todo el arte (sprites, fuente, balón, paneles) se dibuja en múltiplos de esa unidad y SIN filtrado (nearest-neighbor / sin antialias).
 */
object PX {
    const val LP = 4f / 3f
    const val LOGICAL_W = 540f
    const val LOGICAL_H = 960f

    /** Ajusta una coordenada de referencia a la rejilla de píxeles lógicos. */
    fun snap(v: Float): Float = Math.round(v / LP) * LP
}

/** Utilidades de color (ARGB). */
object PC {
    fun r(c: Int) = (c shr 16) and 255
    fun g(c: Int) = (c shr 8) and 255
    fun b(c: Int) = c and 255

    fun pack(r: Float, g: Float, b: Float): Int {
        val ri = r.coerceIn(0f, 255f).toInt(); val gi = g.coerceIn(0f, 255f).toInt(); val bi = b.coerceIn(0f, 255f).toInt()
        return (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
    }

    fun shade(c: Int, f: Float): Int = pack(r(c) * f, g(c) * f, b(c) * f)

    fun mix(c0: Int, c1: Int, t: Float): Int =
        pack(r(c0) + (r(c1) - r(c0)) * t, g(c0) + (g(c1) - g(c0)) * t, b(c0) + (b(c1) - b(c0)) * t)

    /** 4 tonos de un color base: 0 luz, 1 base, 2 sombra, 3 sombra profunda (ligeramente azulada, estilo pixel art). */
    fun tones(c: Int): IntArray = intArrayOf(
        mix(c, 0xFFFFFFFF.toInt(), 0.20f),
        c,
        mix(shade(c, 0.72f), 0xFF1A1030.toInt(), 0.10f),
        mix(shade(c, 0.50f), 0xFF140C28.toInt(), 0.20f)
    )

    fun luma(c: Int): Int = (r(c) * 3 + g(c) * 6 + b(c)) / 10
}

/** Búfer de píxeles pequeño con primitivas de rasterizado sin antialias (cápsulas, polígonos, elipses). */
class PixBuf(val w: Int, val h: Int) {
    val c = IntArray(w * h)
    val g = IntArray(w * h)

    fun get(x: Int, y: Int): Int = if (x in 0 until w && y in 0 until h) c[y * w + x] else 0
    fun grp(x: Int, y: Int): Int = if (x in 0 until w && y in 0 until h) g[y * w + x] else -1
    fun put(x: Int, y: Int, col: Int, grp: Int) {
        if (x in 0 until w && y in 0 until h) { c[y * w + x] = col; g[y * w + x] = grp }
    }

    /** Línea gruesa con radio variable. Sombreado de 3 tonos con luz arriba-izquierda; [sep] marca una línea oscura sobre otros grupos. */
    fun capsule(
        ax: Float, ay: Float, bx: Float, by: Float, ra: Float, rb: Float,
        col: Int, grp: Int, lit: Boolean = true, sep: Boolean = true
    ) {
        val t = PC.tones(col)
        val m = max(ra, rb)
        val x0 = floor(min(ax, bx) - m - 2f).toInt(); val x1 = ceil(max(ax, bx) + m + 2f).toInt()
        val y0 = floor(min(ay, by) - m - 2f).toInt(); val y1 = ceil(max(ay, by) + m + 2f).toInt()
        val dx = bx - ax; val dy = by - ay; val l2 = dx * dx + dy * dy
        for (pass in 0..1) {
            if (pass == 1 && !sep) break
            for (y in y0..y1) for (x in x0..x1) {
                val px = x + 0.5f; val py = y + 0.5f
                val tt = if (l2 < 1e-6f) 0f else (((px - ax) * dx + (py - ay) * dy) / l2).coerceIn(0f, 1f)
                val qx = ax + dx * tt; val qy = ay + dy * tt
                val r = ra + (rb - ra) * tt
                val ox = px - qx; val oy = py - qy
                val d = hypot(ox, oy)
                if (pass == 0) {
                    if (d <= r) {
                        val s = (ox * -0.7f + oy * -0.7f) / max(r, 0.5f)
                        val cc = if (!lit) t[1] else if (s > 0.38f) t[0] else if (s < -0.30f) t[2] else t[1]
                        put(x, y, cc, grp)
                    }
                } else if (d > r && d <= r + 0.95f) {
                    val gg = grp(x, y)
                    val cur = get(x, y)
                    if (cur != 0 && gg != grp && gg != -1) put(x, y, PC.shade(cur, 0.55f), gg)
                }
            }
        }
    }

    /** Polígono (par-impar). [shader] decide el color por píxel; si es null usa el tono base. */
    fun poly(xs: FloatArray, ys: FloatArray, col: Int, grp: Int, shader: ((Int, Int, IntArray) -> Int)?) {
        val t = PC.tones(col)
        var minX = xs[0]; var maxX = xs[0]; var minY = ys[0]; var maxY = ys[0]
        for (i in xs.indices) { minX = min(minX, xs[i]); maxX = max(maxX, xs[i]); minY = min(minY, ys[i]); maxY = max(maxY, ys[i]) }
        val n = xs.size
        for (y in floor(minY).toInt()..ceil(maxY).toInt()) for (x in floor(minX).toInt()..ceil(maxX).toInt()) {
            val px = x + 0.5f; val py = y + 0.5f
            var inside = false
            var j = n - 1
            for (i in 0 until n) {
                val xi = xs[i]; val yi = ys[i]; val xj = xs[j]; val yj = ys[j]
                if ((yi > py) != (yj > py) && px < (xj - xi) * (py - yi) / (yj - yi + 1e-9f) + xi) inside = !inside
                j = i
            }
            if (inside) put(x, y, if (shader == null) t[1] else shader(x, y, t), grp)
        }
    }

    fun ellipse(cx: Float, cy: Float, rx: Float, ry: Float, col: Int, grp: Int, lit: Boolean = true) {
        val t = PC.tones(col)
        for (y in (cy - ry - 2f).toInt()..(cy + ry + 3f).toInt()) for (x in (cx - rx - 2f).toInt()..(cx + rx + 3f).toInt()) {
            val px = x + 0.5f - cx; val py = y + 0.5f - cy
            val d = (px / rx) * (px / rx) + (py / ry) * (py / ry)
            if (d <= 1f) {
                val s = (px / rx * -0.7f + py / ry * -0.7f)
                var cc = t[1]
                if (lit) { if (s > 0.55f) cc = t[0] else if (s < -0.45f) cc = t[2] }
                put(x, y, cc, grp)
            }
        }
    }
}
