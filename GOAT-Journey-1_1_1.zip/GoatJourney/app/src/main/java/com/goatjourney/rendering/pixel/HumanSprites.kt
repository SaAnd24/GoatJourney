package com.goatjourney.rendering.pixel

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.*

/** Aspecto de una persona: rasgos + equipación. Todo derivable de forma estable (sin guardar nada nuevo en la partida). */
class Look(
    val skin: Int, val hair: Int, val hairStyle: Int, val beard: Int = 0, val brow: Int = 1,
    val build: Int = 1, val heightF: Float = 1f, val jaw: Int = 1,
    val shirt: Int, val shirt2: Int, val pattern: Int = 0, val shorts: Int, val shorts2: Int,
    val socks: Int, val socks2: Int, val boots: Int = 0xFF15151C.toInt(),
    val number: Int = 9, val keeper: Boolean = false, val glove: Int = 0xFFFFD24A.toInt(), val longSleeves: Boolean = false
) {
    val key: Int by lazy {
        var h = 17
        for (v in intArrayOf(skin, hair, hairStyle, beard, brow, build, (heightF * 100).toInt(), jaw, shirt, shirt2, pattern, shorts, shorts2, socks, socks2, boots, number, if (keeper) 1 else 0, glove, if (longSleeves) 1 else 0))
            h = h * 31 + v
        h
    }
}

/** Pose: ángulos en radianes (adelante positivo). */
class Pose(
    val lean: Float = 0f, val thL: Float = 0f, val thR: Float = 0f, val flL: Float = 0f, val flR: Float = 0f,
    val abL: Float = 0f, val abR: Float = 0f, val arL: Float = 0f, val arR: Float = 0f,
    val abaL: Float = 0.15f, val abaR: Float = 0.15f, val elL: Float = 0.3f, val elR: Float = 0.3f,
    val crouch: Float = 0f, val lift: Float = 0f, val headTilt: Float = 0f, val mouth: Int = 0
)

object Poses {
    const val IDLE = 0; const val IDLE2 = 1; const val RUN0 = 2 /* 2..7 */; const val KICK_WIND = 8; const val KICK_STRIKE = 9
    const val KICK_FOLLOW = 10; const val CELEBRATE = 11; const val CELEBRATE2 = 12; const val SLUMP = 13; const val PROTEST = 14
    const val HEADER = 15; const val KEEPER = 16
    const val COUNT = 17

    private fun run(p: Float): Pose {
        val a = 2f * PI.toFloat() * p
        val amp = 0.75f; val arm = 0.7f
        fun fl(ph: Float) = 0.25f + max(0f, cos(ph)) * 0.9f
        return Pose(
            lean = 0.12f, thL = amp * sin(a), thR = amp * sin(a + PI.toFloat()), flL = fl(a), flR = fl(a + PI.toFloat()),
            arL = -arm * sin(a), arR = -arm * sin(a + PI.toFloat()), elL = 0.9f, elR = 0.9f, abaL = 0.12f, abaR = 0.12f,
            lift = 0.012f * abs(sin(a * 2f))
        )
    }

    private val table: Array<Pose> by lazy {
        Array(COUNT) { id ->
            when (id) {
                IDLE -> Pose(thL = 0.03f, thR = -0.03f, arL = 0.05f, arR = -0.05f, flL = 0.04f, flR = 0.04f)
                IDLE2 -> Pose(thL = 0.03f, thR = -0.03f, arL = 0.05f, arR = -0.05f, flL = 0.04f, flR = 0.04f, crouch = 0.006f, abaL = 0.2f, abaR = 0.2f)
                in RUN0..RUN0 + 5 -> run((id - RUN0) / 6f)
                KICK_WIND -> Pose(lean = -0.10f, thL = 0.1f, thR = -0.85f, flL = 0.12f, flR = 1.35f, arL = 0.7f, arR = -0.5f, elL = 0.5f, elR = 0.5f, abaL = 0.6f, abaR = 0.35f)
                KICK_STRIKE -> Pose(lean = 0.05f, thL = -0.1f, thR = 0.75f, flL = 0.30f, flR = 0.12f, arL = -0.6f, arR = 0.55f, elL = 0.4f, elR = 0.5f, abaL = 0.5f, abaR = 0.4f, crouch = 0.015f)
                KICK_FOLLOW -> Pose(lean = -0.10f, thL = -0.05f, thR = 1.20f, flL = 0.20f, flR = 0.35f, arL = -0.7f, arR = 0.8f, elL = 0.5f, elR = 0.5f, abaL = 0.7f, abaR = 0.5f, lift = 0.02f)
                CELEBRATE -> Pose(lean = -0.05f, thL = 0.15f, thR = -0.12f, flL = 0.5f, flR = 0.5f, arL = 2.9f, arR = 2.9f, elL = 0.15f, elR = 0.15f, abaL = 0.35f, abaR = 0.35f, lift = 0.06f, mouth = 2)
                CELEBRATE2 -> Pose(lean = -0.03f, thL = 0.05f, thR = -0.05f, flL = 0.2f, flR = 0.2f, arL = 2.7f, arR = 2.7f, elL = 0.3f, elR = 0.3f, abaL = 0.55f, abaR = 0.55f, mouth = 2)
                SLUMP -> Pose(lean = 0.22f, thL = 0.05f, thR = -0.05f, flL = 0.08f, flR = 0.08f, arL = 1.9f, arR = 1.9f, elL = 2.0f, elR = 2.0f, abaL = 0.2f, abaR = 0.2f, headTilt = 0.25f)
                PROTEST -> Pose(thL = 0.04f, thR = -0.04f, flL = 0.05f, flR = 0.05f, arL = 0.6f, arR = 0.6f, elL = 1.1f, elR = 1.1f, abaL = 0.9f, abaR = 0.9f, mouth = 2)
                HEADER -> Pose(lean = 0.30f, thL = 0.7f, thR = -0.2f, flL = 1.0f, flR = 0.7f, arL = 0.9f, arR = -0.6f, elL = 0.5f, elR = 0.5f, abaL = 0.8f, abaR = 0.8f, lift = 0.09f)
                else -> Pose(lean = 0.12f, thL = 0.35f, thR = 0.35f, flL = 0.7f, flR = 0.7f, arL = 0.5f, arR = 0.5f, elL = 0.7f, elR = 0.7f, abaL = 0.9f, abaR = 0.9f, crouch = 0.03f, abL = 0.18f, abR = 0.18f)
            }
        }
    }

    fun of(id: Int): Pose = table[id.coerceIn(0, COUNT - 1)]
    /** Fotograma de carrera para una fase continua. */
    fun runFrame(phase: Float): Int = RUN0 + Math.floorMod((phase * 6f / (2f * PI.toFloat())).toInt(), 6)
}

/** Vistas: 0 = de espalda (mira hacia arriba), 1 = de frente (mira hacia abajo), 2 = de perfil derecho (el izquierdo se espeja). */
object HumanRaster {
    private val OUT_C = 0xFF120E1C.toInt()
    private val DIG = mapOf(
        '0' to "111101101101111", '1' to "010110010010111", '2' to "111001111100111", '3' to "111001111001111",
        '4' to "101101111001001", '5' to "111100111001111", '6' to "111100111101111", '7' to "111001010010010",
        '8' to "111101111101111", '9' to "111101111001111"
    )

    class Sprite(val w: Int, val h: Int, val px: IntArray)

    fun render(look: Look, view: Int, pose: Pose, H: Int): Sprite {
        val W = (Math.round(H * 0.86f) / 2) * 2 + 2
        val b = PixBuf(W, H)
        val cx = W / 2f
        val S = H * 0.94f * look.heightF
        val ground = H - 1.5f
        val bw = when (look.build) { 0 -> 0.90f; 1 -> 1.0f; 2 -> 1.12f; else -> 1.14f }
        val sw = 0.118f * bw
        val hw = 0.062f * (0.95f + 0.05f * bw)
        val lThigh = 0.245f; val lShin = 0.235f; val lFt = 0.085f; val lUa = 0.150f; val lFa = 0.140f; val lTorso = 0.295f
        val hipY = 0.515f - pose.crouch
        val lean = pose.lean
        val p0y = hipY + pose.lift
        // piernas: cadera, rodilla, tobillo (x lateral, y arriba, z adelante)
        class Leg(val hx: Float, val hy: Float, val hz: Float, val kx: Float, val ky: Float, val kz: Float, val ax: Float, val ay: Float, val az: Float)
        fun leg(side: Float, th: Float, fl: Float, ab: Float): Leg {
            val hx = side * hw * 1.05f
            val kx = hx + side * sin(ab) * lThigh
            val ky = p0y - lThigh * cos(th) * cos(ab)
            val kz = lThigh * sin(th)
            val th2 = th - fl
            val ax = kx + side * sin(ab * 0.6f) * lShin
            val ay = ky - lShin * cos(th2)
            val az = kz + lShin * sin(th2)
            return Leg(hx, p0y, 0f, kx, ky, kz, ax, ay, az)
        }
        val legR = leg(1f, pose.thR, pose.flR, pose.abR)
        val legL = leg(-1f, pose.thL, pose.flL, pose.abL)
        val low = min(legR.ay, legL.ay)
        val shift = if (pose.lift < 0.001f) 0.035f - low else (if (low < 0.035f) 0.035f - low else 0f)
        val p0 = floatArrayOf(0f, p0y + shift, 0f)
        val s3 = floatArrayOf(0f, p0[1] + lTorso * cos(lean), p0[2] + lTorso * sin(lean))

        fun projX(x: Float, z: Float): Float = when (view) { 1 -> cx - x * S; 0 -> cx + x * S; else -> cx + z * S }
        fun projY(y: Float, z: Float): Float = when (view) { 1 -> ground - y * S + z * S * 0.18f; 0 -> ground - y * S - z * S * 0.18f; else -> ground - y * S }
        fun depthZ(z: Float): Float = if (view == 1) z else if (view == 0) -z else 0f

        class Prim(val key: Float, val draw: () -> Unit)
        val prims = ArrayList<Prim>()
        val skin = look.skin
        val shirt = look.shirt; val sh2 = look.shirt2
        val rLeg = 0.052f * bw; val rKnee = 0.040f; val rAnk = 0.028f

        // ---- piernas
        for (nm in 0..1) {
            val lg = if (nm == 0) legL else legR
            val side = if (nm == 0) -1f else 1f
            val hx = projX(lg.hx, lg.hz); val hy = projY(lg.hy + shift, lg.hz)
            val kx = projX(lg.kx, lg.kz); val ky = projY(lg.ky + shift, lg.kz)
            val ax = projX(lg.ax, lg.az); val ay = projY(lg.ay + shift, lg.az)
            val tx = projX(lg.ax, lg.az + lFt); val ty = projY(lg.ay + shift - 0.020f, lg.az + lFt)
            val gb = if (nm == 0) 0 else 1
            val key = if (view == 2) side * 0.5f else depthZ((lg.az + lg.kz) / 2f)
            prims.add(Prim(key) {
                b.capsule(hx, hy, kx, ky, rLeg * S, rKnee * S, skin, 10 + gb)
                val qx = hx + (kx - hx) * 0.60f; val qy = hy + (ky - hy) * 0.60f
                b.capsule(hx, hy - 0.01f * S, qx, qy, rLeg * S * 1.12f, rLeg * S * 0.98f, look.shorts, 12 + gb, sep = false)
                b.capsule(kx, ky, ax, ay, rKnee * S * 0.98f, rAnk * S * 1.1f, look.socks, 14 + gb)
                val bx = kx + (ax - kx) * 0.30f; val by = ky + (ay - ky) * 0.30f
                b.capsule(kx, ky + 0.5f, bx, by, rKnee * S, rKnee * S * 0.98f, look.socks2, 14, lit = false, sep = false)
                b.capsule(ax, ay - 0.01f * S, tx, ty, 0.032f * S, 0.026f * S, look.boots, 16 + gb)
            })
        }
        // ---- brazos
        for (nm in 0..1) {
            val side = if (nm == 0) -1f else 1f
            val ar = if (nm == 0) pose.arL else pose.arR
            val el = if (nm == 0) pose.elL else pose.elR
            val ab = if (nm == 0) pose.abaL else pose.abaR
            val sx0 = side * sw; val sy0 = s3[1] - 0.025f * cos(lean); val sz0 = s3[2]
            val ex0 = sx0 + side * sin(ab) * lUa; val ey0 = sy0 - lUa * cos(ar); val ez0 = sz0 + lUa * sin(ar)
            val ar2 = ar + el
            val hx0 = ex0 + side * sin(ab * 0.5f) * lFa; val hy0 = ey0 - lFa * cos(ar2); val hz0 = ez0 + lFa * sin(ar2)
            val psx = projX(sx0, sz0); val psy = projY(sy0, sz0)
            val pex = projX(ex0, ez0); val pey = projY(ey0, ez0)
            val phx = projX(hx0, hz0); val phy = projY(hy0, hz0)
            val gb = if (nm == 0) 0 else 1
            val key = if (view == 2) side * 0.9f else depthZ(hz0)
            prims.add(Prim(key) {
                val longs = look.longSleeves || look.keeper
                b.capsule(pex, pey, phx, phy, 0.030f * S * sqrt(bw), 0.026f * S, if (longs) shirt else skin, 20 + gb)
                b.capsule(psx, psy, pex, pey, 0.034f * S * bw.pow(0.6f), 0.030f * S * sqrt(bw), shirt, 22 + gb)
                val qx = psx + (pex - psx) * 0.90f; val qy = psy + (pey - psy) * 0.90f
                b.capsule(qx, qy, pex, pey, 0.030f * S, 0.029f * S, sh2, 22 + gb, lit = false, sep = false)
                val gc = if (look.keeper) look.glove else skin
                b.capsule(phx, phy, phx + (phx - pex) * 0.25f, phy + (phy - pey) * 0.25f + 0.5f, 0.026f * S, 0.022f * S, gc, 24 + gb)
            })
        }
        // ---- torso
        prims.add(Prim(0f) {
            val psx = projX(0f, s3[2]); val psy = projY(s3[1], s3[2])
            val p0x = projX(0f, p0[2]); val p0yy = projY(p0[1], p0[2])
            var shLx = projX(-sw, s3[2]); var shLy = projY(s3[1] - 0.02f, s3[2])
            var shRx = projX(sw, s3[2]); var shRy = projY(s3[1] - 0.02f, s3[2])
            var wLx = projX(-0.082f * bw, p0[2] + 0.05f * sin(lean)); var wLy = projY(p0[1] + 0.05f, p0[2] + 0.05f * sin(lean))
            var wRx = projX(0.082f * bw, p0[2] + 0.05f * sin(lean)); var wRy = wLy
            if (view == 2) {
                val tw = 0.075f * bw
                shLx = psx - tw * S; shLy = psy + 0.02f * S; shRx = psx + tw * S; shRy = shLy
                wLx = p0x - 0.062f * bw * S; wLy = p0yy - 0.04f * S; wRx = p0x + 0.062f * bw * S; wRy = wLy
            }
            val nkw = 0.046f * S
            val xs = floatArrayOf(min(shLx, shRx) - 0.5f, psx - nkw, psx + nkw, max(shLx, shRx) + 0.5f, max(wLx, wRx) + 0.4f, min(wLx, wRx) - 0.4f)
            val ys = floatArrayOf(shLy + 0.012f * S, min(shLy, shRy) - 1.8f, min(shLy, shRy) - 1.8f, shRy + 0.012f * S, wRy + 0.5f, wLy + 0.5f)
            var tl = xs[0]; var tr = xs[0]; var tt = ys[0]; var tb = ys[0]
            for (i in xs.indices) { tl = min(tl, xs[i]); tr = max(tr, xs[i]); tt = min(tt, ys[i]); tb = max(tb, ys[i]) }
            val pat = look.pattern
            val shader = { x: Int, y: Int, _: IntArray ->
                val u = (x + 0.5f - tl) / max(1f, tr - tl); val v = (y + 0.5f - tt) / max(1f, tb - tt)
                val alt = when (pat) {
                    1 -> ((v * (tb - tt)) / max(2f, S * 0.04f)).toInt() % 2 == 1
                    2 -> ((u * (tr - tl)) / max(2f, S * 0.05f)).toInt() % 2 == 1
                    3 -> u > 0.5f
                    4 -> abs((u - 0.5f) - (v - 0.5f) * 0.9f) < 0.14f
                    5 -> v > 0.30f && v < 0.46f
                    else -> false
                }
                val t2 = PC.tones(if (alt) sh2 else shirt)
                if (view == 2) { if (u > 0.78f) t2[2] else if (u < 0.2f) t2[0] else if (v > 0.88f) t2[2] else t2[1] }
                else { if (u < 0.2f) t2[0] else if (u > 0.8f) t2[2] else if (v > 0.88f) t2[2] else t2[1] }
            }
            b.poly(xs, ys, shirt, 30, shader)
            val midX = (shLx + shRx) / 2f
            if (view == 1) {
                for (dx in -2..2) b.put((psx + dx).toInt(), shLy.toInt(), sh2, 30)
                b.put(psx.toInt(), shLy.toInt() + 1, sh2, 30)
            }
            // short (bloque de cadera)
            val hbx = projX(0f, p0[2]); val hby = projY(p0[1] + 0.015f, p0[2])
            val hwid = 0.080f * bw * S
            b.poly(
                floatArrayOf(hbx - hwid, hbx + hwid, hbx + hwid * 1.06f, hbx - hwid * 1.06f),
                floatArrayOf(hby - 0.05f * S, hby - 0.05f * S, hby + 0.045f * S, hby + 0.045f * S), look.shorts, 31, null
            )
            if (view != 2) {
                for (yy in (hby - 0.04f * S).toInt() until (hby + 0.04f * S).toInt()) {
                    b.put((hbx - hwid).toInt(), yy, look.shorts2, 31); b.put((hbx + hwid - 1f).toInt(), yy, look.shorts2, 31)
                }
            }
            // escudo + patrocinador (frente) y dorsal (espalda)
            if (view == 1 && H >= 36) {
                val ccx = (midX - (shRx - shLx) * 0.22f).toInt(); val ccy = (shLy + S * 0.07f).toInt()
                b.put(ccx, ccy, sh2, 30); b.put(ccx + 1, ccy, sh2, 30); b.put(ccx, ccy + 1, sh2, 30); b.put(ccx + 1, ccy + 1, PC.mix(sh2, shirt, 0.3f), 30)
                if (H >= 40) {
                    val sy = (shLy + S * 0.13f).toInt()
                    val band = if (sh2 != 0xFFF2F2F2.toInt()) 0xFFF2F2F2.toInt() else 0xFF222222.toInt()
                    for (xx in (midX - S * 0.07f).toInt() until (midX + S * 0.07f).toInt()) b.put(xx, sy, band, 30)
                }
            }
            if (view == 0 && H >= 40) {
                val s = look.number.coerceIn(0, 99).toString()
                val ox = (midX - (s.length * 4 - 1) / 2f).toInt(); val oy = (shLy + S * 0.07f).toInt()
                val contrast = abs((PC.r(sh2) + PC.g(sh2) + PC.b(sh2)) - (PC.r(shirt) + PC.g(shirt) + PC.b(shirt))) > 150
                val ncol = if (contrast) sh2 else if (PC.r(shirt) + PC.g(shirt) + PC.b(shirt) < 380) 0xFFFFFFFF.toInt() else 0xFF111111.toInt()
                for (i in s.indices) {
                    val bits = DIG[s[i]] ?: continue
                    for (ry in 0 until 5) for (rx in 0 until 3) if (bits[ry * 3 + rx] == '1') b.put(ox + i * 4 + rx, oy + ry, ncol, 30)
                }
            }
        })
        // ---- cuello y cabeza
        prims.add(Prim(if (view == 2) 0.05f else 0.2f) {
            val hcz = s3[2] + 0.032f * sin(lean)
            val pnx = projX(0f, s3[2] + 0.004f); val pny = projY(s3[1] + 0.01f, s3[2] + 0.004f)
            b.capsule(pnx, pny + 0.01f * S, pnx, pny - 0.03f * S, 0.030f * S * sqrt(bw), 0.028f * S, skin, 40, sep = false)
            val hcx0 = projX(0f, hcz); val hcy0 = projY(s3[1] + 0.014f + 0.066f, hcz)
            val hcx = hcx0 + pose.headTilt * S * 0.03f; val hcy = hcy0 + pose.headTilt * S * 0.03f
            val hh = 0.134f * S
            val hwd = if (view == 2) 0.066f * S else (0.064f + 0.004f * look.jaw) * S
            b.ellipse(hcx, hcy, hwd, hh * 0.52f, skin, 41)
            drawFace(b, look, view, hcx, hcy, hwd, hh * 0.52f, H, pose)
        })
        prims.sortBy { it.key }
        for (p in prims) p.draw()
        // contorno exterior
        val out = IntArray(W * H)
        for (i in 0 until W * H) out[i] = b.c[i]
        for (y in 0 until H) for (x in 0 until W) if (b.get(x, y) == 0) {
            if (b.get(x + 1, y) != 0 || b.get(x - 1, y) != 0 || b.get(x, y + 1) != 0 || b.get(x, y - 1) != 0) out[y * W + x] = OUT_C
        }
        return Sprite(W, H, out)
    }

    private fun hairAt(style: Int, view: Int, x: Int, y: Int, cx: Float, cy: Float, rx: Float, ry: Float): Boolean {
        val u = (x + 0.5f - cx) / rx; val v = (y + 0.5f - cy) / ry
        val r = hypot(u, v)
        return when (style) {
            0 -> when (view) {
                1 -> (r < 1.12f && v < -0.46f + 0.30f * u * u) || (r < 1.12f && v < 0.20f && abs(u) > 0.90f)
                0 -> r < 1.12f && v < 0.35f
                else -> r < 1.12f && (v < -0.25f || (u < 0.1f && v < 0.30f))
            }
            1 -> when (view) {
                1 -> (abs(u) < 1.02f && v > -1.28f && v < -0.38f) || (r < 1.1f && v < -0.3f) || (r < 1.1f && v < 0.25f && abs(u) > 0.9f)
                0 -> (abs(u) < 1.02f && v > -1.28f && v < 0.1f) || (r < 1.1f && v < 0.35f)
                else -> (u > -1.0f && u < 1.0f && v > -1.28f && v < -0.3f) || (u < 0.15f && r < 1.1f && v < 0.3f)
            }
            2 -> when (view) {
                1 -> (r < 1.14f && v < -0.28f) || (abs(u) > 0.78f && abs(u) < 1.28f && v > -0.6f && v < 1.9f)
                0 -> abs(u) < 1.28f && v > -1.1f && v < 1.9f && (r < 1.15f || v > 0f)
                else -> (r < 1.14f && v < -0.2f) || (u > -1.35f && u < 0.35f && v > -0.6f && v < 1.8f)
            }
            3 -> false
            4 -> r < 1.42f && (v < 0f || abs(u) > 1.0f) && !(view == 1 && r < 0.95f && v > -0.38f)
            5 -> when (view) {
                1 -> (r < 1.12f && v < -0.35f) || (abs(u) > 0.55f && v < 1.1f && r < 1.35f && Math.floorMod(((u + 2f) * 3f).toInt(), 2) == 0)
                else -> (r < 1.12f && v < 0.2f) || (v < 1.5f && abs(u) < 1.2f && Math.floorMod(((u + 2f) * 3f).toInt(), 2) == 0 && v > -0.3f)
            }
            6 -> {
                if (r < 1.10f && v < -0.28f) true
                else if (hypot(u - (if (view != 2) 0f else -0.35f), v + 1.18f) < 0.52f) true
                else view == 0 && r < 1.1f && v < 0.3f
            }
            7 -> (r < 1.08f && v > -0.1f && v < 0.4f && abs(u) > 0.80f) || (view == 0 && r < 1.08f && v > 0f && v < 0.5f)
            8 -> abs(u) < 0.30f && v > -1.35f && v < 0.3f
            9 -> when (view) {
                1 -> r < 1.12f && v < -0.42f
                0 -> r < 1.12f && v < 0.45f
                else -> (r < 1.14f && v < -0.3f) || (u > -1.3f && u < 0.1f && v < 0.55f)
            }
            else -> false
        }
    }

    private fun drawFace(b: PixBuf, look: Look, view: Int, cx: Float, cy: Float, rx: Float, ry: Float, H: Int, pose: Pose) {
        val skin = look.skin; val hair = look.hair
        val st = PC.tones(skin); val ht = PC.tones(hair)
        val x0 = (cx - rx * 1.6f).toInt(); val x1 = (cx + rx * 1.6f).toInt()
        val y0 = (cy - ry * 1.9f).toInt(); val y1 = (cy + ry * 2.0f).toInt()
        val style = look.hairStyle
        for (y in y0..y1) for (x in x0..x1) if (hairAt(style, view, x, y, cx, cy, rx, ry)) {
            val u = (x + 0.5f - cx) / rx; val v = (y + 0.5f - cy) / ry
            var c = ht[1]
            if (v < -0.6f && u < 0.1f) c = ht[0] else if (u > 0.55f || v > 0.2f) c = ht[2]
            if (Math.floorMod(x * 7 + y * 13, 11) == 0) c = ht[3]
            b.put(x, y, c, 43)
        }
        if (style == 3) {
            for (y in y0..y1) for (x in x0..x1) {
                val u = (x + 0.5f - cx) / rx; val v = (y + 0.5f - cy) / ry
                if (u * u + v * v <= 1f && v < -0.15f && b.get(x, y) != 0) b.put(x, y, PC.mix(b.get(x, y), hair, 0.55f), 42)
            }
        }
        // orejas
        if (view == 1 && H >= 30) {
            for (sgn in intArrayOf(-1, 1)) {
                val ex = (cx + sgn * rx - (if (sgn > 0) 0 else 1)).toInt(); val ey = (cy + ry * 0.05f).toInt()
                b.put(ex, ey, st[2], 42)
                if (H >= 40) b.put(ex, ey + 1, st[2], 42)
            }
        }
        if (view == 2) {
            b.put((cx - rx * 0.15f).toInt(), (cy + ry * 0.05f).toInt(), st[3], 42)
            if (H >= 40) b.put((cx - rx * 0.15f).toInt(), (cy + ry * 0.05f).toInt() + 1, st[2], 42)
        }
        val dark = 0xFF16121C.toInt()
        val mouthC = PC.mix(skin, 0xFF7A2C34.toInt(), 0.55f)
        if (view == 1) {
            val ey = (cy + ry * 0.10f).toInt()
            for (sgn in intArrayOf(-1, 1)) {
                val ex = (cx + sgn * rx * 0.42f).toInt()
                if (H >= 40) { b.put(ex, ey, 0xFFF4F4F4.toInt(), 44); b.put(ex + (if (sgn < 0) 1 else -1), ey, dark, 44) }
                else b.put(ex, ey, dark, 44)
                if (H >= 36 && look.brow > 0) {
                    val bc = if (look.hair != 0xFFE8E8E8.toInt()) ht[3] else 0xFF8A8A8A.toInt()
                    b.put(ex, ey - 1, PC.mix(bc, 0xFF000000.toInt(), 0.2f), 44)
                    if (look.brow > 1) b.put(ex + (if (sgn < 0) 1 else -1), ey - 1, bc, 44)
                }
            }
            if (H >= 36) b.put(cx.toInt(), (cy + ry * 0.40f).toInt(), st[2], 44)
            val my = (cy + ry * 0.66f).toInt()
            if (pose.mouth == 2 && H >= 36) {
                val m2 = 0xFF3A1018.toInt()
                b.put(cx.toInt() - 1, my, m2, 44); b.put(cx.toInt(), my, m2, 44); b.put(cx.toInt() - 1, my + 1, m2, 44)
            } else if (H >= 36) { b.put(cx.toInt() - 1, my, mouthC, 44); b.put(cx.toInt(), my, mouthC, 44) }
        }
        if (view == 2 && H >= 36) {
            val ey = (cy + ry * 0.10f).toInt(); val ex = (cx + rx * 0.45f).toInt()
            b.put(ex, ey, dark, 44)
            if (look.brow > 0) b.put(ex, ey - 1, ht[3], 44)
            b.put((cx + rx * 0.98f).toInt(), (cy + ry * 0.28f).toInt(), st[2], 44)
            b.put((cx + rx * 0.55f).toInt(), (cy + ry * 0.66f).toInt(), mouthC, 44)
        }
        // barba
        if (look.beard > 0 && view != 0) {
            val bt = look.beard
            for (y in cy.toInt() until (cy + ry * 1.3f).toInt()) for (x in (cx - rx * 1.1f).toInt()..(cx + rx * 1.1f).toInt()) {
                if (b.get(x, y) == 0 || b.grp(x, y) != 41) continue
                val u = (x + 0.5f - cx) / rx; val v = (y + 0.5f - cy) / ry
                if (view == 2 && u < -0.15f) continue
                if (bt == 1 && v > 0.45f && abs(u) < 0.95f && u * u + v * v > 0.35f) b.put(x, y, PC.mix(skin, hair, 0.45f), 45)
                else if (bt == 2 && v > 0.38f) b.put(x, y, if (Math.floorMod(x + y, 5) != 0) ht[1] else ht[2], 45)
                else if (bt == 3 && ((v > 0.42f && abs(u) < 0.35f) || (v > 0.50f && v < 0.60f && abs(u) < 0.7f))) b.put(x, y, ht[1], 45)
            }
            if (view == 1 && H >= 36) {
                val my = (cy + ry * 0.66f).toInt()
                b.put(cx.toInt() - 1, my, if (bt < 2) mouthC else PC.shade(0xFF7A2C34.toInt(), 0.7f), 46)
            }
        }
    }
}

/** Caché de sprites + dibujo sin filtrado. */
object Humans {
    const val T_SMALL = 30; const val T_MID = 38; const val T_BIG = 48; const val T_PORTRAIT = 96

    private val cache = HashMap<Long, Bitmap>()
    private val sizes = HashMap<Long, IntArray>()
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val shadowPaint = Paint().apply { isAntiAlias = false }
    private val dst = RectF()

    /** Altura de sprite (px lógicos) adecuada para el zoom de la cámara de partido. */
    fun tierForZoom(zoom: Float): Int = if (zoom < 13f) T_SMALL else if (zoom < 18f) T_MID else T_BIG

    /** Dirección de pantalla (dx, dy) -> vista: 0 espalda, 1 frente, 2 perfil derecho, 3 perfil izquierdo (espejo). */
    fun viewFor(dx: Float, dy: Float): Int =
        if (abs(dy) >= abs(dx) * 0.8f) (if (dy < 0f) 0 else 1) else (if (dx >= 0f) 2 else 3)

    private fun bitmapFor(look: Look, view: Int, poseId: Int, h: Int): Bitmap {
        val key = (look.key.toLong() shl 24) xor (poseId.toLong() shl 16) xor (view.toLong() shl 12) xor h.toLong()
        var bm = cache[key]
        if (bm == null) {
            if (cache.size > 900) { cache.clear(); sizes.clear() }
            val sp = HumanRaster.render(look, if (view == 3) 2 else view, Poses.of(poseId), h)
            bm = Bitmap.createBitmap(sp.px, sp.w, sp.h, Bitmap.Config.ARGB_8888)
            cache[key] = bm
        }
        return bm!!
    }

    /**
     * Dibuja una persona con los pies en (x, y) (coordenadas de referencia). [unit] = lado de un píxel de sprite en px de referencia
     * (múltiplo de PX.LP; 1 píxel lógico por defecto).
     */
    fun draw(c: Canvas, look: Look, view: Int, poseId: Int, x: Float, y: Float, h: Int, pxMul: Int = 1, jump: Float = 0f, shadow: Boolean = true) {
        val bm = bitmapFor(look, view, poseId, h)
        val u = PX.LP * pxMul
        val w = bm.width * u; val hh = bm.height * u
        val fx = PX.snap(x); val fy = PX.snap(y)
        if (shadow) {
            shadowPaint.color = 0x55000000
            val sw = w * 0.36f
            c.drawRect(fx - sw, fy - u, fx + sw, fy + u, shadowPaint)
            c.drawRect(fx - sw * 0.6f, fy - 2f * u, fx + sw * 0.6f, fy + 2f * u, shadowPaint)
        }
        val top = fy - (h - 1.5f) * u - jump
        c.save()
        if (view == 3) {
            c.translate(fx, 0f); c.scale(-1f, 1f)
            dst.set(-w / 2f, top, w / 2f, top + hh)
        } else dst.set(fx - w / 2f, top, fx + w / 2f, top + hh)
        c.drawBitmap(bm, null, dst, paint)
        c.restore()
    }
}
