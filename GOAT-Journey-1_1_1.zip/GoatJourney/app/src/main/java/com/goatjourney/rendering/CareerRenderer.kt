package com.goatjourney.rendering

import android.graphics.Canvas
import android.graphics.Paint
import com.goatjourney.core.career.*
import com.goatjourney.core.match.MatchImportance
import com.goatjourney.core.player.Attributes
import com.goatjourney.core.simulation.MatchMode
import com.goatjourney.core.simulation.RatingLabel
import com.goatjourney.game.GameController
import com.goatjourney.game.GameState

private fun GameController.shirt(): Int = career!!.club().primary
private fun GameController.shorts(): Int = career!!.club().secondary

/** MAIN CAREER SCREEN (vertical) */
class CareerScreen(g: GameController) : BaseScreen(g) {
    private val bMain = btn("main", 24f, 716f, 672f, 84f, "JUGAR PARTIDO")
    private val bPlayer = btn("player", 24f, 1030f, 216f, 76f, "JUGADOR", 1)
    private val bCal = btn("cal", 252f, 1030f, 216f, 76f, "CALENDARIO", 1)
    private val bTable = btn("table", 480f, 1030f, 216f, 76f, "TABLA", 1)
    private val bSave = btn("save", 24f, 1122f, 330f, 76f, "GUARDAR", 1)
    private val bSet = btn("set", 366f, 1122f, 330f, 76f, "AJUSTES", 1)

    private var info = ""; private var sub = ""; private var date = ""; private var mainLabel = ""
    private var l1 = ""; private var l2 = ""; private var l3 = ""; private var l4 = ""; private var l5 = ""
    private var who = ""; private var meta = ""; private var clubName = ""; private var ovr = ""
    private var savedFlash = 0f

    override fun onEnter() { super.onEnter(); refresh() }

    private fun refresh() {
        val s = game.career ?: return
        val p = s.player
        who = p.fullName(); meta = "${p.age} años  ·  ${p.position.label}  ·  #${p.shirtNumber}"
        clubName = s.club().name; ovr = p.overall.toString()
        date = CareerDate.format(s.currentDay) + "  ·  Temp. ${s.season}"
        val e = s.nextEntry()
        if (e == null) { info = "TEMPORADA COMPLETADA"; sub = "Posición final: ${s.tablePosition()}º"; mainLabel = "NUEVA TEMPORADA" }
        else if (e.type == EntryType.TRAINING) { info = "ENTRENAMIENTO"; sub = CareerDate.format(e.day); mainLabel = "ENTRENAR" }
        else {
            val f = s.fixtureOf(e)!!
            val home = f.homeId == p.clubId
            val opp = s.clubById(if (home) f.awayId else f.homeId)
            info = "J${f.matchday + 1}  vs  ${opp.name}"
            sub = CareerDate.format(e.day) + "  ·  " + (if (home) "LOCAL" else "VISITANTE") + (if (f.importance == MatchImportance.IMPORTANT) "  ·  IMPORTANTE" else "")
            mainLabel = "JUGAR PARTIDO"
        }
        bMain.label = mainLabel
        val st = s.seasonStats
        l1 = "${st.matches}"; l2 = "${st.goals}"; l3 = "${st.assists}"
        l4 = if (st.matchRatings.isEmpty()) "-" else "%.1f".format(st.averageRating()); l5 = "${s.tablePosition()}º"
    }

    override fun draw(c: Canvas) {
        val s = game.career ?: return
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "CARRERA", date)
        ui.panel(c, 24f, 96f, 672f, 440f)
        ui.player(c, 360f, 400f, 3.1f, s.player.appearance, game.shirt(), game.shorts(), 1f, time * 3f, false)
        ui.textFit(c, who, 360f, 440f, 34f, 600f, Palette.WHITE, Paint.Align.CENTER)
        ui.textFit(c, meta, 360f, 474f, 22f, 620f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.textFit(c, clubName, 360f, 512f, 28f, 600f, Palette.GOLD, Paint.Align.CENTER)
        ui.circle(c, 610f, 170f, 48f, Palette.ACCENT)
        ui.text(c, ovr, 610f, 188f, 54f, Palette.BG, Paint.Align.CENTER)
        ui.text(c, "OVR", 610f, 236f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.panel(c, 24f, 556f, 672f, 144f)
        ui.text(c, "PRÓXIMO", 48f, 596f, 24f, Palette.ACCENT)
        ui.textFit(c, info, 48f, 650f, 42f, 624f, Palette.WHITE, Paint.Align.LEFT)
        ui.textFit(c, sub, 48f, 686f, 24f, 624f, Palette.TEXT_DIM, Paint.Align.LEFT)
        ui.panel(c, 24f, 824f, 672f, 180f)
        ui.text(c, "TEMPORADA", 48f, 862f, 24f, Palette.ACCENT)
        val labs = arrayOf("PJ", "GOLES", "ASIST.", "RATING", "TABLA")
        val vals = arrayOf(l1, l2, l3, l4, l5)
        for (i in 0 until 5) {
            val cx = 92f + i * 134f
            ui.text(c, vals[i], cx, 950f, 52f, Palette.WHITE, Paint.Align.CENTER)
            ui.text(c, labs[i], cx, 984f, 20f, Palette.TEXT_DIM, Paint.Align.CENTER)
        }
        drawButtons(c)
        if (savedFlash > 0f) ui.text(c, "PARTIDA GUARDADA", 360f, 1240f, 24f, withAlpha(Palette.ACCENT, (savedFlash.coerceAtMost(1f) * 255).toInt()), Paint.Align.CENTER)
    }

    override fun update(dt: Float) { super.update(dt); if (savedFlash > 0f) savedFlash -= dt }

    override fun onButton(id: String) {
        val s = game.career ?: return
        when (id) {
            "main" -> {
                val e = s.nextEntry()
                when {
                    e == null -> { game.newSeason(); refresh() }
                    e.type == EntryType.TRAINING -> { game.advanceTraining(); refresh() }
                    else -> game.go(GameState.MATCH_PREVIEW)
                }
            }
            "player" -> game.go(GameState.PLAYER)
            "cal" -> game.go(GameState.CALENDAR)
            "table" -> game.go(GameState.TABLE)
            "save" -> { game.saveNow(); savedFlash = 2f }
            "set" -> game.go(GameState.SETTINGS)
        }
    }

    override fun onBack(): Boolean { game.saveNow(); game.go(GameState.TITLE); return true }
}

/** PLAYER SCREEN */
class PlayerScreen(g: GameController) : BaseScreen(g) {
    private val bBack = btn("back", 24f, 1170f, 672f, 76f, "VOLVER", 1)
    private var vals = IntArray(14)
    private var ovr = ""; private var who = ""; private var meta1 = ""; private var meta2 = ""

    override fun onEnter() {
        super.onEnter()
        val p = game.career!!.player
        vals = p.attributes.toArray(); ovr = p.overall.toString(); who = p.fullName()
        meta1 = "${p.age} años · ${p.position.label}"
        meta2 = "Pie ${p.preferredFoot.label.lowercase()} · ${p.nationality}"
    }

    private fun group(c: Canvas, title: String, y: Float, from: Int, to: Int) {
        ui.text(c, title, 48f, y, 26f, Palette.ACCENT)
        for (i in from..to) {
            val ry = y + 38f + (i - from) * 40f
            ui.text(c, Attributes.NAMES[i], 48f, ry, 24f, Palette.WHITE)
            ui.bar(c, 270f, ry - 18f, 280f, 14f, vals[i] / 100f, if (vals[i] >= 60) Palette.ACCENT else Palette.GOLD)
            ui.text(c, vals[i].toString(), 672f, ry, 26f, Palette.WHITE, Paint.Align.RIGHT)
        }
    }

    override fun draw(c: Canvas) {
        val s = game.career ?: return
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "JUGADOR")
        ui.panel(c, 24f, 96f, 672f, 300f)
        ui.player(c, 170f, 360f, 2.6f, s.player.appearance, game.shirt(), game.shorts(), 1f, 0f, false)
        ui.textFit(c, who, 540f, 170f, 32f, 300f, Palette.WHITE, Paint.Align.CENTER)
        ui.textFit(c, meta1, 540f, 204f, 22f, 300f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.textFit(c, meta2, 540f, 232f, 20f, 300f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.circle(c, 540f, 310f, 48f, Palette.ACCENT)
        ui.text(c, ovr, 540f, 328f, 54f, Palette.BG, Paint.Align.CENTER)
        ui.text(c, "OVR", 540f, 378f, 18f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.panel(c, 24f, 412f, 672f, 740f)
        group(c, "TÉCNICOS", 454f, 0, 5)
        group(c, "FÍSICOS", 740f, 6, 9)
        group(c, "MENTALES", 944f, 10, 13)
        drawButtons(c)
    }

    override fun onButton(id: String) { game.go(GameState.CAREER) }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** CALENDAR */
class CalendarScreen(g: GameController) : BaseScreen(g) {
    private val bUp = btn("up", 24f, 790f, 330f, 56f, "", 1, ICON_UP)
    private val bDown = btn("down", 366f, 790f, 330f, 56f, "", 1, ICON_DOWN)
    private val bPlay = btn("play", 24f, 1050f, 330f, 84f, "JUGAR")
    private val bSim = btn("sim", 366f, 1050f, 330f, 84f, "SIMULAR", 1)
    private val bTrain = btn("train", 24f, 1050f, 672f, 84f, "ENTRENAR")
    private val bBack = btn("back", 24f, 1160f, 672f, 76f, "VOLVER", 1)
    private val rows = 9
    private var start = 0
    private var dates = emptyArray<String>(); private var descs = emptyArray<String>(); private var res = emptyArray<String>()
    private var types = emptyArray<EntryType>()
    private var idx = 0; private var total = 0
    private var nTitle = ""; private var nSub = ""; private var isMatch = false; private var over = false

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!
        total = s.calendar.size; idx = s.calendarIndex; over = s.seasonOver()
        dates = Array(total) { CareerDate.format(s.calendar[it].day) }
        types = Array(total) { s.calendar[it].type }
        descs = Array(total) { i ->
            val e = s.calendar[i]
            if (e.type == EntryType.TRAINING) "Entrenamiento" else {
                val f = s.fixtureOf(e)!!; val home = f.homeId == s.player.clubId
                "J${f.matchday + 1}  vs  " + s.clubById(if (home) f.awayId else f.homeId).name + (if (home) "  (L)" else "  (V)")
            }
        }
        res = Array(total) { i ->
            val e = s.calendar[i]; val f = s.fixtureOf(e)
            if (f != null && f.status == MatchStatus.PLAYED) "${f.homeGoals} - ${f.awayGoals}" else ""
        }
        start = (idx - 1).coerceIn(0, (total - rows).coerceAtLeast(0))
        isMatch = !over && types[idx] == EntryType.MATCH
        nTitle = if (over) "TEMPORADA COMPLETADA" else if (isMatch) descs[idx] else "ENTRENAMIENTO"
        nSub = if (over) "" else dates[idx]
        bPlay.visible = isMatch; bSim.visible = isMatch; bTrain.visible = !over && !isMatch
    }

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "CALENDARIO")
        ui.panel(c, 24f, 96f, 672f, 680f)
        for (i in 0 until rows) {
            val k = start + i
            if (k >= total) break
            val y = 106f + i * 74f
            if (k == idx) ui.panel(c, 34f, y, 652f, 66f, withAlpha(Palette.ACCENT, 40), Palette.ACCENT, 12f)
            val col = if (k < idx) Palette.TEXT_DIM else Palette.WHITE
            ui.text(c, dates[k], 50f, y + 42f, 24f, Palette.GOLD)
            ui.textFit(c, descs[k], 160f, y + 42f, 26f, 370f, col, Paint.Align.LEFT)
            ui.text(c, res[k], 668f, y + 42f, 26f, col, Paint.Align.RIGHT)
        }
        ui.panel(c, 24f, 862f, 672f, 170f)
        ui.text(c, "PRÓXIMO", 48f, 900f, 22f, Palette.ACCENT)
        ui.textFit(c, nTitle, 48f, 958f, 34f, 624f, Palette.WHITE, Paint.Align.LEFT)
        ui.text(c, nSub, 48f, 1002f, 26f, Palette.TEXT_DIM)
        drawButtons(c)
    }

    override fun onButton(id: String) {
        when (id) {
            "up" -> start = (start - 1).coerceAtLeast(0)
            "down" -> start = (start + 1).coerceAtMost((total - rows).coerceAtLeast(0))
            "play" -> game.startMatch(MatchMode.PLAY)
            "sim" -> game.startMatch(MatchMode.SIMULATE)
            "train" -> { game.advanceTraining(); onEnter() }
            "back" -> game.go(GameState.CAREER)
        }
    }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** MATCH PREVIEW */
class MatchPreviewScreen(g: GameController) : BaseScreen(g) {
    private val bPlay = btn("play", 24f, 1000f, 330f, 90f, "JUGAR")
    private val bSim = btn("sim", 366f, 1000f, 330f, 90f, "SIMULAR", 1)
    private val bBack = btn("back", 24f, 1110f, 672f, 76f, "VOLVER", 1)
    private var my: Club? = null; private var opp: Club? = null
    private var venue = ""; private var comp = ""; private var posTxt = ""; private var ovrTxt = ""; private var imp = false
    private var rivalTxt = ""; private var dateTxt = ""

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!
        val e = s.nextEntry(); val f = s.fixtureOf(e!!)!!
        val home = f.homeId == s.player.clubId
        my = s.club(); opp = s.clubById(if (home) f.awayId else f.homeId)
        venue = if (home) "LOCAL" else "VISITANTE"
        comp = "${s.competition}  ·  Jornada ${f.matchday + 1}"
        dateTxt = CareerDate.format(e.day)
        imp = f.importance == MatchImportance.IMPORTANT
        posTxt = s.player.position.label; ovrTxt = "OVR ${s.player.overall}"
        rivalTxt = "Fuerza rival ${opp!!.strength}  ·  Tu club ${my!!.strength}"
    }

    override fun draw(c: Canvas) {
        val a = my ?: return; val b = opp ?: return
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "PREVIA DEL PARTIDO", dateTxt)
        ui.panel(c, 24f, 96f, 672f, 440f)
        ui.badge(c, 170f, 250f, 80f, a.primary, a.secondary, a.abbr)
        ui.badge(c, 550f, 250f, 80f, b.primary, b.secondary, b.abbr)
        ui.text(c, "VS", 360f, 275f, 80f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, venue, 360f, 330f, 26f, Palette.ACCENT, Paint.Align.CENTER)
        ui.textFit(c, a.name, 170f, 385f, 30f, 300f, Palette.WHITE, Paint.Align.CENTER)
        ui.textFit(c, b.name, 550f, 385f, 30f, 300f, Palette.WHITE, Paint.Align.CENTER)
        ui.panel(c, 24f, 556f, 672f, 200f)
        ui.textFit(c, comp, 48f, 604f, 28f, 624f, Palette.WHITE, Paint.Align.LEFT)
        ui.textFit(c, rivalTxt, 48f, 644f, 24f, 624f, Palette.TEXT_DIM, Paint.Align.LEFT)
        ui.text(c, "$posTxt  ·  $ovrTxt", 48f, 696f, 28f, Palette.GOLD)
        if (imp) ui.text(c, "PARTIDO IMPORTANTE", 48f, 736f, 24f, Palette.RED)
        ui.panel(c, 24f, 780f, 672f, 190f)
        ui.text(c, "CÓMO SE JUEGA", 48f, 820f, 22f, Palette.ACCENT)
        ui.text(c, "Cuando te llegue el balón:", 48f, 856f, 22f, Palette.WHITE)
        ui.text(c, "1. Arrastra para moverte (si hay tiempo).", 48f, 890f, 22f, Palette.TEXT_DIM)
        ui.text(c, "2. Desde el balón: dirección y fuerza.", 48f, 920f, 22f, Palette.TEXT_DIM)
        ui.text(c, "3. Toca el balón: efecto y altura (spin).", 48f, 950f, 22f, Palette.TEXT_DIM)
        drawButtons(c)
    }

    override fun onButton(id: String) {
        when (id) {
            "play" -> game.startMatch(MatchMode.PLAY)
            "sim" -> game.startMatch(MatchMode.SIMULATE)
            "back" -> game.go(GameState.CAREER)
        }
    }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** FULL TIME */
class MatchResultScreen(g: GameController) : BaseScreen(g) {
    private val bCont = btn("cont", 24f, 1170f, 330f, 76f, "CONTINUAR")
    private val bTable = btn("table", 366f, 1170f, 330f, 76f, "TABLA", 1)
    private var hName = ""; private var aName = ""; private var hs = ""; private var aGoals = ""
    private var lines = emptyArray<String>(); private var rating = 0f; private var label = ""
    private var goals = emptyArray<String>()
    private var hc: Club? = null; private var ac: Club? = null

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!; val r = game.lastResult
        hc = s.clubById(r.homeId); ac = s.clubById(r.awayId)
        hName = hc!!.name; aName = ac!!.name; hs = r.homeGoals.toString(); aGoals = r.awayGoals.toString()
        val st = r.stats
        lines = arrayOf(
            "${r.playerMinutes} minutos", "${st.passesCompleted}/${st.passesAttempted} pases",
            "${st.dribblesCompleted}/${st.dribblesAttempted} regates", "${st.shots} tiros",
            "${st.goals} gol(es)", "${st.assists} asistencia(s)"
        )
        if (st.interceptions + st.clearances + st.crosses > 0)
            lines = lines + "${st.interceptions} interc. · ${st.clearances} despejes · ${st.crosses} centros"
        rating = r.rating; label = RatingLabel.of(r.rating)
        goals = r.events.filter { it.important && it.text.contains("GOL", true) || it.text.contains("marca", true) }.takeLast(5)
            .map { "${it.minute}'  ${it.text}" }.toTypedArray()
    }

    override fun draw(c: Canvas) {
        val h = hc ?: return; val a = ac ?: return
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.fillRect(c, 0f, 0f, Ref.W, 90f, Palette.BG2)
        ui.fillRect(c, 0f, 88f, Ref.W, 4f, Palette.GOLD)
        ui.text(c, "FULL TIME", 360f, 64f, 52f, Palette.GOLD, Paint.Align.CENTER)
        ui.panel(c, 24f, 110f, 672f, 200f)
        ui.badge(c, 80f, 170f, 30f, h.primary, h.secondary, h.abbr); ui.badge(c, 80f, 250f, 30f, a.primary, a.secondary, a.abbr)
        ui.textFit(c, hName, 130f, 182f, 32f, 400f, Palette.WHITE, Paint.Align.LEFT)
        ui.textFit(c, aName, 130f, 262f, 32f, 400f, Palette.WHITE, Paint.Align.LEFT)
        ui.text(c, hs, 660f, 184f, 56f, Palette.GOLD, Paint.Align.RIGHT)
        ui.text(c, aGoals, 660f, 264f, 56f, Palette.GOLD, Paint.Align.RIGHT)
        ui.panel(c, 24f, 330f, 672f, 200f)
        ui.text(c, "RESUMEN", 48f, 366f, 22f, Palette.ACCENT)
        for (i in goals.indices) ui.textFit(c, goals[i], 48f, 400f + i * 28f, 22f, 624f, Palette.WHITE, Paint.Align.LEFT)
        ui.panel(c, 24f, 550f, 672f, 360f)
        ui.text(c, "TU ACTUACIÓN", 48f, 592f, 26f, Palette.ACCENT)
        for (i in lines.indices) ui.textFit(c, lines[i], 48f, 640f + i * 38f, 28f, 624f, Palette.WHITE, Paint.Align.LEFT)
        ui.panel(c, 24f, 930f, 672f, 210f)
        val shown = rating * Ease.outCubic((time / 1.1f).coerceIn(0f, 1f))
        ui.text(c, "%.1f".format(shown), 190f, 1068f, 100f, Palette.GOLD, Paint.Align.CENTER)
        ui.text(c, "RATING", 500f, 996f, 22f, Palette.TEXT_DIM, Paint.Align.CENTER)
        ui.text(c, label, 500f, 1060f, 40f, Palette.WHITE, Paint.Align.CENTER)
        drawButtons(c)
    }

    override fun onButton(id: String) { game.go(if (id == "cont") GameState.CAREER else GameState.TABLE) }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}

/** TABLE */
class TableScreen(g: GameController) : BaseScreen(g) {
    private val bBack = btn("back", 24f, 1060f, 672f, 80f, "VOLVER", 1)
    private var rows = emptyArray<TableRow>(); private var names = emptyArray<String>(); private var mine = -1
    private var cells = emptyArray<Array<String>>()

    override fun onEnter() {
        super.onEnter()
        val s = game.career!!
        rows = s.table.toTypedArray()
        names = Array(rows.size) { s.clubById(rows[it].clubId).name }
        mine = rows.indexOfFirst { it.clubId == s.player.clubId }
        cells = Array(rows.size) { i -> val r = rows[i]; arrayOf("${i + 1}", "${r.played}", "${r.won}", "${r.drawn}", "${r.lost}", "${r.gf}", "${r.ga}", "${r.points}") }
    }

    override fun draw(c: Canvas) {
        ui.fillRect(c, 0f, 0f, Ref.W, Ref.H, Palette.BG)
        ui.header(c, "CLASIFICACIÓN")
        ui.panel(c, 24f, 94f, 672f, 940f)
        val heads = arrayOf("#", "PJ", "G", "E", "P", "GF", "GC", "PTS")
        val xs = floatArrayOf(48f, 392f, 440f, 486f, 532f, 580f, 628f, 676f)
        for (j in heads.indices) ui.text(c, heads[j], xs[j], 130f, 20f, Palette.TEXT_DIM, if (j == 0) Paint.Align.LEFT else Paint.Align.CENTER)
        ui.text(c, "CLUB", 92f, 130f, 20f, Palette.TEXT_DIM)
        for (i in rows.indices) {
            val y = 146f + i * 88f
            if (i == mine) ui.panel(c, 34f, y, 652f, 80f, withAlpha(Palette.ACCENT, 45), Palette.ACCENT, 10f)
            val col = if (i == mine) Palette.WHITE else 0xFFC9D6E8.toInt()
            ui.text(c, cells[i][0], xs[0], y + 52f, 28f, Palette.GOLD)
            ui.textFit(c, names[i], 92f, y + 52f, 28f, 270f, col, Paint.Align.LEFT)
            for (j in 1 until 8) ui.text(c, cells[i][j], xs[j], y + 52f, 24f, if (j == 7) Palette.GOLD else col, Paint.Align.CENTER)
        }
        drawButtons(c)
    }

    override fun onButton(id: String) { game.go(GameState.CAREER) }
    override fun onBack(): Boolean { game.go(GameState.CAREER); return true }
}
