package com.goatjourney.input

import android.view.MotionEvent
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.hypot

class RawTouch(val action: Int, val x: Float, val y: Float, val time: Long)

/**
 * Recoge MotionEvents en el hilo de UI y los entrega al game loop (sin tocar el estado del juego).
 *  - Sigue UN solo dedo (por id): un segundo dedo o levantar el otro no hace saltar el gesto.
 *  - Entrega TODOS los puntos históricos de cada MOVE (Android agrupa movimientos por frame): el trazo no pierde resolución.
 */
class TouchInput {
    private val queue = ConcurrentLinkedQueue<RawTouch>()
    private var activeId = -1

    fun onMotionEvent(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeId = e.getPointerId(0)
                queue.add(RawTouch(MotionEvent.ACTION_DOWN, e.getX(0), e.getY(0), e.eventTime))
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(activeId)
                if (i < 0) return
                for (h in 0 until e.historySize) {
                    queue.add(RawTouch(MotionEvent.ACTION_MOVE, e.getHistoricalX(i, h), e.getHistoricalY(i, h), e.getHistoricalEventTime(h)))
                }
                queue.add(RawTouch(MotionEvent.ACTION_MOVE, e.getX(i), e.getY(i), e.eventTime))
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (e.getPointerId(e.actionIndex) == activeId) {
                    // se levantó el dedo que seguíamos: termina el gesto donde estaba
                    queue.add(RawTouch(MotionEvent.ACTION_UP, e.getX(e.actionIndex), e.getY(e.actionIndex), e.eventTime))
                    activeId = -1
                }
            }
            MotionEvent.ACTION_UP -> {
                if (activeId != -1) queue.add(RawTouch(MotionEvent.ACTION_UP, e.getX(0), e.getY(0), e.eventTime))
                activeId = -1
            }
            MotionEvent.ACTION_CANCEL -> {
                if (activeId != -1) queue.add(RawTouch(MotionEvent.ACTION_CANCEL, e.getX(0), e.getY(0), e.eventTime))
                activeId = -1
            }
        }
    }

    fun drain(handler: (RawTouch) -> Unit) {
        while (true) { val r = queue.poll() ?: break; handler(r) }
    }
}

/** Coordenadas ya en espacio de referencia (720x1280). */
interface GestureListener {
    fun onDown(x: Float, y: Float) {}
    /** Cada movimiento del dedo, sin umbral (para controles que deben responder desde el primer píxel). */
    fun onMove(x: Float, y: Float) {}
    fun onTap(x: Float, y: Float) {}
    fun onDragStart(x: Float, y: Float) {}
    fun onDrag(x: Float, y: Float, startX: Float, startY: Float) {}
    fun onRelease(x: Float, y: Float, startX: Float, startY: Float, dragged: Boolean) {}
    /** El sistema interrumpió el gesto (no es un "soltar": no debe ejecutar acciones). */
    fun onCancel() {}
    fun onLongPress(x: Float, y: Float) {}
}

/** Traduce ACTION_DOWN/MOVE/UP a Tap, Drag, Release y Long Press. */
class GestureProcessor(private val listener: GestureListener) {
    private var isDown = false
    private var dragging = false
    private var longFired = false
    private var sx = 0f
    private var sy = 0f
    private var downTime = 0L
    private val slop = 8f
    private val longPressMs = 550L

    fun down(x: Float, y: Float, t: Long) {
        isDown = true; dragging = false; longFired = false; sx = x; sy = y; downTime = t
        listener.onDown(x, y)
    }

    fun move(x: Float, y: Float) {
        if (!isDown) return
        listener.onMove(x, y)
        if (!dragging && hypot(x - sx, y - sy) > slop) { dragging = true; listener.onDragStart(sx, sy) }
        if (dragging) listener.onDrag(x, y, sx, sy)
    }

    fun up(x: Float, y: Float) {
        if (!isDown) return
        isDown = false
        listener.onRelease(x, y, sx, sy, dragging)
        if (!dragging && !longFired) listener.onTap(x, y)
    }

    fun cancel() {
        if (!isDown) return
        isDown = false; dragging = false
        listener.onCancel()
    }

    fun update(now: Long) {
        if (isDown && !dragging && !longFired && now - downTime >= longPressMs) {
            longFired = true
            listener.onLongPress(sx, sy)
        }
    }
}
