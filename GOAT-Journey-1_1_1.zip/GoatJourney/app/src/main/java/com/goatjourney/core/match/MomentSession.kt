package com.goatjourney.core.match

import com.goatjourney.core.player.Attributes
import kotlin.math.*

class AimPreview(val intent: ActionIntent, val power: Float, val samples: List<BallSample>?)

/**
 * Una intervención del protagonista: POSITIONING (ventana de movimiento) -> AIM -> CONTACT -> resultado.
 * En REACTION se empieza directamente en AIM con un reloj que corre. Sin dependencias de Android ni del render.
 */
class MomentSession(val moment: KeyMoment, private val attrs: Attributes, private val resolver: ActionResolver) {
    enum class Phase { POSITIONING, AIM, CONTACT, DONE }

    val world: World = moment.makeWorld()
    var phase: Phase = if (moment.mode == MomentMode.POSITIONING) Phase.POSITIONING else Phase.AIM; private set
    val window: Float = moment.timeWindow
    var elapsed = 0f; private set
    val timeLeft: Float get() = max(0f, window - elapsed)
    val isReaction: Boolean get() = moment.mode != MomentMode.POSITIONING
    val expired: Boolean get() = isReaction && phase == Phase.AIM && elapsed >= window
    val runSpeed = PositioningPhase.runSpeed(attrs)
    val maxMove = PositioningPhase.maxMove(attrs, window, true)
    var moved = 0f; private set
    var ball: Vec = if (isReaction) (moment.incoming?.at(0f)?.let { Vec(it.x, it.y) } ?: moment.ball) else world.player; private set
    var ballZ: Float = moment.ballHeight; private set
    var aim: Aim? = null; private set
    var intent: ActionIntent? = null; private set
    var result: ActionResult? = null; private set
    private var move: Vec? = null
    private var moveMag = 0f
    private var timing = 1f
    private var arrive = 1f
    private val startPressure = OpponentAI.pressureAt(world.player, world.rivals)

    /** Posición del balón en el momento del golpeo (contacto en reacción; pies en posicionamiento). */
    fun origin(): Vec = if (isReaction) (moment.contact?.pos ?: ball) else world.player

    fun livePressure(): Float = OpponentAI.pressureAt(world.player, world.rivals)

    // ------------------------------------------------------------------ reloj y mundo
    fun update(dt: Float) {
        if (phase == Phase.DONE || phase == Phase.CONTACT) return
        elapsed += dt
        if (!isReaction) {
            if (phase == Phase.POSITIONING && timeLeft > 0f) {
                val mv = move
                if (mv != null && moved < maxMove) {
                    val step = min(runSpeed * 0.8f * moveMag * dt, maxMove - moved)
                    world.player = Geo.clampPitch(world.player + mv * step)
                    moved += step
                }
                TeammateAI.step(world, dt)
                OpponentAI.step(world, world.player, dt, true, elapsed)
            }
            ball = world.player
        } else {
            val cp = moment.contact
            if (cp != null) {
                val d = world.player.dist(cp.pos)
                if (d > 0.6f) world.player = world.player + (cp.pos - world.player).norm() * min(d - 0.6f, runSpeed * dt)
            }
            val inc = moment.incoming
            if (inc != null) { val s = inc.at(min(elapsed, window)); ball = Vec(s.x, s.y); ballZ = s.z }
            TeammateAI.step(world, dt)
            OpponentAI.step(world, ball, dt, false, elapsed)
        }
    }

    /** Avanza el mundo hasta el instante t (usado por el controlador de IA). */
    fun advanceTo(t: Float) { while (elapsed < t && phase != Phase.DONE) update(0.05f) }

    // ------------------------------------------------------------------ posicionamiento
    fun setMove(dir: Vec?, mag: Float) {
        if (phase != Phase.POSITIONING) { move = null; return }
        move = dir; moveMag = mag.coerceIn(0f, 1f)
    }

    fun canMove(): Boolean = phase == Phase.POSITIONING && timeLeft > 0f && moved < maxMove - 0.05f

    fun beginAim() { if (phase == Phase.POSITIONING) { phase = Phase.AIM; move = null } }

    fun cancelAim() { if (phase == Phase.AIM && !isReaction) phase = Phase.POSITIONING }

    // ------------------------------------------------------------------ ejecución
    private fun timingOf(): Float {
        if (!isReaction) return 1f
        val u = (elapsed / window).coerceIn(0f, 1f)
        return 0.75f + 0.25f * (u / 0.3f).coerceIn(0f, 1f)
    }

    private fun arriveOf(): Float {
        val cp = moment.contact ?: return 1f
        if (!isReaction) return 1f
        val d = world.player.dist(cp.pos)
        val need = max(0f, d - 0.9f) / max(1f, runSpeed)
        val left = max(0f, window - elapsed)
        return if (need <= left) 1f else (1f - (need - left) / 0.8f).coerceIn(0.3f, 1f)
    }

    private fun inputFor(a: Aim, it: ActionIntent, c: Contact, tim: Float, arr: Float): ResolveInput {
        val tech = resolver.technique(attrs)
        val eff = ContactPhase.effect(c, a.power, tech)
        val pr = (livePressure() * 0.6f + moment.pressure * 0.4f).coerceIn(0f, 1f)
        val cpz = moment.contact?.z ?: 0.1f
        return ResolveInput(moment, world, origin(), if (isReaction) cpz else 0.1f, attrs, a, it, c, eff, tim, arr, pr)
    }

    fun preview(dir: Vec, dragPx: Float): AimPreview? {
        val a = AimPhase.fromDrag(dir, dragPx) ?: return null
        val it = AimPhase.infer(moment, origin(), world.mates, a)
        val traj = resolver.previewTrajectory(inputFor(a, it, Contact(0f, 0f), 1f, 1f))
        return AimPreview(it, a.power, traj?.samples)
    }

    /** Trayectoria hipotética (sin ruido) con un contacto concreto: la usa la IA para calibrar la fuerza. */
    fun previewAt(dir: Vec, power: Float, c: Contact): Trajectory? {
        val a = Aim(dir.norm(), power, AimPhase.dragFor(power))
        val it = AimPhase.infer(moment, origin(), world.mates, a)
        return resolver.previewTrajectory(inputFor(a, it, c, 1f, 1f))
    }

    /** Trayectoria hipotética (sin ruido) con el golpeo ya apuntado y un contacto concreto: se enseña mientras el jugador elige dónde golpear. */
    fun previewContactTrajectory(c: Contact): Trajectory? {
        val a = aim ?: return null
        val it = intent ?: return null
        return resolver.previewTrajectory(inputFor(a, it, c, 1f, 1f))
    }

    fun releaseAim(dir: Vec, dragPx: Float): Boolean {
        if (phase != Phase.AIM) return false
        val a = AimPhase.fromDrag(dir, dragPx) ?: return false
        aim = a
        val it = AimPhase.infer(moment, origin(), world.mates, a)
        intent = it
        timing = timingOf(); arrive = arriveOf()
        phase = Phase.CONTACT
        if (it.kind == IntentKind.CONTROL || it.kind == IntentKind.INTERCEPT) finish(Contact(0f, 0f))
        return true
    }

    fun commitContact(nx: Float, ny: Float): ActionResult {
        val c = ContactPhase.fromTouch(nx, ny)
        return finish(c)
    }

    private fun finish(c: Contact): ActionResult {
        val a = aim ?: Aim(Vec(1f, 0f), 0.3f, 80f)
        val it = intent ?: AimPhase.infer(moment, origin(), world.mates, a)
        val r = resolver.resolve(inputFor(a, it, c, timing, arrive))
        // regate/escape: intentar salir de la presión moviéndose
        if (!isReaction && moved > 1.5f && startPressure > 0.45f) {
            r.dribbleAttempt = true
            r.dribbleWon = livePressure() < startPressure - 0.08f
        }
        result = r
        phase = Phase.DONE
        return r
    }

    /** Se acabó el tiempo de reacción: golpeo tardío y descontrolado. */
    fun timeoutResolve(): ActionResult {
        val cp = moment.contact?.pos ?: world.player
        val toGoal = Vec(Pitch.LENGTH - cp.x, Pitch.CENTER_Y - cp.y).norm()
        val dir = when (moment.type) {
            KeyMomentType.INTERCEPTION_MOMENT, KeyMomentType.FIRST_TOUCH_MOMENT -> (cp - world.player).norm()
            KeyMomentType.CLEARANCE_MOMENT -> Vec(0.5f, if (cp.y > 34f) 0.8f else -0.8f).norm()
            else -> toGoal
        }
        aim = Aim(dir, 0.35f, AimPhase.dragFor(0.35f))
        intent = AimPhase.infer(moment, origin(), world.mates, aim!!)
        timing = 0.35f; arrive = (arriveOf() * 0.8f).coerceIn(0.3f, 1f)
        phase = Phase.CONTACT
        return finish(Contact(0.6f, -0.4f))
    }
}
