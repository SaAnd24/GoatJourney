package com.goatjourney.core.match

import com.goatjourney.core.player.Attributes
import com.goatjourney.core.player.Position
import kotlin.math.*
import kotlin.random.Random

class Split(val moment: KeyMoment, val startT: Float)

enum class Scenario {
    RECEIVE_PASS, RECEIVE_BOX, THROUGH_RUN, FIRST_TOUCH, CROSS_DELIVER, CROSS_INCOMING,
    LOOSE_BOX, INTERCEPT, CLEAR_HIGH, CLEAR_LOOSE
}

/**
 * Decide cuándo aparece un KeyMoment y construye la escena (posiciones, compañeros, rivales, ventana de tiempo).
 * Positioning (colocación inicial, distancia al marcador, llegada a centros) y Vision (pistas legibles) se aplican aquí.
 */
class KeyMomentGenerator(
    private val rng: Random,
    private val attrs: Attributes,
    val position: Position,
    myStr: Float,
    oppStr: Float
) {
    private val myQ = (myStr / 80f).coerceIn(0.25f, 0.92f)
    private val oppQ = (oppStr / 80f).coerceIn(0.25f, 0.92f)
    private val edge: Float get() = ((attrs.positioning / 100f - 0.5f) * 2f).coerceIn(-1f, 1f)
    private val readQ: Float get() = (attrs.vision / 100f * 0.7f + attrs.decisions / 100f * 0.3f).coerceIn(0f, 1f)

    private fun rf(a: Float, b: Float) = a + rng.nextFloat() * (b - a)

    // ------------------------------------------------------------------ frecuencia y tipo
    fun involvementChance(p: Position): Float = when (p) {
        Position.CENTER_BACK -> 0.10f
        Position.FULL_BACK -> 0.12f
        Position.MIDFIELDER -> 0.15f
        Position.WINGER -> 0.13f
        Position.STRIKER -> 0.11f
    }

    fun attackShare(p: Position): Float = when (p) {
        Position.CENTER_BACK -> 0.35f
        Position.FULL_BACK -> 0.50f
        Position.MIDFIELDER -> 0.55f
        Position.WINGER -> 0.70f
        Position.STRIKER -> 0.85f
    }

    private val attackW: Map<Position, Map<Scenario, Int>> = mapOf(
        Position.CENTER_BACK to mapOf(Scenario.RECEIVE_PASS to 70, Scenario.FIRST_TOUCH to 10, Scenario.CROSS_INCOMING to 8, Scenario.RECEIVE_BOX to 3, Scenario.THROUGH_RUN to 3),
        Position.FULL_BACK to mapOf(Scenario.RECEIVE_PASS to 40, Scenario.CROSS_DELIVER to 38, Scenario.FIRST_TOUCH to 10, Scenario.RECEIVE_BOX to 5, Scenario.CROSS_INCOMING to 5, Scenario.THROUGH_RUN to 4),
        Position.MIDFIELDER to mapOf(Scenario.RECEIVE_PASS to 45, Scenario.FIRST_TOUCH to 15, Scenario.RECEIVE_BOX to 15, Scenario.LOOSE_BOX to 5, Scenario.CROSS_INCOMING to 5, Scenario.CROSS_DELIVER to 5, Scenario.THROUGH_RUN to 10),
        Position.WINGER to mapOf(Scenario.CROSS_DELIVER to 25, Scenario.RECEIVE_PASS to 20, Scenario.FIRST_TOUCH to 15, Scenario.RECEIVE_BOX to 20, Scenario.THROUGH_RUN to 15, Scenario.CROSS_INCOMING to 5),
        Position.STRIKER to mapOf(Scenario.RECEIVE_BOX to 28, Scenario.CROSS_INCOMING to 25, Scenario.THROUGH_RUN to 15, Scenario.LOOSE_BOX to 15, Scenario.RECEIVE_PASS to 10, Scenario.FIRST_TOUCH to 7)
    )
    private val defendW: Map<Position, Map<Scenario, Int>> = mapOf(
        Position.CENTER_BACK to mapOf(Scenario.CLEAR_HIGH to 40, Scenario.INTERCEPT to 30, Scenario.CLEAR_LOOSE to 30),
        Position.FULL_BACK to mapOf(Scenario.INTERCEPT to 55, Scenario.CLEAR_HIGH to 25, Scenario.CLEAR_LOOSE to 20),
        Position.MIDFIELDER to mapOf(Scenario.INTERCEPT to 75, Scenario.CLEAR_LOOSE to 15, Scenario.CLEAR_HIGH to 10),
        Position.WINGER to mapOf(Scenario.INTERCEPT to 85, Scenario.CLEAR_LOOSE to 10, Scenario.CLEAR_HIGH to 5),
        Position.STRIKER to mapOf(Scenario.INTERCEPT to 90, Scenario.CLEAR_LOOSE to 6, Scenario.CLEAR_HIGH to 4)
    )

    fun pick(pos: Position, attacking: Boolean): Scenario {
        val w = (if (attacking) attackW else defendW).getValue(pos)
        var r = rng.nextInt(w.values.sum())
        for ((k, v) in w) { if (r < v) return k; r -= v }
        return Scenario.RECEIVE_PASS
    }

    // ------------------------------------------------------------------ utilidades de escena
    private fun mateQ(role: Role): Float {
        val b = when (role) { Role.FWD -> 0.06f; Role.WING -> 0.03f; Role.MID -> 0f; else -> -0.05f }
        return (myQ + b + rf(-0.06f, 0.06f)).coerceIn(0.15f, 0.95f)
    }

    private fun rivalQ(role: Role): Float {
        val b = when (role) { Role.FWD -> 0.04f; Role.DEF -> 0.02f; else -> 0f }
        return (oppQ + b + rf(-0.06f, 0.06f)).coerceIn(0.15f, 0.95f)
    }

    private fun keeperFor(ballY: Float) =
        Keeper(Vec(103.6f, Pitch.CENTER_Y + (ballY - Pitch.CENTER_Y) * 0.12f), (oppQ + 0.08f + rf(-0.05f, 0.05f)).coerceIn(0.2f, 0.95f))

    private fun zoneOf(p: Vec): Zone = when {
        p.x < 16.5f && abs(p.y - 34f) < 20.2f -> Zone.OWN_BOX
        p.x < 35f -> Zone.OWN_THIRD
        p.x < 70f -> Zone.MIDFIELD
        p.x >= 88.5f && abs(p.y - 34f) < 20.2f -> Zone.BOX
        abs(p.y - 34f) > 20f -> Zone.WIDE_FINAL
        else -> Zone.FINAL_THIRD
    }

    private fun posWindow(pressure: Float, zone: Zone): Float {
        var w = mix(3.0f, 0.85f, pressure)
        if (zone == Zone.BOX) w *= 0.75f
        w += (readQ - 0.5f) * 0.4f + edge * 0.15f
        return w.coerceIn(0.7f, 3.2f)
    }

    private fun pressureOf(pl: Vec, rivals: List<Rival>, base: Float) =
        (0.55f * base + 0.45f * OpponentAI.pressureAt(pl, rivals)).coerceIn(0.05f, 0.95f)

    private fun spotFor(): Vec = when (position) {
        Position.CENTER_BACK -> Vec(rf(14f, 40f), rf(18f, 50f))
        Position.FULL_BACK -> Vec(rf(24f, 72f), if (rng.nextBoolean()) rf(5f, 16f) else rf(52f, 63f))
        Position.MIDFIELDER -> Vec(rf(30f, 72f), rf(14f, 54f))
        Position.WINGER -> Vec(rf(52f, 90f), if (rng.nextBoolean()) rf(5f, 15f) else rf(53f, 63f))
        Position.STRIKER -> Vec(rf(66f, 92f), rf(18f, 50f))
    }

    private fun makeMates(pl: Vec, n: Int = 4): MutableList<Mate> {
        val list = ArrayList<Mate>()
        val s = if (pl.y > 34f) -1f else 1f
        fun add(id: Int, pos: Vec, run: Vec, role: Role) {
            val p = Geo.clampPitch(pos)
            list.add(Mate(id, p, Geo.clampPitch(p + run), mateQ(role), role))
        }
        add(0, Vec(pl.x + rf(10f, 22f), pl.y + rf(-14f, 14f)), Vec(rf(6f, 14f), rf(-5f, 5f)), if (pl.x > 55f) Role.FWD else Role.MID)
        if (n > 1) add(1, Vec(pl.x + rf(3f, 12f), pl.y + s * rf(14f, 22f)), Vec(rf(4f, 10f), 0f), Role.WING)
        if (n > 2) add(2, Vec(pl.x - rf(6f, 14f), pl.y + rf(-10f, 10f)), Vec(rf(0f, 4f), rf(-3f, 3f)), Role.MID)
        if (n > 3) add(3, Vec(pl.x + rf(-4f, 6f), pl.y - s * rf(12f, 18f)), Vec(rf(2f, 8f), rf(-3f, 3f)), Role.MID)
        return list
    }

    private fun markRivals(pl: Vec, mates: List<Mate>, markerDist: Float, extra: Int): MutableList<Rival> {
        val out = ArrayList<Rival>()
        val ang = rf(-1.2f, 1.2f)
        out.add(Rival(Geo.clampPitch(Vec(pl.x + cos(ang) * markerDist, pl.y + sin(ang) * markerDist)), rivalQ(Role.DEF), Role.DEF))
        for (m in mates) if (m.pos.x > pl.x - 4f && rng.nextFloat() < 0.8f)
            out.add(Rival(Geo.clampPitch(Vec(m.pos.x + rf(1.8f, 5f), m.pos.y + rf(-3f, 3f))), rivalQ(Role.DEF), Role.DEF))
        for (i in 0 until extra) out.add(Rival(Geo.clampPitch(Vec(pl.x + rf(4f, 12f), pl.y + rf(-9f, 9f))), rivalQ(Role.DEF), Role.DEF))
        return out
    }

    private fun moment(
        type: KeyMomentType, mode: MomentMode, minute: Int, pl: Vec, ball: Vec, ballZ: Float,
        mates: List<Mate>, rivals: List<Rival>, keeper: Keeper?, pressure: Float, window: Float,
        actions: Set<IntentKind>, allowsPos: Boolean, incoming: Trajectory?, contact: ContactPoint?, depth: Int, context: String
    ): KeyMoment {
        val danger = (1f - hypot(Pitch.LENGTH - pl.x, Pitch.CENTER_Y - pl.y) / Pitch.LENGTH).coerceIn(0f, 1f)
        val vel = incoming?.velAt(0f) ?: Vec(0f, 0f)
        val hints: List<Vec> = if (readQ >= 0.55f) mates.map { Geo.clampPitch(it.run + (it.run - it.pos).norm() * 4f) } else emptyList()
        return KeyMoment(type, mode, minute, pl, ball, ballZ, vel, mates, rivals, keeper, pressure, window, zoneOf(pl), context,
            danger, actions, allowsPos, incoming, contact, true, readQ, hints, depth)
    }

    // ------------------------------------------------------------------ escenarios
    fun build(sc: Scenario, minute: Int, base: Float): KeyMoment = when (sc) {
        Scenario.RECEIVE_PASS -> buildReceivePass(minute, base)
        Scenario.RECEIVE_BOX -> buildShotBox(minute, base)
        Scenario.THROUGH_RUN -> buildThrough(minute, base)
        Scenario.FIRST_TOUCH -> buildFirstTouch(minute, base)
        Scenario.CROSS_DELIVER -> buildCrossDeliver(minute, base)
        Scenario.CROSS_INCOMING -> buildCrossIncoming(minute, base)
        Scenario.LOOSE_BOX -> buildLooseBox(minute, base)
        Scenario.INTERCEPT -> buildIntercept(minute, base)
        Scenario.CLEAR_HIGH -> buildClearHigh(minute, base)
        Scenario.CLEAR_LOOSE -> buildClearLoose(minute, base)
    }

    private fun buildReceivePass(minute: Int, base: Float): KeyMoment {
        val b0 = spotFor()
        val pl = Geo.clampPitch(Vec(b0.x + edge * 1.5f, b0.y))
        val mates = makeMates(pl)
        val md = (3.0f + edge * 1.4f + rf(-1f, 1.3f)).coerceIn(1.4f, 6f)
        val rivals = markRivals(pl, mates, md, 1)
        val shoot = pl.x > 78f && abs(pl.y - 34f) < 24f
        val keeper = if (pl.x > 78f) keeperFor(pl.y) else null
        val pr = pressureOf(pl, rivals, base)
        val actions = HashSet<IntentKind>(); actions.add(IntentKind.PASS); actions.add(IntentKind.SPACE_PASS)
        if (shoot) actions.add(IntentKind.SHOT)
        return moment(if (shoot) KeyMomentType.SHOT_MOMENT else KeyMomentType.PASS_MOMENT, MomentMode.POSITIONING, minute,
            pl, pl, 0.1f, mates, rivals, keeper, pr, posWindow(pr, zoneOf(pl)), actions, true, null, null, 0,
            "Posiciónate y decide")
    }

    private fun buildShotBox(minute: Int, base: Float): KeyMoment {
        var y = rf(20f, 48f)
        y += (34f - y) * 0.1f * edge
        val pl = Geo.clampPitch(Vec(rf(84f, 98f), y))
        val mates = makeMates(pl, 3)
        val md = (2.8f + edge * 1.2f + rf(-0.8f, 1.6f)).coerceIn(1.3f, 5.5f)
        val rivals = markRivals(pl, mates, md, 0)
        val pr = pressureOf(pl, rivals, base)
        return moment(KeyMomentType.SHOT_MOMENT, MomentMode.POSITIONING, minute, pl, pl, 0.1f, mates, rivals, keeperFor(pl.y), pr,
            posWindow(pr, Zone.BOX), setOf(IntentKind.SHOT, IntentKind.PASS, IntentKind.SPACE_PASS), true, null, null, 0, "Ocasión en el área")
    }

    private fun buildThrough(minute: Int, base: Float): KeyMoment {
        val pl = Geo.clampPitch(Vec(rf(66f, 84f), rf(14f, 54f)))
        val mates = makeMates(pl, 2)
        val rivals = ArrayList<Rival>()
        val d = (3.5f + edge * 1.2f + rf(0f, 2.5f)).coerceIn(2f, 7f)
        rivals.add(Rival(Geo.clampPitch(Vec(pl.x - d * 0.6f, pl.y + rf(-d, d))), rivalQ(Role.DEF), Role.DEF))
        for (m in mates) rivals.add(Rival(Geo.clampPitch(Vec(m.pos.x + rf(2f, 5f), m.pos.y + rf(-3f, 3f))), rivalQ(Role.DEF), Role.DEF))
        val shoot = pl.x > 78f
        val pr = pressureOf(pl, rivals, base * 0.7f)
        val actions = HashSet<IntentKind>(); actions.add(IntentKind.PASS); actions.add(IntentKind.SPACE_PASS)
        if (shoot) actions.add(IntentKind.SHOT)
        val w = (posWindow(pr, zoneOf(pl)) + 0.4f).coerceAtMost(3.2f)
        return moment(if (shoot) KeyMomentType.SHOT_MOMENT else KeyMomentType.PASS_MOMENT, MomentMode.POSITIONING, minute, pl, pl, 0.1f,
            mates, rivals, if (shoot) keeperFor(pl.y) else null, pr, w, actions, true, null, null, 0, "Balón al espacio")
    }

    private fun buildCrossDeliver(minute: Int, base: Float): KeyMoment {
        val top = rng.nextBoolean()
        val pl = Vec(rf(70f, 92f), if (top) rf(5f, 10f) else rf(58f, 63f))
        val inward = if (top) 1f else -1f
        val mates = ArrayList<Mate>()
        fun add(id: Int, p: Vec, role: Role) { mates.add(Mate(id, Geo.clampPitch(p), Geo.clampPitch(p + Vec(rf(1f, 4f), rf(-2f, 2f))), mateQ(role), role)) }
        add(0, Vec(rf(94f, 100f), rf(28f, 40f)), Role.FWD)
        add(1, Vec(rf(90f, 96f), 34f + inward * rf(8f, 14f) * (if (top) 1f else 1f)), Role.WING)
        add(2, Vec(rf(84f, 90f), rf(26f, 42f)), Role.MID)
        val rivals = ArrayList<Rival>()
        rivals.add(Rival(Geo.clampPitch(Vec(pl.x + rf(0f, 2f), pl.y + inward * (3.5f + edge * 1.2f + rf(0f, 2f)))), rivalQ(Role.DEF), Role.DEF))
        for (m in mates) rivals.add(Rival(Geo.clampPitch(Vec(m.pos.x + rf(1.5f, 4f), m.pos.y + rf(-3f, 3f))), rivalQ(Role.DEF), Role.DEF))
        val pr = pressureOf(pl, rivals, base * 0.8f)
        val w = (posWindow(pr, Zone.WIDE_FINAL) + 0.2f).coerceIn(1.0f, 2.8f)
        return moment(KeyMomentType.CROSS_MOMENT, MomentMode.POSITIONING, minute, pl, pl, 0.1f, mates, rivals, keeperFor(pl.y), pr, w,
            setOf(IntentKind.CROSS, IntentKind.PASS, IntentKind.SPACE_PASS), true, null, null, 0, "Hay hombres en el área")
    }

    private class Inc(val traj: Trajectory, val cp: ContactPoint)

    private fun crossIncoming(pl: Vec, cz: Float, t: Float, arr: Float, ahead: Boolean): Inc {
        val ang = rng.nextFloat() * 6.283f
        val cxy = Geo.clampPitch(Vec(pl.x + cos(ang) * arr, pl.y + sin(ang) * arr))
        val side = if (rng.nextBoolean()) 1f else -1f
        val dx = rf(8f, 16f) * (if (ahead) 1f else -1f)
        val a = Geo.clampPitch(Vec(cxy.x + dx, cxy.y + side * rf(8f, 16f)))
        return Inc(Trajectory.arc(a, cxy, cz + 2.0f, cz, 0.5f, t, false), ContactPoint(cxy, cz))
    }

    private fun buildCrossIncoming(minute: Int, base: Float): KeyMoment {
        val pl = Geo.clampPitch(Vec(rf(91f, 99f), rf(26f, 42f)))
        val arr = (rf(0.8f, 3.4f) - edge * 0.9f).coerceIn(0.5f, 4.2f)
        val r = rng.nextFloat()
        val type: KeyMomentType; val z: Float; val t: Float
        when {
            r < 0.14f -> { type = KeyMomentType.CHILENA_MOMENT; z = rf(1.2f, 1.8f); t = rf(0.45f, 0.7f) }
            r < 0.34f -> { type = KeyMomentType.VOLLEY_MOMENT; z = rf(0.5f, 0.95f); t = rf(0.55f, 0.95f) }
            else -> { type = KeyMomentType.HEADER_MOMENT; z = rf(1.5f, 2.2f); t = rf(0.6f, 1.1f) }
        }
        val inc = crossIncoming(pl, z, t, arr, false)
        val mates = makeMates(pl, 2)
        val rivals = ArrayList<Rival>()
        for (i in 0 until 3) rivals.add(Rival(Geo.clampPitch(Vec(pl.x + rf(-2f, 4f), pl.y + rf(-6f, 6f))), rivalQ(Role.DEF), Role.DEF))
        val mode = if (type == KeyMomentType.CHILENA_MOMENT) MomentMode.ACROBATIC else MomentMode.REACTION
        val pr = pressureOf(pl, rivals, base)
        val ctx = if (type == KeyMomentType.CHILENA_MOMENT) "¡Balón acrobático!" else "¡Centro al área!"
        return moment(type, mode, minute, pl, inc.traj.samples[0].let { Vec(it.x, it.y) }, inc.traj.samples[0].z, mates, rivals, keeperFor(pl.y), pr,
            t, setOf(IntentKind.SHOT, IntentKind.PASS), false, inc.traj, inc.cp, 0, ctx)
    }

    private fun buildLooseBox(minute: Int, base: Float): KeyMoment {
        val pl = Geo.clampPitch(Vec(rf(88f, 98f), rf(24f, 44f)))
        val mates = makeMates(pl, 2)
        val rivals = markRivals(pl, mates, rf(3f, 6f), 1)
        val kp = keeperFor(pl.y)
        val w = World(pl, mates, rivals, kp)
        val reb = loose(Vec(rf(100f, 103f), 34f + rng.gauss() * 3f))
        return reboundMoment(w, reb, minute, 0)?.moment ?: buildShotBox(minute, base)
    }

    private fun loose(at: Vec): Trajectory {
        val dir = Vec(-1f, 0f).rot(rng.gauss() * 0.7f)
        val l = BallPhysics.launch(dir, rf(4f, 9f), rf(0f, 0.3f))
        return BallPhysics.simulate(at, 0.3f, l, 1.8f)
    }

    private fun buildFirstTouch(minute: Int, base: Float): KeyMoment {
        val pl = spotFor()
        val passer = Geo.clampPitch(Vec(pl.x - rf(14f, 24f), pl.y + rf(-10f, 10f)))
        val t = rf(0.9f, 1.5f)
        val traj = Trajectory.arc(passer, pl, 0.1f, 0.1f, if (rng.nextFloat() < 0.35f) 0.9f else 0f, t, true)
        val mates = makeMates(pl)
        mates.add(Mate(9, passer, passer, mateQ(Role.MID), Role.MID))
        val rivals = markRivals(pl, mates, (4.5f + edge * 1.2f + rf(0f, 2f)).coerceIn(2f, 7f), 0)
        val pr = pressureOf(pl, rivals, base)
        return moment(KeyMomentType.FIRST_TOUCH_MOMENT, MomentMode.REACTION, minute, pl, passer, 0.1f, mates, rivals,
            if (pl.x > 78f) keeperFor(pl.y) else null, pr, t, setOf(IntentKind.CONTROL), false, traj, ContactPoint(pl, 0.1f), 0,
            "Orienta tu primer toque")
    }

    private fun buildIntercept(minute: Int, base: Float): KeyMoment {
        val pl = Geo.clampPitch(Vec(rf(25f, 75f), rf(14f, 54f)))
        val miss = (rf(2.5f, 6f) - edge * 0.9f).coerceIn(1.2f, 7f)
        val ang = rf(0f, 6.283f)
        val cp = Geo.clampPitch(Vec(pl.x + cos(ang) * miss, pl.y + sin(ang) * miss))
        val d = Vec(-1f, 0f).rot(rf(-0.5f, 0.5f))
        val v = rf(12f, 18f); val t0 = rf(0.8f, 1.25f)
        val a = Geo.clampPitch(cp - d * (v * t0))
        val b = Geo.clampPitch(cp + d * rf(10f, 16f))
        val total = max(1f, a.dist(b))
        val dur = total / v
        val tc = dur * a.dist(cp) / total
        val traj = Trajectory.arc(a, b, 0.1f, 0.1f, if (rng.nextFloat() < 0.3f) 0.8f else 0f, dur, false)
        val mates = makeMates(pl, 2)
        val rivals = ArrayList<Rival>()
        rivals.add(Rival(a, rivalQ(Role.MID), Role.MID))
        rivals.add(Rival(b, rivalQ(Role.FWD), Role.FWD))
        rivals.add(Rival(Geo.clampPitch(Vec(pl.x - rf(4f, 9f), pl.y + rf(-8f, 8f))), rivalQ(Role.FWD), Role.FWD))
        val pr = pressureOf(pl, rivals, base)
        return moment(KeyMomentType.INTERCEPTION_MOMENT, MomentMode.REACTION, minute, pl, a, 0.1f, mates, rivals, null, pr, max(0.45f, tc),
            setOf(IntentKind.INTERCEPT), false, traj, ContactPoint(cp, 0.1f), 0, "El rival juega el balón")
    }

    private fun buildClearHigh(minute: Int, base: Float): KeyMoment {
        val pl = Geo.clampPitch(Vec(rf(7f, 15f), rf(24f, 44f)))
        val arr = (rf(0.8f, 3.2f) - edge * 0.9f).coerceIn(0.5f, 4f)
        val z = rf(1.3f, 2.2f); val t = rf(0.7f, 1.2f)
        val inc = crossIncoming(pl, z, t, arr, true)
        val mates = ArrayList<Mate>()
        mates.add(Mate(0, Geo.clampPitch(Vec(pl.x + rf(-3f, 5f), pl.y + rf(-8f, 8f))), pl, mateQ(Role.DEF), Role.DEF))
        mates.add(Mate(1, Geo.clampPitch(Vec(pl.x + rf(2f, 8f), pl.y + rf(-12f, 12f))), pl, mateQ(Role.DEF), Role.DEF))
        val rivals = ArrayList<Rival>()
        for (i in 0 until 3) rivals.add(Rival(Geo.clampPitch(Vec(pl.x + rf(-1f, 4f), pl.y + rf(-7f, 7f))), rivalQ(Role.FWD), Role.FWD))
        val pr = pressureOf(pl, rivals, base)
        return moment(KeyMomentType.CLEARANCE_MOMENT, MomentMode.REACTION, minute, pl, Vec(inc.traj.samples[0].x, inc.traj.samples[0].y),
            inc.traj.samples[0].z, mates, rivals, null, pr, t, setOf(IntentKind.CLEARANCE), false, inc.traj, inc.cp, 0, "¡Centro rival a tu área!")
    }

    private fun buildClearLoose(minute: Int, base: Float): KeyMoment {
        val pl = Geo.clampPitch(Vec(rf(6f, 16f), rf(24f, 44f)))
        val arr = (rf(0.8f, 3f) - edge * 0.8f).coerceIn(0.5f, 3.8f)
        val ang = rf(0f, 6.283f)
        val cp = Geo.clampPitch(Vec(pl.x + cos(ang) * arr, pl.y + sin(ang) * arr))
        val s = Geo.clampPitch(Vec(cp.x + rf(4f, 9f), cp.y + rf(-6f, 6f)))
        val t = rf(0.55f, 0.95f)
        val traj = Trajectory.arc(s, cp, 0.3f, 0.2f, 0.6f, t, true)
        val mates = ArrayList<Mate>()
        mates.add(Mate(0, Geo.clampPitch(Vec(pl.x + rf(2f, 8f), pl.y + rf(-10f, 10f))), pl, mateQ(Role.DEF), Role.DEF))
        val rivals = ArrayList<Rival>()
        for (i in 0 until 2) rivals.add(Rival(Geo.clampPitch(Vec(cp.x + rf(1f, 5f), cp.y + rf(-5f, 5f))), rivalQ(Role.FWD), Role.FWD))
        val pr = pressureOf(pl, rivals, base)
        return moment(KeyMomentType.CLEARANCE_MOMENT, MomentMode.REACTION, minute, pl, s, 0.3f, mates, rivals, null, pr, t,
            setOf(IntentKind.CLEARANCE), false, traj, ContactPoint(cp, 0.2f), 0, "¡Balón suelto en tu área!")
    }

    // ------------------------------------------------------------------ continuaciones de jugada
    private fun nearestContact(traj: Trajectory, p: Vec, tMin: Float, tMax: Float, zMax: Float, zMin: Float): Pair<BallSample, Float>? {
        var best: BallSample? = null; var bd = 1e9f
        for (s in traj.samples) {
            if (s.t < tMin || s.t > tMax || s.z > zMax || s.z < zMin) continue
            val d = hypot(s.x - p.x, s.y - p.y)
            if (d < bd) { bd = d; best = s }
        }
        val b = best ?: return null
        return Pair(b, bd)
    }

    fun reboundMoment(w: World, reb: Trajectory, minute: Int, depth: Int): Split? {
        if (depth > 4) return null
        val (best, bd) = nearestContact(reb, w.player, 0.45f, 1.8f, 1.3f, 0f) ?: return null
        if (bd > 13f) return null
        val tc = best.t
        val t = min(tc, 1.0f)
        val t0 = tc - t
        val inc = reb.sub(t0, tc)
        val cp = ContactPoint(Vec(best.x, best.y), best.z)
        val pl = Geo.clampPitch(w.player + (cp.pos - w.player).norm() * max(0f, min(bd - 2f, 4f)))
        val pr = pressureOf(pl, w.rivals, 0.4f)
        val m = moment(KeyMomentType.REBOUND_MOMENT, MomentMode.REACTION, minute, pl, Vec(inc.samples[0].x, inc.samples[0].y), inc.samples[0].z,
            w.mates.map { it.copyOf() }, w.rivals.map { it.copyOf() }, w.keeper?.copyOf(), pr, t,
            setOf(IntentKind.SHOT, IntentKind.PASS), false, inc, cp, depth, "¡Rechace! Remata ya")
        return Split(m, t0)
    }

    fun oneTwoMoment(w: World, traj: Trajectory, cp: Vec, minute: Int, depth: Int): KeyMoment? {
        if (depth > 4) return null
        val pr = pressureOf(w.player, w.rivals, 0.4f)
        return moment(KeyMomentType.ONE_TWO_MOMENT, MomentMode.REACTION, minute, w.player, Vec(traj.samples[0].x, traj.samples[0].y), 0.1f,
            w.mates.map { it.copyOf() }, w.rivals.map { it.copyOf() }, w.keeper?.copyOf() ?: (if (w.player.x > 78f) keeperFor(w.player.y) else null),
            pr, max(0.5f, traj.duration), setOf(IntentKind.SHOT, IntentKind.PASS), false, traj, ContactPoint(cp, 0.1f), depth, "¡Te devuelven la pared!")
    }

    fun headerFromCross(w: World, traj: Trajectory, minute: Int, depth: Int): Split? {
        if (depth > 4) return null
        val (best, bd) = nearestContact(traj, w.player, 0.6f, 4f, 2.4f, 0.4f) ?: return null
        if (bd > 7f) return null
        val tc = best.t
        val t = min(tc, 1.1f)
        val t0 = tc - t
        val inc = traj.sub(t0, tc)
        val cp = ContactPoint(Vec(best.x, best.y), best.z)
        val type = when {
            best.z in 1.2f..1.8f && rng.nextFloat() < 0.12f -> KeyMomentType.CHILENA_MOMENT
            best.z < 1.0f -> KeyMomentType.VOLLEY_MOMENT
            else -> KeyMomentType.HEADER_MOMENT
        }
        val mode = if (type == KeyMomentType.CHILENA_MOMENT) MomentMode.ACROBATIC else MomentMode.REACTION
        val pr = pressureOf(w.player, w.rivals, 0.4f)
        val m = moment(type, mode, minute, w.player, Vec(inc.samples[0].x, inc.samples[0].y), inc.samples[0].z,
            w.mates.map { it.copyOf() }, w.rivals.map { it.copyOf() }, w.keeper?.copyOf() ?: keeperFor(w.player.y), pr, max(0.4f, t),
            setOf(IntentKind.SHOT, IntentKind.PASS), false, inc, cp, depth, "¡Centro! Puedes llegar")
        return Split(m, t0)
    }

    fun clearanceLoose(w: World, traj: Trajectory, minute: Int, depth: Int): Split? {
        if (depth > 4) return null
        val (best, bd) = nearestContact(traj, w.player, 0.45f, 1.8f, 2.2f, 0f) ?: return null
        if (bd > 12f) return null
        val tc = best.t
        val t = min(tc, 1.0f)
        val t0 = tc - t
        val inc = traj.sub(t0, tc)
        val cp = ContactPoint(Vec(best.x, best.y), best.z)
        val pl = Geo.clampPitch(w.player + (cp.pos - w.player).norm() * max(0f, min(bd - 2f, 4f)))
        val pr = pressureOf(pl, w.rivals, 0.5f)
        val m = moment(KeyMomentType.CLEARANCE_MOMENT, MomentMode.REACTION, minute, pl, Vec(inc.samples[0].x, inc.samples[0].y), inc.samples[0].z,
            w.mates.map { it.copyOf() }, w.rivals.map { it.copyOf() }, null, pr, max(0.4f, t),
            setOf(IntentKind.CLEARANCE), false, inc, cp, depth, "¡El balón sigue en tu área!")
        return Split(m, t0)
    }

    fun passAfterIntercept(w: World, at: Vec, minute: Int, depth: Int): KeyMoment? {
        if (depth > 4) return null
        val mates = w.mates.map { it.copyOf() }
        for (m in mates) m.run = Geo.clampPitch(m.pos + Vec(rf(4f, 10f), rf(-4f, 4f)))
        val rivals = w.rivals.map { it.copyOf() }
        val pr = pressureOf(at, rivals, 0.3f)
        val actions = HashSet<IntentKind>(); actions.add(IntentKind.PASS); actions.add(IntentKind.SPACE_PASS)
        if (at.x > 78f) actions.add(IntentKind.SHOT)
        return moment(KeyMomentType.PASS_MOMENT, MomentMode.POSITIONING, minute, at, at, 0.1f, mates, rivals,
            if (at.x > 78f) keeperFor(at.y) else null, pr, rf(1.0f, 1.9f), actions, true, null, null, depth, "¡Contraataque! Juega rápido")
    }

    fun afterFirstTouch(w: World, newPos: Vec, minute: Int, forward: Float, shield: Boolean, depth: Int): KeyMoment? {
        if (depth > 4) return null
        val mates = w.mates.map { it.copyOf() }
        val rivals = w.rivals.map { it.copyOf() }
        var pr = OpponentAI.pressureAt(newPos, rivals)
        if (shield) pr *= 0.8f
        pr = pr.coerceIn(0.05f, 0.95f)
        val shoot = newPos.x > 78f && abs(newPos.y - 34f) < 24f
        val actions = HashSet<IntentKind>(); actions.add(IntentKind.PASS); actions.add(IntentKind.SPACE_PASS)
        if (shoot) actions.add(IntentKind.SHOT)
        var win = posWindow(pr, zoneOf(newPos)) * (1f - 0.2f * forward.coerceIn(0f, 1f))
        if (shield) win += 0.3f
        return moment(if (shoot) KeyMomentType.SHOT_MOMENT else KeyMomentType.PASS_MOMENT, MomentMode.POSITIONING, minute,
            newPos, newPos, 0.1f, mates, rivals, w.keeper?.copyOf() ?: (if (newPos.x > 78f) keeperFor(newPos.y) else null), pr,
            win.coerceIn(0.6f, 3.2f), actions, true, null, null, depth, "Tras tu primer toque")
    }
}
