package com.goatjourney.rendering.pixel

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.*

/**
 * Estadio en pixel art: gradas con público, vallas publicitarias, césped con textura de corte, porterías con red,
 * banderines de córner y túnel. Las texturas se generan una vez (determinista) y se pintan sin filtrado.
 */
class Stadium {
    private var crowd: Bitmap? = null
    private var grass: Bitmap? = null
    private var crowdKey = 0
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val fill = Paint()
    private val src = Rect()
    private val dst = RectF()
    private val tilePx = 128                       // lado de la textura en píxeles lógicos
    private val tileRef = 128 * PX.LP              // ... y en referencia

    private fun rnd(a: Int, b: Int, s: Int): Int {
        var h = a * 374761393 + b * 668265263 + s * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        return (h xor (h ushr 16)) and 0x7fffffff
    }

    private fun buildCrowd(c1: Int, c2: Int): Bitmap {
        val n = tilePx
        val b = PixBuf(n, n)
        val concrete = intArrayOf(0xFF2A2F3F.toInt(), 0xFF232838.toInt())
        for (y in 0 until n) for (x in 0 until n) b.put(x, y, concrete[(y / 2) % 2], 1)
        val skins = intArrayOf(0xFFFBD5B5.toInt(), 0xFFEAB98C.toInt(), 0xFFC98E5F.toInt(), 0xFFA46A3F.toInt(), 0xFF7A4A28.toInt())
        val hairs = intArrayOf(0xFF1A1208.toInt(), 0xFF4A2C12.toInt(), 0xFF8B5A2B.toInt(), 0xFFD9B35B.toInt(), 0xFF9A9A9A.toInt())
        val shirts = intArrayOf(c1, c2, c1, PC.shade(c1, 0.7f), 0xFFF2F2F2.toInt(), 0xFF3A4260.toInt(), 0xFF8A2A3A.toInt(), c2)
        val rowH = 8
        for (row in 0 until n / rowH) {
            val y0 = row * rowH
            // grada: escalón claro con sombra
            for (x in 0 until n) { b.put(x, y0 + 7, 0xFF181C28.toInt(), 1); b.put(x, y0 + 6, 0xFF343A50.toInt(), 1) }
            var x = (rnd(row, 1, 5) % 3)
            while (x < n - 4) {
                val r = rnd(x, row, 9)
                if (r % 7 != 0) {
                    val skin = skins[r % skins.size]
                    val hair = hairs[(r / 7) % hairs.size]
                    val shirt = shirts[(r / 53) % shirts.size]
                    // cabeza 2x2 (+ pelo), torso 4x3
                    b.put(x + 1, y0 + 1, hair, 2); b.put(x + 2, y0 + 1, hair, 2)
                    b.put(x + 1, y0 + 2, skin, 2); b.put(x + 2, y0 + 2, skin, 2)
                    for (tx in 0..3) for (ty in 3..5) b.put(x + tx, y0 + ty, if (ty == 5) PC.shade(shirt, 0.7f) else shirt, 2)
                    if ((r / 11) % 9 == 0) { b.put(x - 1, y0 + 2, skin, 2); b.put(x - 1, y0 + 1, skin, 2) } // brazo arriba
                }
                x += 4 + (r / 3) % 2
            }
        }
        // pasillos verticales (escaleras) y algún banderín/pancarta
        for (k in 0 until 4) { val sx = k * 32 + 31; for (y in 0 until n) { b.put(sx, y, 0xFF141824.toInt(), 3); b.put(sx - 1, y, 0xFF3C435C.toInt(), 3) } }
        for (k in 0 until 3) {
            val bx = 10 + k * 40 + rnd(k, 3, 2) % 8; val by = (k * 3 + 1) * rowH
            val col = if (k % 2 == 0) c1 else c2
            for (xx in 0 until 14) for (yy in 0 until 4) b.put(bx + xx, by + yy, if (yy == 3) PC.shade(col, 0.7f) else col, 4)
        }
        return Bitmap.createBitmap(b.c, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun buildGrass(): Bitmap {
        val n = 64
        val b = PixBuf(n, n)
        for (y in 0 until n) for (x in 0 until n) {
            val r = rnd(x, y, 77) % 100
            if (r < 9) b.put(x, y, 0x26000000, 1)            // brizna oscura
            else if (r < 15) b.put(x, y, 0x22FFFFFF, 1)      // brizna clara
            else if (r < 17) b.put(x, y, 0x30FFFFFF, 1)
        }
        return Bitmap.createBitmap(b.c, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun ensure(c1: Int, c2: Int) {
        val k = c1 * 31 + c2
        if (crowd == null || k != crowdKey) { crowd = buildCrowd(c1, c2); crowdKey = k }
        if (grass == null) grass = buildGrass()
    }

    private fun tileFill(c: Canvas, bm: Bitmap, size: Float, left: Float, top: Float, right: Float, bottom: Float, ox: Float, oy: Float) {
        val bw = bm.width; val bh = bm.height
        src.set(0, 0, bw, bh)
        var y: Float
        // alinear la rejilla de texturas al origen (ox, oy) para que se mueva con el mundo
        val startY = oy + floor((top - oy) / size) * size
        val startX = ox + floor((left - ox) / size) * size
        y = startY
        while (y < bottom) {
            var x = startX
            while (x < right) {
                dst.set(x, y, x + size, y + size)
                c.drawBitmap(bm, src, dst, paint)
                x += size
            }
            y += size
        }
    }

    /**
     * [l], [r], [top], [bot]: rectángulo del campo en pantalla (px de referencia). [z]: px por metro.
     * Dibuja todo lo que rodea al césped; después el partido dibuja el campo encima.
     */
    fun drawSurround(c: Canvas, l: Float, r: Float, top: Float, bot: Float, z: Float, c1: Int, c2: Int, time: Float) {
        ensure(c1, c2)
        val cw = Ref_W; val ch = Ref_H
        // gradas: público en toda la pantalla (lo cubren después la pista y el césped)
        tileFill(c, crowd!!, tileRef, 0f, 0f, cw, ch, l, top)
        // sombra de la grada (más oscura lejos del campo)
        fill.color = 0x40000000
        c.drawRect(0f, 0f, cw, ch, fill)
        // túnel de vestuarios (lateral izquierdo, a la altura del centro)
        val tm = (top + bot) / 2f
        val tx1 = l - 6.5f * z; val tx0 = l - 14f * z
        fill.color = 0xFF0B0D16.toInt(); c.drawRect(tx0, tm - 3.4f * z, tx1, tm + 3.4f * z, fill)
        fill.color = 0xFF4A5170.toInt()
        c.drawRect(tx0, tm - 3.4f * z - PX.LP * 2f, tx1, tm - 3.4f * z, fill)
        c.drawRect(tx0, tm + 3.4f * z, tx1, tm + 3.4f * z + PX.LP * 2f, fill)
        // pista perimetral (césped corto + zona técnica)
        val m = 6.0f * z
        fill.color = 0xFF1B5A30.toInt(); c.drawRect(l - m, top - m, r + m, bot + m, fill)
        tileFill(c, grass!!, 64 * PX.LP, l - m, top - m, r + m, bot + m, l, top)
        // vallas publicitarias (4 lados) con módulos de colores
        val bo = 5.2f * z; val bt = max(PX.LP * 5f, 0.95f * z)
        val mods = intArrayOf(c1, 0xFFF2F2F2.toInt(), c2, 0xFF1E3A8A.toInt(), 0xFFE53935.toInt(), 0xFF111827.toInt(), 0xFFFFC857.toInt(), 0xFF2EE6A6.toInt())
        var xx = l - bo
        var k = 0
        val modW = 7.5f * z
        while (xx < r + bo) {
            val x1 = min(xx + modW, r + bo)
            fill.color = mods[k % mods.size]
            c.drawRect(xx, top - bo - bt, x1, top - bo, fill)
            c.drawRect(xx, bot + bo, x1, bot + bo + bt, fill)
            fill.color = withA(0xFF000000.toInt(), 70)
            c.drawRect(xx, top - bo - bt * 0.35f, x1, top - bo, fill)
            c.drawRect(xx, bot + bo, x1, bot + bo + bt * 0.35f, fill)
            // "texto" de patrocinador: bloques de píxeles
            fill.color = withA(0xFFFFFFFF.toInt(), 150)
            var bx = xx + PX.LP * 3f
            while (bx < x1 - PX.LP * 5f) { c.drawRect(bx, top - bo - bt * 0.75f, bx + PX.LP * 2f, top - bo - bt * 0.45f, fill); c.drawRect(bx, bot + bo + bt * 0.25f, bx + PX.LP * 2f, bot + bo + bt * 0.55f, fill); bx += PX.LP * 4f }
            xx = x1; k++
        }
        var yy = top - bo
        k = 3
        while (yy < bot + bo) {
            val y1 = min(yy + modW, bot + bo)
            fill.color = mods[k % mods.size]
            c.drawRect(l - bo - bt, yy, l - bo, y1, fill)
            c.drawRect(r + bo, yy, r + bo + bt, y1, fill)
            fill.color = withA(0xFF000000.toInt(), 70)
            c.drawRect(l - bo - bt * 0.35f, yy, l - bo, y1, fill)
            c.drawRect(r + bo, yy, r + bo + bt * 0.35f, y1, fill)
            yy = y1; k++
        }
    }

    /** Césped: franjas de corte + textura. Se dibuja encima de [drawSurround]. */
    fun drawTurf(c: Canvas, l: Float, r: Float, top: Float, bot: Float, grass1: Int, grass2: Int) {
        val n = 14
        val h = (bot - top) / n
        for (i in 0 until n) {
            fill.color = if (i % 2 == 0) grass1 else grass2
            c.drawRect(l, top + i * h, r, top + (i + 1) * h, fill)
        }
        c.save()
        c.clipRect(l, top, r, bot)
        tileFill(c, grass!!, 64 * PX.LP, l, top, r, bot, l, top)
        c.restore()
    }

    /** Portería con red y palos; [dir] = -1 portería de arriba (hacia el exterior por arriba), +1 de abajo. */
    fun drawGoal(c: Canvas, x0: Float, x1: Float, lineY: Float, depth: Float, dir: Int, z: Float) {
        val y0 = if (dir < 0) lineY - depth else lineY
        val y1 = if (dir < 0) lineY else lineY + depth
        fill.color = 0xFF0E1A12.toInt()
        c.drawRect(x0, y0, x1, y1, fill)
        fill.color = 0x66FFFFFF
        val step = PX.LP * 3f
        var x = x0
        while (x < x1) { c.drawRect(x, y0, x + PX.LP * 0.75f, y1, fill); x += step }
        var y = y0
        while (y < y1) { c.drawRect(x0, y, x1, y + PX.LP * 0.75f, fill); y += step }
        val p = max(PX.LP * 2f, z * 0.28f)
        fill.color = 0xFFF2F2F2.toInt()
        c.drawRect(x0 - p, y0, x0, y1, fill); c.drawRect(x1, y0, x1 + p, y1, fill)
        c.drawRect(x0 - p, if (dir < 0) y0 else y1 - p, x1 + p, if (dir < 0) y0 + p else y1, fill)
    }

    fun drawCornerFlag(c: Canvas, x: Float, y: Float, up: Boolean, color: Int, z: Float) {
        val h = max(PX.LP * 8f, z * 1.5f)
        fill.color = 0xFFF2F2F2.toInt()
        val top = if (up) y - h else y
        c.drawRect(x - PX.LP * 0.5f, top, x + PX.LP * 0.5f, top + h, fill)
        fill.color = color
        c.drawRect(x + PX.LP * 0.5f, top, x + PX.LP * 4f, top + PX.LP * 3f, fill)
    }

    private fun withA(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    private val Ref_W = 720f
    private val Ref_H = 1280f
}
