package com.goatjourney.rendering.pixel

import com.goatjourney.core.player.Appearance

/** Fábrica de aspectos. Todo es determinista (semilla -> persona), así nada nuevo se guarda en la partida. */
object Looks {
    private fun mixHash(a: Int): Int {
        var h = a * -0x61c88647
        h = h xor (h ushr 15); h *= 0x2c1b3c6d; h = h xor (h ushr 12); h *= 0x297a2d39; h = h xor (h ushr 15)
        return h
    }

    private fun pick(h: Int, shift: Int, n: Int): Int = Math.floorMod(h ushr shift, n)

    fun nameSeed(s: String): Int { var h = 7; for (ch in s) h = h * 31 + ch.code; return mixHash(h) }

    private fun contrast(c: Int): Int = if (PC.luma(c) > 150) 0xFF1A1A22.toInt() else 0xFFF2F2F2.toInt()

    /** Persona genérica de reparto (compañeros, rivales, árbitros, NPC). */
    fun npc(seed: Int, shirt: Int, shirt2: Int, shorts: Int, socks: Int, pattern: Int, number: Int, keeper: Boolean = false): Look {
        val h = mixHash(seed)
        val skinIdx = when (pick(h, 0, 10)) { 0, 1, 2 -> 1; 3, 4 -> 0; 5, 6 -> 2; 7 -> 3; 8 -> 4; else -> 5 }
        val hairIdx = when (pick(h, 4, 10)) { 0, 1, 2, 3 -> 0; 4, 5 -> 1; 6 -> 2; 7 -> 3; 8 -> 4; else -> 5 }
        val styleRoll = pick(h, 8, 14)
        val style = if (styleRoll < 10) styleRoll else when (styleRoll) { 10 -> 0; 11 -> 3; 12 -> 1; else -> 9 }
        val beard = if (pick(h, 12, 100) < 34) 1 + pick(h, 19, 3) else 0
        val build = pick(h, 22, 4)
        val hf = 0.95f + pick(h, 25, 12) * 0.01f
        var hair = Appearance.HAIRS[hairIdx]
        if (pick(h, 27, 12) == 0) hair = 0xFF9A9A9A.toInt()   // veterano canoso
        return Look(
            skin = Appearance.SKINS[skinIdx], hair = hair, hairStyle = style, beard = beard, brow = 1 + pick(h, 29, 2),
            build = build, heightF = hf, jaw = pick(h, 30, 3),
            shirt = shirt, shirt2 = shirt2, pattern = if (keeper) 0 else pattern,
            shorts = shorts, shorts2 = shirt2,
            socks = socks, socks2 = shirt2,
            boots = if (pick(h, 31, 5) == 0) 0xFFF2F2F2.toInt() else 0xFF15151C.toInt(),
            number = number, keeper = keeper, longSleeves = keeper
        )
    }

    /** El protagonista: usa su Appearance; el resto de rasgos salen de su nombre (siempre la misma cara). */
    fun protagonist(a: Appearance, name: String, shirt: Int, shirt2: Int, shorts: Int, socks: Int, pattern: Int, number: Int, build: Int): Look {
        val h = mixHash(nameSeed(name))
        return Look(
            skin = Appearance.SKINS[a.skin.coerceIn(0, Appearance.SKINS.size - 1)],
            hair = Appearance.HAIRS[a.hair.coerceIn(0, Appearance.HAIRS.size - 1)],
            hairStyle = a.hairStyle.coerceIn(0, 3),
            beard = if (pick(h, 4, 100) < 22) 1 + pick(h, 11, 2) else 0, brow = 2, build = build, heightF = 1.02f, jaw = pick(h, 15, 3),
            shirt = shirt, shirt2 = shirt2, pattern = pattern, shorts = shorts, shorts2 = shirt2, socks = socks, socks2 = shirt2,
            boots = Appearance.ACCENTS[a.shirt.coerceIn(0, Appearance.ACCENTS.size - 1)], number = number
        )
    }

    /** Aspecto para pantallas de menú (la API antigua de figuras). */
    fun menu(skin: Int, hair: Int, hairStyle: Int, shirt: Int, shorts: Int, accent: Int): Look {
        val i = hairStyle.coerceIn(0, 3)
        return Look(
            skin = skin, hair = hair, hairStyle = i, brow = 2, build = 1, jaw = 1,
            shirt = shirt, shirt2 = accent, pattern = 0, shorts = shorts, shorts2 = accent, socks = shirt, socks2 = accent,
            boots = PC.shade(accent, 0.45f), number = 10
        )
    }
}
