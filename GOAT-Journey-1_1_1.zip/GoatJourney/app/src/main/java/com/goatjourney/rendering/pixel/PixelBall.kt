package com.goatjourney.rendering.pixel

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.*

/**
 * Balón en pixel art: una esfera con 12 parches (icosaedro truncado) rasterizada en una cuadrícula lógica n x n.
 * Es la MISMA cuadrícula (32 x 32) que usa la fase de contacto: cada celda visible corresponde a un punto de contacto.
 */
object PixelBall {
    private val cache = HashMap<Int, Bitmap>()
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val dst = RectF()
    private val verts: Array<FloatArray> by lazy {
        val p = (1f + sqrt(5f)) / 2f
        val raw = arrayOf(
            floatArrayOf(0f, 1f, p), floatArrayOf(0f, -1f, p), floatArrayOf(0f, 1f, -p), floatArrayOf(0f, -1f, -p),
            floatArrayOf(1f, p, 0f), floatArrayOf(-1f, p, 0f), floatArrayOf(1f, -p, 0f), floatArrayOf(-1f, -p, 0f),
            floatArrayOf(p, 0f, 1f), floatArrayOf(-p, 0f, 1f), floatArrayOf(p, 0f, -1f), floatArrayOf(-p, 0f, -1f)
        )
        Array(12) { i -> val v = raw[i]; val l = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); floatArrayOf(v[0] / l, v[1] / l, v[2] / l) }
    }

    const val ROT_STEPS = 12

    /** Sprite del balón de n x n píxeles; [rot] 0..11 = giro alrededor del eje vertical (para animar el vuelo). */
    fun bitmap(n: Int, rot: Int = 0): Bitmap {
        val key = n * 100 + Math.floorMod(rot, ROT_STEPS)
        cache[key]?.let { return it }
        val px = IntArray(n * n)
        val yaw = Math.floorMod(rot, ROT_STEPS) * (2f * PI.toFloat() / ROT_STEPS)
        val tilt = 0.45f
        val cy = cos(yaw); val sy = sin(yaw); val ct = cos(tilt); val st = sin(tilt)
        val rad = n / 2f - 1f
        val white = PC.tones(0xFFF2F4F8.toInt())
        val patch = PC.tones(0xFF2C3140.toInt())
        val seam = 0xFFB9BECC.toInt()
        val lx = -0.5f; val ly = 0.62f; val lz = 0.60f
        val ll = sqrt(lx * lx + ly * ly + lz * lz)
        val inside = BooleanArray(n * n)
        for (j in 0 until n) for (i in 0 until n) {
            val x = (i + 0.5f - n / 2f) / rad; val y = -(j + 0.5f - n / 2f) / rad
            val r2 = x * x + y * y
            if (r2 > 1f) continue
            inside[j * n + i] = true
            val z = sqrt(1f - r2)
            val lam = (x * lx + y * ly + z * lz) / ll
            // normal en el marco del balón (rotado): giro vertical + inclinación
            val rx = x * cy + z * sy; val rz0 = -x * sy + z * cy
            val ry = y * ct - rz0 * st; val rz = y * st + rz0 * ct
            var best = -1f
            for (v in verts) best = max(best, rx * v[0] + ry * v[1] + rz * v[2])
            val tone = if (lam > 0.72f) 0 else if (lam > 0.30f) 1 else if (lam > -0.05f) 2 else 3
            px[j * n + i] = when {
                best > 0.936f -> patch[min(tone, 3).coerceAtLeast(1)]
                best > 0.905f -> if (tone >= 2) PC.shade(seam, 0.78f) else seam
                else -> white[tone]
            }
        }
        val outline = 0xFF14101C.toInt()
        for (j in 0 until n) for (i in 0 until n) if (!inside[j * n + i]) {
            var near = false
            for (d in 0..3) {
                val ni = i + (if (d == 0) 1 else if (d == 1) -1 else 0); val nj = j + (if (d == 2) 1 else if (d == 3) -1 else 0)
                if (ni in 0 until n && nj in 0 until n && inside[nj * n + ni]) near = true
            }
            if (near) px[j * n + i] = outline
        }
        val bm = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
        cache[key] = bm
        return bm
    }

    /** Dibuja el balón centrado en (cx, cy) con diámetro [dia] (px de referencia). */
    fun draw(c: Canvas, cx: Float, cy: Float, dia: Float, n: Int, rot: Int = 0) {
        val bm = bitmap(n, rot)
        val h = dia / 2f
        dst.set(cx - h, cy - h, cx + h, cy + h)
        c.drawBitmap(bm, null, dst, paint)
    }
}
