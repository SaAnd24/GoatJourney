package com.goatjourney.rendering

import android.graphics.Canvas
import com.goatjourney.input.GestureListener
import kotlin.math.min

/** Escala responsive: se diseña en 1280x720 y se escala/centra con scale + offset. */
/** Resolución de referencia VERTICAL (9:16). */
object Ref { const val W = 720f; const val H = 1280f }

/** Rejilla de píxeles lógicos (540x960). */
object PxGrid { const val W = 540f; const val H = 960f; const val LOGICAL_PER_REF = 0.75f }

class Viewport {
    val referenceWidth = Ref.W
    val referenceHeight = Ref.H
    var scale = 1f; private set
    var offsetX = 0f; private set
    var offsetY = 0f; private set

    fun resize(w: Int, h: Int) {
        // El arte se dibuja en píxeles lógicos (540x960 = 0.75 de la referencia). Si el factor de escala a pantalla
        // está cerca de un entero, se ajusta a él: cada píxel lógico ocupa un número exacto de píxeles de pantalla.
        val raw = min(w / PxGrid.W, h / PxGrid.H)
        val s = if (raw >= 1f && raw - kotlin.math.floor(raw) < 0.2f) kotlin.math.floor(raw) else raw
        scale = s * PxGrid.LOGICAL_PER_REF
        offsetX = (w - referenceWidth * scale) / 2f
        offsetY = (h - referenceHeight * scale) / 2f
    }

    fun toRefX(px: Float) = (px - offsetX) / scale
    fun toRefY(py: Float) = (py - offsetY) / scale

    fun apply(c: Canvas) {
        c.translate(offsetX, offsetY)
        c.scale(scale, scale)
        c.clipRect(0f, 0f, referenceWidth, referenceHeight)
    }
}

object Ease {
    fun outCubic(p: Float): Float { val q = 1f - p; return 1f - q * q * q }
    fun outQuad(p: Float): Float = 1f - (1f - p) * (1f - p)
    fun inOut(p: Float): Float = if (p < 0.5f) 2f * p * p else 1f - (-2f * p + 2f).let { it * it } / 2f
    fun outBack(p: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; val q = p - 1f; return 1f + c3 * q * q * q + c1 * q * q }
}

/** Contrato de toda pantalla Canvas. Para añadir una pantalla: implementa esto (o extiende BaseScreen). */
interface ScreenRenderer : GestureListener {
    val background: Int get() = Palette.BG
    fun onEnter()
    fun update(dt: Float)
    fun render(c: Canvas)
    fun onBack(): Boolean = false
}

/** Pool simple de partículas (confeti de gol) sin asignaciones durante el juego. */
class Particles(private val n: Int = 56) {
    private val x = FloatArray(n); private val y = FloatArray(n)
    private val vx = FloatArray(n); private val vy = FloatArray(n)
    private val life = FloatArray(n); private val col = IntArray(n)
    private val palette = intArrayOf(Palette.GOLD, Palette.ACCENT, Palette.WHITE, Palette.RED)

    fun burst(cx: Float, cy: Float) {
        for (i in 0 until n) {
            val a = Math.random().toFloat() * 6.2832f
            val s = 120f + Math.random().toFloat() * 420f
            x[i] = cx; y[i] = cy
            vx[i] = kotlin.math.cos(a) * s; vy[i] = kotlin.math.sin(a) * s - 180f
            life[i] = 0.8f + Math.random().toFloat() * 0.9f
            col[i] = palette[i % palette.size]
        }
    }

    fun update(dt: Float) {
        for (i in 0 until n) {
            if (life[i] <= 0f) continue
            life[i] -= dt
            vy[i] += 700f * dt
            x[i] += vx[i] * dt; y[i] += vy[i] * dt
        }
    }

    fun draw(c: Canvas, ui: UI) {
        for (i in 0 until n) {
            if (life[i] <= 0f) continue
            ui.fill.color = withAlpha(col[i], (life[i].coerceIn(0f, 1f) * 255).toInt())
            c.drawRect(x[i], y[i], x[i] + 9f, y[i] + 6f, ui.fill)
        }
    }
}
