# GOAT Journey 1.1.1 — Pixel Contact + Pixel Art humano

Mismo proyecto (Canvas, Room, DataStore, CareerState, Match Engine, ActionResolver, PLAY/SIMULATE). No se rehace la arquitectura
ni se añaden sistemas RPG. Las partidas existentes son compatibles: no cambia ningún dato serializado (los aspectos
de personas se derivan de `Appearance` + nombre/club con una semilla; nada nuevo se guarda).

> IMPORTANTE: esta versión se escribió sin compilador ni dispositivo a mano. Hay que compilar y probar en un móvil;
> abajo hay una lista de qué mirar primero y de las constantes de ajuste.

## 1. Controles (prioridad 1)
- `input/Input.kt`: sigue UN solo dedo por id (un segundo dedo ya no rompe el gesto), entrega todos los puntos históricos de cada
  MOVE y distingue CANCEL de UP (un cancel del sistema ya no ejecuta un golpeo).
- Nuevo callback `onMove` sin umbral: el trazo se actualiza desde el primer píxel. El umbral de drag baja de 16 a 8 px.
- `MatchScreen`:
  - el toque ya no se pierde durante la intro del momento (antes se ignoraba ~0.8 s);
  - en POSITIONING, tocar a menos de 120 px del balón (aro punteado visible) empieza a apuntar al instante; fuera de él te mueves;
    si ya no puedes moverte (tiempo agotado o recorrido máximo) cualquier toque apunta;
  - potencia = distancia (máx. 230 px, antes 260; mínimo 16 px, antes 26).

## 2. Pixel Contact System (prioridades 2–3)
- Balón de pixel art con cuadrícula lógica **32 × 32** (`rendering/pixel/PixelBall.kt`, `ContactGrid` en `core/match/Phases.kt`).
- El toque se convierte a coordenadas normalizadas (nx, ny ∈ [-1, 1] respecto al centro), se proyecta al borde si cae fuera del balón
  (zona táctil generosa) y se cuantiza a la celda (muestra discreta de un modelo continuo). No hay comportamiento por píxel.
- La celda elegida se resalta; se muestran el resultado en texto, barras de efecto/altura y **la trayectoria prevista en vivo** sobre el campo
  (recta al principio, curva después).

## 3. Física del spin (prioridades 4–7) — `core/match/SpinPhysics.kt`, `BallPhysics.kt`
```
contacto (nx, ny) -> r = (nx, -profundidad, ny·0.30)      centro -> punto, marco local del golpeo
dirección + potencia -> F (a lo largo del golpeo)
torque = r × F  ->  spin inicial ω (rad/s), proporcional a la velocidad de salida y al desplazamiento
vuelo: a_Magnus = ½ρA/m · CL(S) · v² · (ω × v)/(|ω||v|),   S = ωR/|v|   (∝ spin × velocidad)
```
- La pantalla NO decide la curva: el spin vive en un marco inercial y el efecto se calcula respecto a la velocidad real. Misma
  desviación a 0°, 30°, –40° o 90° (verificado con `tools/spin_prototype.py`).
- La curva nace en cero y crece (≈ t²), depende de la velocidad y del spin, y el spin decae en vuelo (0.35/s) y en el bote.
- Contacto vertical continuo: abajo = más elevación + backspin (sustentación), arriba = más bajo/rasante + topspin (cae antes) + algo más de velocidad.
- Bote con fricción: el spin cambia la velocidad horizontal tras el bote y pierde intensidad.
- Los atributos solo modulan el spin máximo (×0.78–1.18) y el margen de error; el ruido aleatorio por mal contacto baja respecto a 1.1.

**Convención (física real):** tocar la mitad DERECHA del balón (visto desde atrás) hace que curve a la IZQUIERDA, y viceversa. La pantalla
lo recuerda ("IZQ: CURVA →", "DER: ← CURVA") y la trayectoria prevista lo enseña. Si prefieres lo contrario, basta con invertir el signo de `nx`
en `SpinModel.spinFor`.

Constantes de ajuste (`SpinModel`): `STRIKE_EFF` (0.30, cuánto spin sale del golpe), `W_MAX` (100), `VERT_FACTOR` (0.30),
`CL_MAX`/`S0` (curva de sustentación), `SPIN_DECAY` (0.35). Referencia con estos valores: tiro a 26 m/s con contacto lateral máximo
≈ 3–4 m de desviación en 1 s; pase a 14 m/s ≈ 0.3–0.5 m en 16 m.

## 4. Pixel art humano (prioridad 9)
- Resolución lógica 540 × 960 (1 px lógico = 4/3 px de referencia). El factor de escala a pantalla se ajusta a un entero cuando está cerca
  (p. ej. 1080 de ancho → exactamente 2 px de pantalla por px lógico). Todo se dibuja sin antialias y con bitmaps sin filtrado.
- `rendering/pixel/HumanSprites.kt`: generador procedural de personas (esqueleto 3D → proyección → sombreado de 3 tonos → contorno).
  Proporciones de ~7 cabezas, 4 complexiones, altura variable, 10 peinados, barba/bigote, cejas, ropa por club (patrones: liso, aros, rayas,
  mitades, banda diagonal, banda al pecho), dorsal en la espalda, escudo y patrocinador al frente, guantes de portero, botas.
  Vistas: espalda / frente / perfil (espejo). Poses: idle, carrera (6 fotogramas), golpeo (preparación, contacto, continuación),
  celebración, lamento, protesta, cabezazo, portero.
- `Looks.kt`: protagonista = su `Appearance` + rasgos de su nombre (siempre la misma cara); compañeros/rivales = semilla por club e índice.
- `Stadium.kt`: gradas con público, vallas publicitarias, túnel, césped con corte y textura, porterías con red, banderines.
- `PixelFont.kt` (5×7 proporcional, mayúsculas, con tildes/Ñ) y `UIComponents.kt`: paneles, botones, barras e iconos con bordes
  pixelados; la UI conserva las mismas funciones, así que todas las pantallas heredan el estilo. El texto se encoge solo si no cabe.
- `tools/sprite_prototype.py` genera hojas de sprites para iterar el arte sin compilar (`python3 sprite_prototype.py 42`).

## 5. Qué revisar primero al compilar
1. Que compile (todo el código nuevo está sin compilar). Si algo falla, probablemente sea tipado Float/Int o un import.
2. Texto: la fuente de píxeles es más ancha que la anterior; las pantallas con cadenas largas se reducen automáticamente (escala 1),
   y quizá convenga acortar alguna.
3. Rendimiento: los sprites se generan al vuelo la primera vez (un pequeño tirón al empezar un momento); luego salen de caché.
4. Sensación de la curva: ajustar `STRIKE_EFF` / `CL_MAX` primero.

## Estructura nueva
```
core/match/SpinPhysics.kt        Vec3, Spin, SpinModel (torque, Magnus, elevación)
core/match/BallPhysics.kt        simulación con spin, Magnus y bote con fricción
core/match/Phases.kt             Contact, ContactGrid 32x32, ContactPhase, AimPhase
rendering/pixel/                 PixelArt, HumanSprites, Looks, PixelBall, PixelFont, Stadium
input/Input.kt                   un dedo, historial de movimientos, onMove / onCancel
tools/                           prototipos en Python de spin y sprites
```
